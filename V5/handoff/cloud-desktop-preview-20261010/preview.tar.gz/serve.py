"""Serve the unchanged cloud read-only snapshot on this machine's loopback."""
import argparse,hashlib,json,os,signal,subprocess,sys,tempfile,time
from pathlib import Path
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--port',type=int,default=18896);args=parser.parse_args()
if not 1024<=args.port<=65533:raise SystemExit('PORT_RANGE')
manifest=json.loads((root/'FILES.json').read_text())
for name,sha in manifest.items():
 p=root/name
 if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest()!=sha:raise SystemExit('BUNDLE_SHA_MISMATCH:'+name)
env=dict(os.environ,PYTHONPATH=str(root/'src'),PYTHONDONTWRITEBYTECODE='1');processes=[]
with tempfile.TemporaryDirectory(prefix='v5-readonly-preview-') as temporary:
 config_dir=Path(temporary)
 for name in ('manager','announcement','gateway'):
  config=json.loads((root/'config'/f'{name}.json').read_text())
  if name=='gateway':
   config['modules']['manager']['port']=args.port+1;config['modules']['announcement']['port']=args.port+2
  else:config['data_root']=str(root/('data-'+name))
  (config_dir/f'{name}.json').write_text(json.dumps(config))
 def stop(signum,frame):raise KeyboardInterrupt
 signal.signal(signal.SIGTERM,stop)
 try:
  for name,port in (('manager',args.port+1),('announcement',args.port+2),('gateway',args.port)):
   module='api_gateway' if name=='gateway' else 'module_api'
   command=[sys.executable,'-B','-m','v5_shadow.'+module,'--config',str(config_dir/f'{name}.json'),'--port',str(port)]
   if name=='gateway':command+=['--frontend-root',str(root/'web'),'--frontend-manifest',str(root/'config/frontend.json')]
   processes.append(subprocess.Popen(command,cwd=root,env=env))
  print(f'LOCAL ONLY http://127.0.0.1:{args.port}/manager-selection/?date=20261012',flush=True)
  print('Existing PARTIAL run b28fae24e8c446e199fa5a0743cb8c55; no collection; no browser opened.',flush=True)
  while all(p.poll() is None for p in processes):time.sleep(.25)
  raise SystemExit('PREVIEW_PROCESS_EXITED')
 except KeyboardInterrupt:pass
 finally:
  for p in processes:
   if p.poll() is None:p.terminate()
  for p in processes:
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.kill();p.wait()
