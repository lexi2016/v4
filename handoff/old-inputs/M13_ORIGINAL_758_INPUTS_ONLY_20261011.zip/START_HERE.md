# M13 旧 08/07 真实输入专包

仅包含原 `request.json` 和它声明的 758 个原件，附新生成的逐件 SHA 清单与装配说明。未包含 10/12 缺件诊断、其他模块运行记录或共享诊断文档。此包仅在本地准备，没有上传。

## 原始身份

- target_date：20261008
- publication_date：2026-10-07
- request：`original/request.json`，138989 bytes，SHA-256 `817c2ac013db29d7fb6c560442edaaad7c583ecf8bb425252cc744fcd1c11b7d`
- 六键原样保留：target_date、publication_date、manager_root、materials_root、manager_files、material_files。
- `original/manager/`：原 manager_files 声明的 694 件。
- `original/materials/`：原 material_files 声明的 64 件。
- 原 request + 758 个绑定文件全部保留原字节，原日期、审核、产品和文件 SHA 没有修改。MANIFEST.json 的文件清单依据原 request 两个映射生成，SHA256SUMS 覆盖交接文件。

## 先核后用

在本包解压根读取 ASSEMBLY.md，逐件核 request 声明的 SHA，再进行明确标注的路径迁移。原 request 中的两个绝对根是原 Mac 路径，不能假称在其他电脑同样存在。

此包解决原 M13 真实 20 项测试所需的旧输入材料，不包含 M13 工程源码、Python 环境或依赖，也不保证测试已经通过。工程源码与 e06d/1a699a0 fixture、consumer overlay 使用独立工程交接包；保持两个合成版本独立。

没有运行产品、pytest、fixture、采集、审核、导入或发布。旧 08/07 材料不能改日期成为 10/12 新公告。原 request 是历史原件，任何路径迁移只能另存派生文件，不得冒称历史回执。
