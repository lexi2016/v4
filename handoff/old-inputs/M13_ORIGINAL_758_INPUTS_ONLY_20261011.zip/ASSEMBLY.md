# 离线核验与路径迁移

本包解压后已有 original/request.json、original/manager 和 original/materials。所有数据均是原 request 明确声明的输入；不要合并其他版本、造额外正文或填新时间。

## 1. 本地文件核验

在解压根执行下列 Python 标准库命令。它只读取文件，核六键、原 request SHA、694+64 文件 SHA，不导入产品：

```sh
python3 - <<'PY'
from pathlib import Path, PurePosixPath
import json, hashlib
base = Path.cwd()
raw = (base / 'original/request.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == '817c2ac013db29d7fb6c560442edaaad7c583ecf8bb425252cc744fcd1c11b7d'
r = json.loads(raw)
assert set(r) == {'target_date','publication_date','manager_root','materials_root','manager_files','material_files'}
assert r['target_date'] == '20261008' and r['publication_date'] == '2026-10-07'
assert len(r['manager_files']) == 694 and len(r['material_files']) == 64
for key, subdir in [('manager_files','manager'),('material_files','materials')]:
    for name, expected in r[key].items():
        p = PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in name
        actual = base / 'original' / subdir / p
        assert actual.is_file() and not actual.is_symlink(), name
        assert hashlib.sha256(actual.read_bytes()).hexdigest() == expected, name
print('Original request + 758 bound file SHA256: PASS; product NOT_RUN')
PY
```

## 2. 仅路径迁移到其他受支持环境

只有原 request 的两个 Mac 根在消费环境确实存在且逐件验证时，才可直接使用原 request。否则在已经授权的独立测试副本中，先完成第 1 步，再另建派生文件。如下命令不改变日期、两组相对路径或文件 SHA，不覆盖原 request，不执行产品：

```sh
python3 - <<'PY'
from pathlib import Path
import json, hashlib
base = Path.cwd().resolve()
source = base / 'original/request.json'
raw = source.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '817c2ac013db29d7fb6c560442edaaad7c583ecf8bb425252cc744fcd1c11b7d'
r = json.loads(raw)
original = json.loads(raw)
r['manager_root'] = str(base / 'original/manager')
r['materials_root'] = str(base / 'original/materials')
assert {k for k in r if r[k] != original[k]} <= {'manager_root','materials_root'}
for key, subdir in [('manager_files','manager'),('material_files','materials')]:
    for name, expected in r[key].items():
        assert hashlib.sha256((base/'original'/subdir/name).read_bytes()).hexdigest() == expected, name
target = base / 'DERIVED_PATH_RELOCATION_ONLY.request.json'
with target.open('x') as stream:
    json.dump(r, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
assert source.read_bytes() == raw
print('Created path-only derivative:', target)
print('Original SHA256:', hashlib.sha256(raw).hexdigest())
print('Derivative SHA256:', hashlib.sha256(target.read_bytes()).hexdigest())
print('Only roots changed; no product execution; not a historical receipt')
PY
```

然后把 V5_ANNOUNCEMENT_REQUEST_PATH 指向消费环境中此派生文件的实际绝对路径。记录原 SHA、派生 SHA 与两个根的映射。不得把派生 request 当作原始请求、审核或运行回执；本包没有预先生成它。

是否执行产品测试及使用哪个解释器，沿原 M13 工程交接和既有测试授权；这些文件校验命令不代表产品通过，也不授权采集、导入、生产发布或交易。
