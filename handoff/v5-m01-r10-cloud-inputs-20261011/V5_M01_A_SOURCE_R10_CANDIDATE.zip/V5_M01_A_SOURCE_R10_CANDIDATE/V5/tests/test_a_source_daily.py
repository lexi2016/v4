
import pytest
from v5_shadow.a_source_daily import project,M01BindingError,binding_relative

def fixture():
    return {"status":"READY","target_date":"20261011",
    "generation_id":"a"*64,"path":"/tmp/generation",
    "sha256":"b"*64,"strict_source_verified":True,
    "input_manifest":{"manifest_sha256":"c"*64},
    "input_manifest_evidence":{"sha256":"d"*64},
    "source":{"sync_receipt_sha256":"e"*64}}

def test_ok():
    assert project(fixture()).status=="BOUND"

def test_strict_int():
    x=fixture(); x["strict_source_verified"]=1
    with pytest.raises(M01BindingError):
        project(x)

def test_relative():
    b=project(fixture())
    assert b.identity if hasattr(b,"identity") else binding_relative(b)
