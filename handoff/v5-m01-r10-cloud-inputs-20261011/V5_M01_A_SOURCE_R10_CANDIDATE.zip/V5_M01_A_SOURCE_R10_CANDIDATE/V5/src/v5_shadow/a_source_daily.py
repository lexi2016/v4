
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime
import hashlib, json, re

class M01BindingError(Exception):
    pass

@dataclass(frozen=True)
class ASourceBinding:
    schema:str
    status:str
    target_date:str
    generation_id:str
    generation_path:str
    generation_sha256:str
    manifest_sha256:str
    manifest_evidence_sha256:str
    sync_receipt_sha256:str
    strict_source_verified:bool
    cutoff_status:str

FIELDS=set(ASourceBinding.__dataclass_fields__)

def validate_date(v):
    if type(v) is not str or re.fullmatch(r"[0-9]{8}", v) is None:
        raise M01BindingError("date")
    datetime.strptime(v,"%Y%m%d")
    return v

def sha(v,n):
    if type(v) is not str or re.fullmatch(r"[0-9a-f]{64}",v) is None:
        raise M01BindingError(n)
    return v

def project(r):
    if r.get("status")!="READY":
        raise M01BindingError("status")
    if type(r.get("strict_source_verified")) is not bool or r["strict_source_verified"] is not True:
        raise M01BindingError("strict")
    p=r["path"]
    if isinstance(p,Path): p=str(p)
    if type(p) is not str or "\x00" in p or not p.startswith("/"):
        raise M01BindingError("path")
    gid=r["generation_id"]
    if type(gid) is not str or re.fullmatch(r"[0-9a-f]{64}",gid) is None:
        raise M01BindingError("generation_id")
    return ASourceBinding(
        "v5.m01.a_source_binding.r10","BOUND",
        validate_date(r["target_date"]),gid,p,
        sha(r["sha256"],"generation"),
        sha(r["input_manifest"]["manifest_sha256"],"manifest"),
        sha(r["input_manifest_evidence"]["sha256"],"evidence"),
        sha(r["source"]["sync_receipt_sha256"],"receipt"),
        True,"UNVERIFIED")

def identity(b):
    return hashlib.sha256(
        json.dumps(asdict(b),sort_keys=True,separators=(",",":")).encode()
    ).hexdigest()

def binding_relative(b):
    return f"m01/a_source/{b.target_date}/{identity(b)}/binding.json"

def parse_binding(raw):
    try:
        o=json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise M01BindingError("json") from e
    if type(o) is not dict or set(o)!=FIELDS:
        raise M01BindingError("fields")
    b=ASourceBinding(**o)
    if b.schema!="v5.m01.a_source_binding.r10" or b.status!="BOUND":
        raise M01BindingError("schema")
    if type(b.strict_source_verified) is not bool or b.strict_source_verified is not True:
        raise M01BindingError("strict")
    if b.cutoff_status!="UNVERIFIED":
        raise M01BindingError("cutoff")
    validate_date(b.target_date)
    for x in (b.generation_sha256,b.manifest_sha256,b.manifest_evidence_sha256,b.sync_receipt_sha256):
        sha(x,"sha")
    return b

def verify_binding_bytes(raw, relative, reader):
    b=parse_binding(raw)
    if relative != binding_relative(b):
        raise M01BindingError("relative")
    current=project(reader(b.generation_path,
        expected_target_date=b.target_date,require_source=True))
    if current != b:
        raise M01BindingError("drift")
    return b

def read_and_verify_binding(safe_root,relative,reader):
    raw=safe_root.read_bytes(relative,max_bytes=65536)
    return verify_binding_bytes(raw,relative,reader)

def create_binding(private_root,generation_pointer,target_date,reader):
    current=project(reader(generation_pointer,
        expected_target_date=validate_date(target_date),
        require_source=True))
    relative=binding_relative(current)
    raw=json.dumps(asdict(current),sort_keys=True).encode()
    with private_root.kernel_lock("m01/.binding.lock",timeout=5):
        try:
            raw_old=private_root.read_bytes(relative,max_bytes=65536)
        except FileNotFoundError:
            raw_old=None
        if raw_old is not None:
            old=verify_binding_bytes(raw_old,relative,reader)
            if old!=current:
                raise M01BindingError("identity")
            return old
        private_root.write_bytes(relative,raw,require_absent=True)
        return verify_binding_bytes(
            private_root.read_bytes(relative,max_bytes=65536),
            relative,reader)
