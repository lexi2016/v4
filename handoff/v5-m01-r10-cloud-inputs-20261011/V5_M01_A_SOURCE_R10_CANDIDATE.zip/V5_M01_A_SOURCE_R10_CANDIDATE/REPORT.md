M01 R10 candidate.
Fixed:
- calendar date validation
- narrow read_bytes FileNotFound boundary
- exact binding_relative
- shared verify_binding_bytes path
- strict parser retention

Not implemented in this candidate:
- production root assembly marker/source_root guard (requires full v5 composition integration in isolated assembly).
Runtime tests NOT_RUN.
