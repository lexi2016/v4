from dataclasses import dataclass,asdict
from pathlib import Path
import json,hashlib,re
class M01BindingError(Exception): pass
@dataclass(frozen=True)
class ASourceBinding:
 schema:str;status:str;target_date:str;generation_id:str;generation_path:str
 generation_sha256:str;manifest_sha256:str;manifest_evidence_sha256:str
 sync_receipt_sha256:str;strict_source_verified:bool;cutoff_status:str
def sha(x):
 if type(x) is not str or re.fullmatch(r"[0-9a-f]{64}",x) is None: raise M01BindingError("sha")
 return x
def project(r):
 if r.get("status")!="READY" or type(r.get("strict_source_verified")) is not bool or not r["strict_source_verified"]: raise M01BindingError("reader")
 p=r["path"]; p=str(p) if isinstance(p,Path) else p
 if type(p) is not str or not p.startswith("/"): raise M01BindingError("path")
 if type(r["target_date"]) is not str or re.fullmatch(r"\\d{8}",r["target_date"]) is None: raise M01BindingError("date")
 return ASourceBinding("v5.m01.a_source_binding.r9","BOUND",r["target_date"],r["generation_id"],p,sha(r["sha256"]),sha(r["input_manifest"]["manifest_sha256"]),sha(r["input_manifest_evidence"]["sha256"]),sha(r["source"]["sync_receipt_sha256"]),True,"UNVERIFIED")
def identity(b):
 return hashlib.sha256(json.dumps(asdict(b),sort_keys=True,separators=(",",":")).encode()).hexdigest()
def parse_binding(raw):
 try: o=json.loads(raw.decode())
 except Exception as e: raise M01BindingError("json") from e
 if type(o) is not dict: raise M01BindingError("object")
 b=ASourceBinding(**o)
 if b.schema!="v5.m01.a_source_binding.r9" or b.status!="BOUND" or type(b.strict_source_verified) is not bool or not b.strict_source_verified or b.cutoff_status!="UNVERIFIED": raise M01BindingError("schema")
 for x in [b.generation_sha256,b.manifest_sha256,b.manifest_evidence_sha256,b.sync_receipt_sha256]: sha(x)
 return b
def read_and_verify_binding(safe_root,relative,reader):
 raw=safe_root.read_bytes(relative,max_bytes=65536)
 b=parse_binding(raw)
 c=project(reader(b.generation_path,expected_target_date=b.target_date,require_source=True))
 if c!=b or identity(b) not in relative: raise M01BindingError("drift")
 return b
def create_binding(private_root,generation_pointer,target_date,reader):
 b=project(reader(generation_pointer,expected_target_date=target_date,require_source=True))
 rel=f"m01/a_source/{b.target_date}/{identity(b)}/binding.json"
 raw=json.dumps(asdict(b),sort_keys=True).encode()
 with private_root.kernel_lock("m01/.binding.lock",timeout=5):
  try: old=read_and_verify_binding(private_root,rel,reader)
  except FileNotFoundError: old=None
  if old is not None:
   if old!=b: raise M01BindingError("identity")
   return old
  private_root.write_bytes(rel,raw,require_absent=True)
 return read_and_verify_binding(private_root,rel,reader)
