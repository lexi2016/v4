import pytest
from v5_shadow.a_source_daily import project,M01BindingError
def f():
 return {"status":"READY","target_date":"20261011","generation_id":"a"*64,"path":"/tmp/g","sha256":"b"*64,"strict_source_verified":True,"input_manifest":{"manifest_sha256":"c"*64},"input_manifest_evidence":{"sha256":"d"*64},"source":{"sync_receipt_sha256":"e"*64}}
def test_ok(): assert project(f()).status=="BOUND"
def test_strict_type():
 x=f(); x["strict_source_verified"]=1
 with pytest.raises(M01BindingError): project(x)
