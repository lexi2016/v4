# M13 实际源码输入包

日期：2026-10-10。本包直接提供真实源码字节，普通Chat无需访问私有GitHub即可开始。它是源码材料，不是代码修复候选、可部署应用或已跑测试报告。

## 立即使用

1. 解压本ZIP，先读本README、SOURCE_MANIFEST.json、FILE_SCOPE.csv及TASK/PROMPT_FOR_CHAT.md。
2. 唯一代码基线：lexi2016/v4@f7cb731c384ee6890a87d16c19a5b5a621779477。
3. 本轮重新核该commit Git tree为7c97899274c1bed96cf87ae2df6226eddf27aac2（recursive tree未截断），每份源码按固定tree的Git blob SHA逐字节校验。SHA-256与长度另记SOURCE_MANIFEST。
4. TARGET四文件及M13测试可作为最小候选对象；文件存在不代表授权修改。先交逐文件白名单，已等效实现保持原字节。
5. 保留完整before/after/正反patch/SHA、针对性测试、Mac步骤及跨模块请求。当前所有产品动态结果NOT_RUN。

若Chat不能解压ZIP，使用随包另附的M13核心全文文本；其包含四目标、五测试及主要manifest。全源码另提供分组全文TXT，无需私有链接。源文件以原始独立文件为校验权威，TXT边界与描述只是阅读包装。

## 已包含哪些材料

- 四个真实目标：announcement_bridge.py、announcement_offline_reader.py、announcement_analysis_api.py、daily_announcement_revision.py。
- 五个关联原测试：三个M13测试，加两个M18消费只读参考测试。
- 原announcement_offline_baseline的28项、announcement_revision_baseline的29项、announcement_readback_baseline的21项manifest成员，保留三套版本区别，并附原manifest。
- 上述入口必要静态阅读依赖、Python项目依赖声明、原README；共享函数、gateway与发布/运行账本文件均是只读参考。
- M18消费相关manager_plan/IO/gate及原workspace_announcements/calendar最小参考；完整80项manager_plan manifest保留，未冒充完整M18运行胶囊。
- TASK/含此前M13的四份任务/来源/验收文档。本README关于已提供源码与并行写入边界的最新说明优先。

三组公告owner闭包中少量workspace_plan/projection文件是其原manifest要求的冻结依赖，仅供理解原调用关系，不能因此获得经理保存/汇总或共享UI的改写权。

## 独占与共享边界

M13只负责原公告采集/目录、正文与来源、原Reader语义、原独立Reviewer、原owner导入、独立读取与消费接口。禁止重写算法、自审当独审、伪造PASS/source/PIT/获取时间或把未知填0。

原跨13→18 Chat正在处理经理/共享UI。不要与其重叠写入：
- manager_plan*.py、M18 vendor/消费测试、经理保存/汇总/terminal：只读。
- module_api/api_gateway/web/shared contracts、发布/调度/运行账本、共享前端：只读。
- frozen vendor胶囊/manifest：默认只读；必要原owner缺陷只交有证据的最小donor差异和闭包变更说明，嘻嘻统一集成。
- M13遇共享断点，提交接口、消费fixture和精确跨模块请求，不直接打共享补丁。

现有392决定及5b4feaf7ef7d4d13bec639e90b6d3db0经理消费成果复用，不重采、不重新分类/导入、不建立新经理run代替。原Mac正文、业务原件、运行绑定、凭据均未收进包。

## 可执行性边界：明确缺什么

本包足够按固定源码编写/审查M13最小差异，但不是独立可运行安装包：
- 原项目要求Python>=3.14、pandas>=2.3,<3、pyarrow>=21,<25；本包没有环境/虚拟环境/已安装依赖，未安装或执行。
- test_announcement_bridge要求真实V5_ANNOUNCEMENT_REQUEST_PATH及其已绑定原件；本包故意不含Mac真实公告材料，无输入必须NOT_RUN，不能改成skip假绿或造392数据。
- 原完整offline/revision测试另需V5_ANNOUNCEMENT_OFFLINE_TEST_BUNDLE及V5_ANNOUNCEMENT_REVISION_TEST_BUNDLE；这些upstream测试fixture未在固定V5 tree出现，本包不伪造。具体要求来自原测试源码。
- announcement_offline_reader.install_consumer_contract调用manager_plan._sources，会校验manager_plan_source_manifest的完整80项；本包只带3项直接消费/日历参考，缺77项，不能宣称该运行链可独立通过。
- manager_plan的M14/M15/archive等动态分支、daily adapter的跨模块identity依赖，以及完整平台部署配置不在M13最小包内。确需执行某条测试时，给嘻嘻精确缺失文件/fixture清单补齐，不索要全仓、不从其他版本凑文件。
- 实际Mac前像、source/semantic/reviewer/binding/product/receipt identities、共享集成/普通API/UI/自然接续均需后续现场核验。缺输入不阻止你交有完整前后像的代码候选。

MISSING_RUNTIME_INPUTS.json记录精确运行缺口；其中缺文件是范围披露，不是邀请M13重写或降低manifest校验。

## d659局部修复

本包未加入d659ff0 donor。当前只交固定源码，尚无实际候选差异能证明它对本M13目标必需；该交接还混含超跌修复，不整体带入。若最小复现确需其中公告SHA顺序或CLI readback donor，请明确原路径/函数/版本，由嘻嘻补原before/after到独立donor目录；不能把参考候选当现役源覆盖。

## 包检查与真实性

PACKAGE_CHECKS.json记录源码字节、Git blob、SHA-256、原owner manifest覆盖及ZIP CRC检查结果；它不代表产品测试。没有执行任何源码、导入业务模块、采集、测试、部署或外发。没有Mac真实392正文/数据/凭据。GitHub普通网页链接保留为来源标识，读取材料不依赖链接可访问。

所有共享集成仍由嘻嘻统一落地。M13代码候选、Mac定向通过、页面接入、自然接续分别记账，不在此包计完整模块完成。

