# M13 原始测试材料补件：e06d 原合成 fixture

本补件只补固定上游原始源码/测试字节及配置说明；不含真实业务数据，不改原 M13 ZIP，不改任何业务代码，不运行产品、pytest、unittest、fixture 生成、采集、导入或 Mac 操作。动态结果全部 NOT_RUN。文件读取、Git blob/SHA-256、依赖静态检查和 ZIP CRC 检查不等于业务验收。

## 结论

1. V5_ANNOUNCEMENT_REQUEST_PATH 指向原真实已发布输入的 JSON 文件。不是代码目录，也不是一个新造的空 request。其数据仍缺，不能由本包补造。
2. V5_ANNOUNCEMENT_REVISION_TEST_BUNDLE 指向固定 e06d 上游测试目录；它是原作者编写的合成测试代码，不是 392 篇真实材料。本包已补到原件。
3. 补到 e06d 并不代表 revision 三项已全部解锁。其共享 setUpClass 最后执行 run_revision→read_owner→install_consumer_contract→manager_plan._sources；原 M13 包只带 M18 manifest 的 3/80 个成员，仍缺 77。两个测试体还直接执行 M18 run_manager_plan，另有跨模块 identity/runtime 依赖。不能把后一层缺源错误改成 skip，也不能只改 PIN 放行。
4. 五文件建议另含 V5_ANNOUNCEMENT_OFFLINE_TEST_BUNDLE。它必须用原 1a699a040c0b2cd467726bca5ccc7847182cb975 合成闭包。本包不提供这个不同版本；不要把 e06d 路径同时赋给它。两个 owner manifest 不同。

## e06d 来源与内容

原 commit：e06d143e881c66c22053a5c594b9c0be21d5be34。
原目录：V5/handoff/announcement-budget-red-20261009。
原 tests/test_decision_revision.py Git blob：6a9306d87493541ec8ae057a3109f2df0524a4ed。

目录 e06d-original-fixture 保留原相对路径，含：

- 五个原测试：test_decision_revision.py → test_offline_analysis_chain.py → test_failed_partial_pages.py → test_v5_private_owner.py / test_offline_evidence_recovery.py
- 原 tools/assemble_owner_app.py
- 原 SOURCE_MANIFEST.json、OWNER_DEPENDENCIES.json、CANDIDATE_MANIFEST.json
- 这三个 manifest 按原 assembler 覆盖顺序选出的 25 个有效 owner 文件
- 原 DECISION_REVISION.md、OFFLINE_ANALYSIS_CHAIN.md

这是该测试入口的最小装配闭包，不是整个上游 handoff。原 manifest 中被后续覆盖的旧 preimage、其他未调用测试和其他说明未全部复制。原 assembler 先构建覆盖映射，再读取最终映射文件；本包包含全部最终映射文件。所有原文件未改一字。不要对本包要求执行上游完整 handoff 的 SHA256SUMS。

25 个有效 owner 文件与已发送 f7cb731 M13 包中的 announcement_revision_baseline 对应字节完全相同，同时核对 e06d 原 Git blob 和原 manifest SHA-256。按原 assembler 的顺序/格式静态推导的 app manifest 与现有 capsule 原 manifest 逐字相同：

da392a57bf93dd9a5b4355d934e267a7c5c4fe495e90779364627e8a8f118d8a

本轮没有执行 assembler。SOURCE_MANIFEST.json 记录本补件每个原件的 commit、路径、Git blob、SHA-256、字节数和固定 URL。EFFECTIVE_ASSEMBLER_INPUTS.json 记录有效覆盖映射。

## 准确配置

解压到一个新目录，保留本包结构。V5_ANNOUNCEMENT_REVISION_TEST_BUNDLE 必须设为解压所得 e06d-original-fixture 的绝对路径。该目录下应直接看到 tests/test_decision_revision.py、tools/assemble_owner_app.py 和三个 manifest；不要指向 tests 子目录、V5 源码目录或 ZIP 文件。

例如把下面的占位前缀替换为真实解压目录后设置，不能原样使用占位文字：

    export V5_ANNOUNCEMENT_REVISION_TEST_BUNDLE="<本补件实际解压绝对目录>/e06d-original-fixture"

原测试以 sys.executable -I -B 开独立子进程装配原 owner，原网络/子进程拒绝审计钩子保留；测试代码自身会生成临时合成材料、原合成 reviewer 和合成 import。源内固有测试时间/代码/计数保留为合成值，不代表实际日期、真实独立审核或真实采集。不得运行这些入口后把结果称为 392/5b4f 自然链验收。

原固定项目声明 Python >=3.14、pandas >=2.3,<3、pyarrow >=21,<25。运行环境本补件不提供，也没有验证。后续授权执行时保留 cwd、解释器版本、完整命令、exit、stdout/stderr、原输入/源 SHA。使用已固定 V5 根作为 cwd 时，项目导入需 PYTHONPATH=src；若 cwd 是含 V5 的上层，则需 PYTHONPATH=V5/src。先记录实际 cwd，不能只口述“加了 PYTHONPATH”。

## 真实 REQUEST_PATH 的最小范围

唯一 request 的六个键来自 announcement_bridge._request：target_date、publication_date、manager_root、materials_root、manager_files、material_files。

现有真实-owner测试绑定：target_date=20261008；publication_date=2026-10-07 或等价紧凑格式。manager_root/materials_root 为已有、互不包含、无 symlink 的真实绝对目录；两个 files 字典都是精确相对路径 → 原文件 SHA-256。

原测试要求该批已有 694 个 manager 文件、64 个 material 文件，合计 758；manager 其中 624 件为 announcement_agent_runs 下的原 handoff 引用，body_corpus 原件长度 21,861,605 bytes；原产品观察值是 33 selected、54 watch、75 unassessed。数字仅用于核对原件，不能按数字生成数据。

必要输入必须以原 request 两个字典完整展开并逐件核原 SHA；它们包括日期目录下原 analysis.v1.json、owner_import_receipt.v1.json、latest.json 与原 run mirror、声明的 handoff/body 文件、材料 blobs 与 index。不能只给一个 JSON 路径而没有它绑定的原件，也不能用 20261009/2026-10-08 的 392 修订产品或另一个经理 run 代替这批 08/07 原件。

固定 f7cb731 的 manager-announcement-input-audit 原文明确：原 758 文件输入包不在该云工作区，其 request/data 留在既有 Mac 任务。现有源包 MISSING_RUNTIME_INPUTS.json 也明确排除了它。本轮没有连接或读取 Mac，没有获得实际 request 路径、request SHA、原业务输入 SHA 清单，均 UNKNOWN/SOURCE_NOT_PROVIDED。只要继续在现有 Mac 核原件，就不需外传正文；若要给原 Chat 完整真实fixture，须另外确认原 request 指向的精确文件、必要传输范围及读权限，不能搬整棵业务目录或凭据。

此真实变量只挡 bridge 类与 ManagerAnnouncementRealOwner 类，不挡下列独立单元。REVISION_TEST_BUNDLE 的取得无需 Mac，只是执行规范仍应遵循原项目/父任务授权。

## 静态测试分层，不是测试结果

固定 f7cb731 五文件共 42 个 test_ 方法（AST 静态清点）：

- AnnouncementAnalysisApiTests：4。两变量都不依赖；原测试使用明示 mock，是查询/发布合同单元测试，不是真实 owner 验收。
- AnnouncementBridgeTests：17。setUp 每项都读 REQUEST_PATH，缺变量时 17 项全在前置失败。其中 test_handoff_corpus_limit_does_not_expand_other_input_or_output_limits 的测试体只检查边界大小，但仍被类 setUp 带住；不要为了凑绿改测试。
- DailyRevisionOriginalChainTests：3。全类依赖 e06d fixture，且其共享 setUp 最后依赖完整 M18 80 文件 consumer capsule；本补件只解决第一层。
- ManagerAnnouncementLimitTests：3。自身创建合法 JSON padding，测试内存/文件字节边界；不需要真实业务fixture。
- ManagerAnnouncementRealOwnerTests：3。要求原 REQUEST_PATH 758 文件及 M18 真实消费依赖。
- OfflineAnnouncementTransportTests：6。其中 test_overlay_keeps_new_terminal_and_installs_existing_manager_checks 依赖 manager_plan._sources 全80成员；其余5项是独立 transport 合同单元，不需要这两个变量或真实业务fixture。
- OfflineAnnouncementOriginalChainTests：6。由第三变量 V5_ANNOUNCEMENT_OFFLINE_TEST_BUNDLE 控制整类 skip；另需 consumer closure。旧 MANAGER_OFFLINE_ANNOUNCEMENT 文档写5项，但当前测试新增默认日期测试后源码实际为6，以固定测试源码为准。skip 不算验收。

在原环境/父任务授权范围内，源码就绪的独立单元可分开运行，不必等 Mac 真实业务包。本轮未运行。不要将全套42项和 Chat 的局部24项混算。

## Chat 回执的证据等级

可见回执自报实际尝试的是三个文件（API、bridge、revision），先 ModuleNotFoundError，再称加 PYTHONPATH=src 后 4 passed / 17 failed / 3 errors。五文件命令是后续建议。这里仅复述 Chat 的报告，不是本轮独立验证；完整原始 stdout/stderr、具体 cwd、解释器、exit 仍未提供。精确错误分类须待原日志，不能将“未找到业务缺陷”升级为“代码无需修复已完成”。

## 后续最小补充

1. 给原 Chat 本包及变量语义纠正；保持原 ZIP SHA 不变。
2. 若要执行 revision 3项或 overlay 合同1项，先按原 MISSING_RUNTIME_INPUTS.json 补固定 f7cb731 的缺失77个 M18 manifest 成员（只读消费依赖，不授权改 M18）；如测试随后进入 manager_plan 的其他缺失 identity/runtime，继续报精确缺件，不把它叫fixture缺失。
3. 原08/07真实fixture只在原 Mac 任务按已有 request + SHA核对；无需重采/重导/重建392。
4. 第三变量另用原1a699a0闭包；不能混装e06d或把skip当通过。
