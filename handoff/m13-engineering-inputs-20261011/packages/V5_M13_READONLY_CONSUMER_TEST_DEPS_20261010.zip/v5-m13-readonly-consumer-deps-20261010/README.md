# M13 既有测试的只读消费依赖补件

仅服务已经提交的 M13 会话。不是 M18 新模块交付，不开新 Chat，不授予 M13 修改 M18、共享 owner 或其他模块的权限。本包只提供固定 f7cb731c384ee6890a87d16c19a5b5a621779477 原文件字节。

## 已补内容

- overlay/V5/vendor/manager_plan_baseline：原 consumer descriptor 缺失的 77 件；与原 M13 包已有3件组合，完整80件已按路径/bytes/SHA-256静态核对。
- overlay/V5/src/v5_shadow：manager_plan._identity 无条件读到、原 M13 包没带的16件源码。它们在本任务只作身份/读取依赖，不是其他模块的业务候选。
- FIXED_CLOSURE.json：完整111件检查集合（80个consumer文件、30个identity文件、1个descriptor）。其中93件本包增补，18件要求沿用原M13包；含每件固定commit/blob/SHA-256/bytes/URL。

manager consumer descriptor逻辑PIN：61f288f00095ce0e60adf20598123e702d855462ac7d7216334ecfd1064933f5。
本轮未import产品、未执行owner、未run pytest/unittest/fixture、未采集、未用Mac。

## 怎么加入同一 M13 测试树

1. 保留原ZIP。原 v5-module13-source-20261010.zip SHA256 必须仍为 b226c0ead72b24392cda4b072ceda5fe40319ff44a48b1dc7603c8e1fd456e9e。
2. 将原 ZIP 解到新的独立测试目录，不直接写活动Mac代码、V4或其他模块工作树。
3. 将本包 overlay 下的 V5 按相同相对路径并入新解压的 v5-module13-source-20261010 目录。这93个路径原包均不存在；若实际目标已存在，先核固定SHA，只接受完全相同字节，任何不同内容必须停止，不覆盖。
4. 依 FIXED_CLOSURE.json 检查最终111件全部路径、bytes、SHA-256和blob；保留原112源件不变。不要更新任何PIN或业务代码。
5. e06d、1a699a0 fixture 目录应单独解压；不要把它们 candidate/owner_dependencies 混到 V5/vendor。两者由原测试在独立临时进程按各自原manifest装配。

环境声明沿原 pyproject：Python>=3.14、pandas>=2.3,<3、pyarrow>=21,<25。原fixture文件注释/文档保留Mac执行规范；执行地点和授权由现有父任务决定。本包只是补材料，不称这些动态测试已经运行或一定通过。

## 三个输入位置各司其职

- V5_ANNOUNCEMENT_REVISION_TEST_BUNDLE：先发e06d补包中的 e06d-original-fixture 绝对路径，owner manifest da392a57bf93dd9a5b4355d934e267a7c5c4fe495e90779364627e8a8f118d8a。
- V5_ANNOUNCEMENT_OFFLINE_TEST_BUNDLE：另发1a699a0补包中的 1a699a0-original-fixture 绝对路径，owner manifest 0ff96e3c5bc48c67fada2b979a9862b7778c9a33c1983cdc0ab180ea85125ab5。
- V5_ANNOUNCEMENT_REQUEST_PATH：原08/07真实758文件request JSON。它仍未提供；不得用合成数据或392修订产品替代。

本补件解决先发e06d README中提到的77 consumer＋16 identity缺源；另发1a699a0包解决其中第三变量原代码缺失。先发ZIP不改名不改字节。

## 对应测试分组（命令建议，NOT_RUN）

在新的测试树 V5 目录下，正确设置两个合成bundle绝对路径并确认环境/执行授权后，可以将不依赖真实REQUEST_PATH的22个test_方法与真实20个方法分别记录。下列是建议，不是已运行回执：

    PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 python -m pytest \
      tests/test_announcement_analysis_api.py \
      tests/test_manager_announcement_binding.py::ManagerAnnouncementLimitTests \
      tests/test_manager_offline_announcement.py \
      tests/test_daily_revision_chain.py -q

22项=API4 + manager大小3 + transport6 + offline原合成chain6 + revision原合成chain3。两个合成chain会调用真实原owner实现对临时合成数据执行；不得称真实业务数据验收。缺变量导致skip/error应如实单列。所有执行保留 cwd、Python版本、command、exit、完整stdout/stderr、fixture/源SHA；不要只报统计。

真实20项=AnnouncementBridgeTests 17 + ManagerAnnouncementRealOwnerTests 3；它们继续等原Mac任务已有request及全758件原SHA输入。无须因此阻塞上述独立分组，亦不得凭上述分组通过就宣布M13完成。

本包覆盖上述既有测试的consumer/identity源码依赖。不会提供其他可选业务lane的真实输入、凭据或整库部署配置。若后续实跑仍报缺件，原样交完整trace、精确路径和调用点，不能把源码错误笼统说成“两个真实fixture未到”。
