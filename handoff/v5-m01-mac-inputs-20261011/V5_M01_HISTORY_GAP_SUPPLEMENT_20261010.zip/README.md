# M01 历史缺口契约原文补件

本补件只补齐已发送 `V5_M01_SOURCE_REVIEW_20261010.zip` 缺少的一份真实原始材料，供同一 M01 Chat 继续静态审阅。没有改动、重打包或替换旧 ZIP。

## 来源与核对

- 仓库：`lexi2016/v4`
- 固定 commit：`f7cb731c384ee6890a87d16c19a5b5a621779477`
- 原仓库路径：`handoff/v4-running-source-20261005/canonical/contracts/a_known_history_gaps.json`
- Git blob：`cf75d542c85b1f7e082c902f46e32cef63d5766d`
- 原字节数：`65194`
- 文件 SHA-256：`988e483ded86ed9df6862f4a3317f74394b713c288b8f0df12fdb13ab9c04f02`
- 完整固定树 `truncated=false`；以 GitHub 返回的 base64 解码保存原字节，没有重新格式化或合成 JSON。

旧包中的 `handoff/v4-running-source-20261005/canonical/ops/_a_formula_increment_parts/history_audit.py:11` 读取原项目根目录下的 `contracts/a_known_history_gaps.json`。同包 `handoff/v4-running-source-20261005/canonical/ops/a_formula_increment.py:108` 的 `APPROVED_HISTORY_CONTRACT_SHA256` 与本文件 SHA-256 完全相同。两份引用源码也已按固定树 blob 核对；不在本补件中重复放入。

## 给 M01 Chat

1. 将本 ZIP 与原 SOURCE_REVIEW ZIP 一起阅读。原文保留原仓库相对路径，位于 `handoff/v4-running-source-20261005/canonical/contracts/a_known_history_gaps.json`。
2. 原运行时相对路径是 `contracts/a_known_history_gaps.json`，由原 `_PROJECT_ROOT` 定位。这里没有替你决定或修改 V5 候选的安装根、路径映射、包资源机制，也没有替换常量。
3. 保持原契约的原字节与精确 SHA、seed、role、key 绑定。不得以文件存在、行数、日期窗口相同代替逐项约束，不得重序列化后声称仍是该原文。
4. 原契约声明 `EXACT_KEYS_ONLY_RETAIN_NOT_REPAIR`。材料补齐不代表历史数据已修复、全种子健康通过、新增豁免获准、Mac 验收通过或自然运行完成。

## 包内清单

- `README.md`：用途与使用边界。
- `SOURCE_MANIFEST.json`：commit、path、blob、bytes、SHA-256、引用证据与核验范围。
- `FIXED_TREE_ENTRIES.json`：完整固定树中的本文件及两份引用源码条目摘录。
- `handoff/v4-running-source-20261005/canonical/contracts/a_known_history_gaps.json`：唯一新增的原始仓库文件。

原 ZIP 的 SHA-256 保持 `8643ec4846da31e2a32c95492cdf51648f1a957991a673d197685104d8029933`。本次只做静态字节、哈希、引用与 ZIP 完整性核对，没有导入或执行产品、没有运行产品测试，也没有读取 Mac 数据或部署。
