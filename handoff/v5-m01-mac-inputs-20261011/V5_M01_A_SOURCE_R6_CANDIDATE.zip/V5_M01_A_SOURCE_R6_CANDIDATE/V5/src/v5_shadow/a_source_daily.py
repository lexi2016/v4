"""M01 immutable generation binding boundary."""
from dataclasses import dataclass, asdict
import json, re

class M01BindingError(Exception):
    pass

@dataclass(frozen=True)
class ASourceBinding:
    schema: str
    status: str
    target_date: str
    generation_id: str
    generation_path: str
    generation_sha256: str
    manifest_sha256: str
    manifest_evidence_sha256: str
    sync_receipt_sha256: str
    strict_source_verified: bool
    cutoff_status: str = "UNVERIFIED"

def _sha(v, name):
    if not isinstance(v, str) or not re.fullmatch(r"[0-9a-f]{64}", v):
        raise M01BindingError(name)
    return v

def _project(v):
    if v.get("status") != "READY" or v.get("strict_source_verified") is not True:
        raise M01BindingError("reader state")
    return ASourceBinding(
        "v5.m01.a_source_binding.v6", "BOUND",
        str(v["target_date"]), str(v["generation_id"]), str(v["path"]),
        _sha(v["sha256"],"generation"),
        _sha(v["input_manifest"]["manifest_sha256"],"manifest"),
        _sha(v["input_manifest_evidence"]["sha256"],"evidence"),
        _sha(v["source"]["sync_receipt_sha256"],"receipt"),
        True)

def read_and_verify_binding(*, safe_root, relative, read_formula_generation):
    b=ASourceBinding(**json.loads(safe_root.read_bytes(relative, max_bytes=65536)))
    current=_project(read_formula_generation(b.generation_path,
        expected_target_date=b.target_date, require_source=True))
    if current != b:
        raise M01BindingError("drift")
    return b

def create_binding(*, private_root, generation_pointer, target_date,
                   read_formula_generation):
    b=_project(read_formula_generation(generation_pointer,
        expected_target_date=target_date, require_source=True))
    relative=f"m01/a_source/{b.target_date}/{b.generation_id}/binding.json"
    raw=json.dumps(asdict(b), sort_keys=True).encode()
    with private_root.kernel_lock("m01/.binding.lock", timeout=5):
        try:
            return read_and_verify_binding(safe_root=private_root,
              relative=relative, read_formula_generation=read_formula_generation)
        except Exception:
            pass
        private_root.write_bytes(relative, raw, require_absent=True)
        return read_and_verify_binding(safe_root=private_root,
          relative=relative, read_formula_generation=read_formula_generation)
