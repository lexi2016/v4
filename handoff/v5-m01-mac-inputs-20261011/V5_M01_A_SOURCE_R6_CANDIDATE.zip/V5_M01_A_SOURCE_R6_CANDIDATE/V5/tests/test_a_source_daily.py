import pytest
from v5_shadow.a_source_daily import _project, M01BindingError

def sample():
    return {"status":"READY","target_date":"20261010","generation_id":"g",
    "path":"/p","sha256":"a"*64,"strict_source_verified":True,
    "input_manifest":{"manifest_sha256":"b"*64},
    "input_manifest_evidence":{"sha256":"c"*64},
    "source":{"sync_receipt_sha256":"d"*64}}

def test_projection():
    assert _project(sample()).status=="BOUND"

def test_strict_reject():
    x=sample(); x["strict_source_verified"]=False
    with pytest.raises(M01BindingError):
        _project(x)
