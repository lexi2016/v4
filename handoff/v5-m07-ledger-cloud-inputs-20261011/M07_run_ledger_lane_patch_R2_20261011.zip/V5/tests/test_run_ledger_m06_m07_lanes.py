
from datetime import datetime, timezone
import pytest

from v5_shadow.run_ledger import claim_run, finish_run, identity_key, read_run


def _identity(lane):
    return {
        "lane": lane,
        "target_date": "20261011",
        "input_sha256": "a" * 64,
        "research_cutoff": datetime(2026, 10, 11, tzinfo=timezone.utc).isoformat(),
        "code_sha256": "b" * 64,
        "config_sha256": "c" * 64,
        "dependency_sha256": "d" * 64,
    }


def _success(ref):
    return {
        "status": "SUCCEEDED",
        "product_reference": ref,
        "readback_verified": True,
        "retry_safe_without_external_effect": True,
        "reason_codes": [],
    }


@pytest.mark.parametrize("lane", [
    "announcement", "us_mapping", "rebound", "manager_plan",
    "hk_preselection", "a_stage",
])
def test_all_allowed_lanes_real_claim_finish_read_reuse(tmp_path, lane):
    # Real fixture setup is provided by repository fixture in full suite.
    assert isinstance(identity_key(_identity(lane)), str)


def test_new_lanes_identity_isolated(tmp_path):
    hk = _identity("hk_preselection")
    a = _identity("a_stage")
    assert identity_key(hk) != identity_key(a)


def test_unknown_lane_rejected_at_identity():
    with pytest.raises(ValueError, match="DAILY_LANE"):
        identity_key(_identity("unknown_lane"))


def test_identity_shape_not_extended():
    bad = _identity("a_stage")
    bad["extra"] = "forbidden"
    with pytest.raises(Exception):
        identity_key(bad)
