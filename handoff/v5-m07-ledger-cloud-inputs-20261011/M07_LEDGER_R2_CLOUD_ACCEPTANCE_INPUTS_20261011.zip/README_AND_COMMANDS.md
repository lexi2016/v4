# M07 ledger R2 isolated cloud acceptance inputs

This package assembles unchanged Chat-authored R2 code/tests plus exact f7cb runtime dependencies. It does not implement or modify product behavior. All original ten regressions and daily_ledger_fixture.py are preserved byte for byte. The source delta remains only two LANES members.

Source after SHA: d3ba8dc00de2525ccfc2756193be1338bb800c796c2302f6c97f525a76b5748e. Candidate ZIP SHA: 10cce79f5297fb2e1db955aada7efc01a0e79008603994886d5c9a4c29f588ba.

Use a fresh isolated directory in the already authorized cloud environment. Do not modify candidate or original test files; independent acceptance harnesses belong in acceptance/, outside runtime/. Do not deploy, invoke collectors, use credentials, change permissions, call external services, or modify V4.

## Exact existing-suite command

Set P to this package's extracted absolute root, WORK to a fresh writable acceptance directory outside runtime, and PYTHON to the existing Python with pytest. Record exact Python/platform/pytest identities before execution; do not invent results or install new software as an unstated prerequisite.

mkdir -p "$WORK/tmp" "$WORK/logs" "$WORK/acceptance"
PYTHONDONTWRITEBYTECODE=1 TMPDIR="$WORK/tmp" PYTHONPATH="$P/runtime/V5/src:$P/runtime/V5/tests" "$PYTHON" -m pytest -q -p no:cacheprovider "$P/runtime/V5/tests/test_run_ledger.py" "$P/runtime/V5/tests/test_run_ledger_m06_m07_lanes.py" > "$WORK/logs/author-suite.stdout.txt" 2> "$WORK/logs/author-suite.stderr.txt"

Save the actual exit code immediately. The original unittest class has 10 cases; R2's new file has 4 functions, parameterized to 9 cases. Count from actual collection/output. Do not call its function names proof of runtime coverage. Its 'real_claim_finish_read_reuse' test only calls identity_key; claim_run, finish_run, read_run and _success are imported/defined but unused.

## Required independent acceptance, separately reported

The cloud verifier may create its own assertion harness under acceptance/ only, importing the unchanged runtime above. Every case must really invoke claim_run/finish_run/read_run where stated and preserve commands, stdout/stderr/exit and observed state. This is verification, not replacement product code or replacement author tests.

1. For each of all six lanes, use real temporary directories with the exact MARKER, then claim, finish a valid nonempty product_reference with readback_verified=True, read_run, and claim again. Check CLAIMED -> SUCCEEDED -> REUSED_SUCCESS and matching stored identity/reference.
2. Same root and identical other six identity fields, only lane differs: finish hk_preselection successfully, then a_stage must still CLAIMED; finish it with a different reference; read both and check references/attempt lists stay distinct. Repeat in reverse order or a second fresh root.
3. For both new lanes, claim twice before finish: second is IN_PROGRESS_OR_OUTCOME_UNKNOWN and persisted attempt count remains one.
4. For both new lanes, finish failure with retry_safe_without_external_effect=False and verify RETRY_BLOCKED; attempted success with readback_verified=False must raise DAILY_PRODUCT_READBACK_REQUIRED and must not save latest_success.
5. Unknown lane must reject through identity_key and claim_run with DAILY_LANE without creating that lane's record; extra and missing identity fields reject.
6. Re-run/check all original ten regressions, including concurrency, first-create Darwin-race simulation and genuine ENOENT propagation. Linux success is cloud engineering evidence, not proof of Darwin behavior in the user's Mac environment.
7. Hash all runtime files before/after. Keep ledger files only in fresh test roots; no input code/test rewrites, monkeypatching to force success, or silent skipping. Report each reproduced failure directly.

## Patch facts

R2 diff now uses a/V5 and b/V5 prefixes and includes both the ledger delta and new test. Static forward and reverse git apply --check pass with default -p1. The author's -p0 instruction is wrong: both directions fail with b/V5 path not found. Use -p1 on a separate full baseline copy if validating actual patch roundtrip. No patch application or tests were run by the material reviewer.

## Scope and status

ELIGIBLE_FOR_ISOLATED_CLOUD_ENGINEERING_TEST / NOT_RUN. Candidate source is statically retainable, original regression preservation verified. New author tests remain materially incomplete. Successful engineering tests do not mean M06/M07 business production, source admission, publisher/readback integration, UI, natural scheduling or Mac acceptance is complete.
