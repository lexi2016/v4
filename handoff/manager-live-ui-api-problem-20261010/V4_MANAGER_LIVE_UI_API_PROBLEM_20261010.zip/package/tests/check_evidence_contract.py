#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
projection=json.loads((ROOT/'evidence/live_ui_api_problem_projection.json').read_text(encoding='utf-8'))
assert projection['target_trade_date']=='20261009'
assert projection['announcement_publication_date']=='20261008'
assert projection['execution_date']=='20261010'
assert projection['natural_run_verified'] is False

immediate=projection['immediate_owner_refresh_and_readbacks']
later=projection['independent_later_readback']
assert immediate['requests']==['POST','GET','GET']
assert immediate['request_count']=={'GET':2,'POST':1}
assert immediate['plan_status']=='CURRENT'
assert immediate['run_id']==later['run_id']
assert immediate['product_sha256']==later['product_sha256']
assert later['plan_status']=='STALE_INPUTS_CHANGED'
assert later['consumed'] is False
assert later['identity_equal'] is False
assert later['semantic_version_equal'] is True
assert later['date_bindings_equal'] is True
assert later['research_cutoff_equal'] is True
assert later['saved_plan_file_unchanged'] is True
assert later['specific_changed_identity_component']=='CANNOT_CONFIRM'
assert later['response_body_sha256']=='CANNOT_CONFIRM_NOT_PERSISTED'

visual=projection['visual_symptoms']
assert visual['three_channel_summary_visible'] is False
assert visual['target_date']=='20261009' and visual['announcement_date_visible']=='20261008'
assert visual['us_daily_mapping'].startswith('VALID_EMPTY')
assert visual['research_pending_rows']==693 and visual['ledger_gaps']==695
assert visual['raw_observation_rows_before_core_results']==100

frontend=projection['frontend_boundary_review']
assert frontend['review_status']=='REVIEWED'
assert frontend['current_ui_behavior']=='FAIL'
assert 'no ManagerSelection page import/call/render host exists' in frontend['frontend_root_cause']
assert frontend['synthetic_helper_render']['status']=='PASS'
assert frontend['focused_regression_tests']['status']=='NOT_RUN'
assert frontend['loaded_browser_bundle_sha256']=='CANNOT_CONFIRM'
assert frontend['us_field_scopes']['same_scope'] is False

backend=projection['backend_identity_review']
assert backend['confirmed_severity']=='P2'
assert backend['source_ref_count']==1970
assert backend['unique_payload_receipt_pairs']==40
assert backend['all_current_payload_receipt_and_manifest_entries_match_saved_bindings'] is True
assert backend['counterfactual_only_changed_leaf']=='source_refs[*].manifest_sha256'
assert backend['counterfactual_identity_changed'] is True
assert backend['live_stale_unique_cause']=='CANNOT_CONFIRM'

channels=projection['deployed_channel_summary']
assert channels['announcement']['status']=='CANNOT_CONFIRM'
assert channels['hk_connect']['status']=='CANNOT_CONFIRM'
assert channels['oversold']['status']=='PARTIAL'
assert channels['oversold']['pending_count']==693

isolated=projection['corrected_isolated_owner_run']
assert isolated['plan_status']=='PARTIAL' and isolated['stock_count']==0
assert isolated['full_selection']=='CANNOT_CONFIRM'
assert '20261008 panel is present' in isolated['authority_note']
assert 'security-master entry/pointer is absent' in isolated['authority_note']
assert 'NOT_PROVEN' in isolated['screen'] and 'NOT_ATTESTED_BY_PROVIDER' in isolated['screen']

timeline=projection['previous_date_pair_facts']
pair=timeline['target_20261008_publication_20261007']
assert pair['reader_rows']==613 and pair['reviewer_dispositions']==613
assert pair['reviewer_identity_distinct'] is True and pair['selected_count']==33
assert pair['owner_import_status']=='VERIFIED'
assert 'CANNOT_CONFIRM' in timeline['target_20260930']

evidence_manifest=json.loads((ROOT/'evidence/EVIDENCE_MANIFEST.json').read_text(encoding='utf-8'))
evidence_by_path={row['bundle_path']:row for row in evidence_manifest['items']}
expected_independent_evidence={
    'evidence/frontend_boundary_report_20261010.md':'86512f78ce7c292dcbd3821da409dfba8bf23ef818e5accf69ad403b93b02be8',
    'evidence/frontend_boundary_receipt_20261010.json':'5af019b5888330405db196ef455b721f1a04da14351ccb71218e673d55a68ff0',
    'evidence/root_cause_report_20261010.md':'ee5d2976049de6a91d2d09d6eec60a5047816a3b010e99dbe42a136df3e3b0c4',
    'evidence/reproduce_global_manifest_identity_coupling.py':'b57c4635a678bcfdf3fbed123673ffd7ae913bb6d95de4c6fc427a5c7cc5ad60',
    'evidence/global_manifest_identity_counterfactual_receipt.json':'093ded63f330ca25b52b549c8392035b21c9393f566e907a62b32eeae7d1c9fb'
}
for path,expected_sha in expected_independent_evidence.items():
    row=evidence_by_path[path]
    assert row['source_sha256']==expected_sha
    assert row['sha256']==expected_sha
    assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==expected_sha

source=json.loads((ROOT/'SOURCE_SNAPSHOT_MANIFEST.json').read_text(encoding='utf-8'))
assert source['candidate']['source_count_fixed_reference']==16
assert sum(r['source_type']=='fixed_16_source_reference' for r in source['files'])==16

ui=json.loads((ROOT/'evidence/UI_VISUAL_INSPECTION_20261010.json').read_text(encoding='utf-8'))
for item in ui['screenshots']:
    f=ROOT/'evidence'/item['filename']
    assert f.is_file()
    assert hashlib.sha256(f.read_bytes()).hexdigest()==item['sha256']

for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    assert p.suffix.lower() not in {'.csv','.parquet','.db','.sqlite','.plist','.pyc'}
    assert p.stat().st_size<=2_000_000
print('REAL_EVIDENCE_CONTRACT=PASS; no live owner/API/UI behavior was exercised')
