#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
import json
import stat
import zipfile
from pathlib import Path

PACKAGE=Path(__file__).resolve().parents[1]
OUTPUT_ROOT=PACKAGE.parent
ZIP_PATH=OUTPUT_ROOT/'ZIP'/'V4_MANAGER_LIVE_UI_API_PROBLEM_20261010.zip'
PACKAGE_MANIFEST=PACKAGE/'PACKAGE_FILE_MANIFEST.json'
SOURCE_MANIFEST=PACKAGE/'SOURCE_SNAPSHOT_MANIFEST.json'
EVIDENCE_MANIFEST=PACKAGE/'evidence'/'EVIDENCE_MANIFEST.json'
FORBIDDEN_SUFFIXES={'.csv','.parquet','.db','.sqlite','.pyc','.plist'}

def sha(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()

def file_sha(path:Path)->str:
    return sha(path.read_bytes())

def package_entries()->list[dict]:
    rows=[]
    for path in sorted(PACKAGE.rglob('*')):
        if not path.is_file() or path==PACKAGE_MANIFEST:
            continue
        rel=path.relative_to(PACKAGE).as_posix()
        if path.suffix.lower() in FORBIDDEN_SUFFIXES:
            raise SystemExit('FORBIDDEN_PACKAGE_FILE:'+rel)
        if path.stat().st_size>2_000_000:
            raise SystemExit('OVERSIZE_PACKAGE_FILE:'+rel)
        rows.append({'path':rel,'bytes':path.stat().st_size,'sha256':file_sha(path)})
    return rows

def verify_snapshot_manifest(path:Path,entries_key:str='files')->None:
    data=json.loads(path.read_text(encoding='utf-8'))
    rows=data[entries_key]
    for row in rows:
        f=PACKAGE/row['bundle_path']
        if not f.is_file():
            raise SystemExit('SNAPSHOT_MISSING:'+row['bundle_path'])
        actual=file_sha(f)
        if actual!=row['bundle_sha256'] or actual!=row['source_sha256']:
            raise SystemExit('SNAPSHOT_SHA_MISMATCH:'+row['bundle_path'])
    print(f'{path.name}=PASS ({len(rows)} files)')

def verify_evidence_manifest()->None:
    data=json.loads(EVIDENCE_MANIFEST.read_text(encoding='utf-8'))
    listed={row['bundle_path']:row for row in data['items']}
    actual={p.relative_to(PACKAGE).as_posix() for p in (PACKAGE/'evidence').rglob('*') if p.is_file() and p!=EVIDENCE_MANIFEST}
    if actual!=set(listed):
        raise SystemExit('EVIDENCE_MANIFEST_PATH_MISMATCH')
    for rel,row in listed.items():
        p=PACKAGE/rel
        if p.stat().st_size!=row['bytes'] or file_sha(p)!=row['sha256']:
            raise SystemExit('EVIDENCE_SHA_MISMATCH:'+rel)
    if data.get('raw_response_body_included') is not False:
        raise SystemExit('RAW_RESPONSE_BOUNDARY_INVALID')
    print(f'EVIDENCE_MANIFEST=PASS ({len(listed)} files)')

def write_package_manifest()->None:
    data={'schema_version':'v4.manager.live_ui_api_problem_package_files.v1','files':package_entries()}
    PACKAGE_MANIFEST.write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

def write_zip()->None:
    ZIP_PATH.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(ZIP_PATH,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(PACKAGE.rglob('*')):
            if not p.is_file(): continue
            rel='package/'+p.relative_to(PACKAGE).as_posix()
            info=zipfile.ZipInfo(rel,date_time=(2026,10,10,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=(stat.S_IFREG|0o644)<<16
            z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)

def verify_zip()->None:
    data=json.loads(PACKAGE_MANIFEST.read_text(encoding='utf-8'))
    expected={r['path']:r for r in data['files']}
    expected['PACKAGE_FILE_MANIFEST.json']={'bytes':PACKAGE_MANIFEST.stat().st_size,'sha256':file_sha(PACKAGE_MANIFEST)}
    with zipfile.ZipFile(ZIP_PATH) as z:
        names=z.namelist()
        actual={n.removeprefix('package/') for n in names}
        if actual!=set(expected):
            raise SystemExit('ZIP_MEMBER_SET_MISMATCH')
        for name in names:
            rel=name.removeprefix('package/')
            payload=z.read(name); row=expected[rel]
            if len(payload)!=row['bytes'] or sha(payload)!=row['sha256']:
                raise SystemExit('ZIP_MEMBER_SHA_MISMATCH:'+rel)
    print('ZIP_CONSISTENCY=PASS')

def main()->None:
    ap=argparse.ArgumentParser()
    ap.add_argument('--build-zip',action='store_true')
    args=ap.parse_args()
    verify_snapshot_manifest(SOURCE_MANIFEST)
    verify_evidence_manifest()
    if args.build_zip:
        write_package_manifest()
        write_zip()
    if not PACKAGE_MANIFEST.exists():
        raise SystemExit('PACKAGE_FILE_MANIFEST_MISSING')
    current=package_entries()
    recorded=json.loads(PACKAGE_MANIFEST.read_text(encoding='utf-8'))['files']
    if current!=recorded: raise SystemExit('PACKAGE_FILE_MANIFEST_MISMATCH')
    print('PACKAGE_FILES='+str(len(recorded)+1))
    if ZIP_PATH.is_file():
        verify_zip()
        print('ZIP_SHA256='+file_sha(ZIP_PATH))
        print('ZIP_BYTES='+str(ZIP_PATH.stat().st_size))
    else:
        print('ZIP_CONSISTENCY=NOT_AVAILABLE (no sibling ZIP; package file manifest verified)')

if __name__=='__main__':
    main()
