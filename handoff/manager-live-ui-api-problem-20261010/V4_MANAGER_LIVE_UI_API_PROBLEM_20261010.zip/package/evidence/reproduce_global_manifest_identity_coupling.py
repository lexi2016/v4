#!/usr/bin/env python3
"""Offline reviewer reproduction of global-manifest fingerprint coupling.

Reads the saved 20261009 plan, the exact current V35 research archive root,
and frozen candidate projection code. It never writes to business state,
starts services, or performs owner/API calls. The only output is a reviewer
receipt beside this script.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

PLAN = Path(
    "/Users/lexi/Library/Application Support/com.lexi.v4.local/state/manager_auto_research/"
    "workspace_plans/20261009/3bc75d1beea24036850b1af0f4d5f395.json"
)
APP = Path(
    "/Users/lexi/Desktop/学习/agents调试/V4_MANAGER_OWNER_INPUT_INTEGRATION_MAC_20261010_R1/"
    "candidate/stage_r4_manager_r2_owner_input_r1_fused_r1/app"
)
DATA_ROOT = Path("/Users/lexi/Library/Application Support/com.lexi.v35.local/state/data")
OUT_DIR = Path(__file__).resolve().parent
RECEIPT = OUT_DIR / "global_manifest_identity_counterfactual_receipt.json"
EXPECTED_PLAN_SHA = "42ffe059781333dddaf5dead93416ae168b7a90fa265b178a8912441d79f3d12"
EXPECTED_OLD_GLOBAL_SHA = "c8a8fc7f1fe654d7f700c960ead60fce1dd075c9999a3ad1b98932dcc180dcc4"
EXPECTED_CURRENT_GLOBAL_SHA = "864e1f6d789e9a8a9b2614ac2534f6e4cdce55ccc46242fefba7203f1fed6e31"

SOURCE_FILES = {
    "research_lane_source.py": APP / "infrastructure/research_lane_source.py",
    "existing_materials.py": APP / "v4/manager_research/existing_materials.py",
    "workspace_projection.py": APP / "v4/manager_research/workspace_projection.py",
    "workspace.py": APP / "v4/manager_research/workspace.py",
}


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def strip_only_global_fingerprint(material: Any) -> Any:
    value = copy.deepcopy(material)
    refs = value.get("source_refs", []) if isinstance(value, dict) else []
    if isinstance(refs, list):
        for ref in refs:
            if isinstance(ref, dict):
                ref.pop("manifest_sha256", None)
    return value


def main() -> None:
    if not PLAN.is_file():
        raise FileNotFoundError(f"saved plan missing: {PLAN}")
    if not (DATA_ROOT / "manifest.json").is_file():
        raise FileNotFoundError(f"current manifest missing: {DATA_ROOT / 'manifest.json'}")
    for name, path in SOURCE_FILES.items():
        if not path.is_file():
            raise FileNotFoundError(f"candidate source missing: {name}: {path}")

    plan_bytes = PLAN.read_bytes()
    plan = json.loads(plan_bytes)
    materials = plan["workspace"]["materials"]
    if not isinstance(materials, list) or not materials:
        raise AssertionError("saved plan materials absent")

    manifest_path = DATA_ROOT / "manifest.json"
    manifest_bytes = manifest_path.read_bytes()
    current_manifest_sha = sha_bytes(manifest_bytes)
    current_manifest = json.loads(manifest_bytes)

    old_global_shas = set()
    unique_bindings: dict[tuple[str, str], dict[str, Any]] = {}
    source_ref_count = 0
    for material in materials:
        refs = material.get("source_refs") or []
        if not isinstance(refs, list):
            raise AssertionError("source_refs is not a list")
        for ref in refs:
            source_ref_count += 1
            if ref.get("manifest_sha256"):
                old_global_shas.add(ref["manifest_sha256"])
            key = (str(ref.get("payload_path", "")), str(ref.get("receipt_path", "")))
            unique_bindings.setdefault(key, ref)

    if old_global_shas != {EXPECTED_OLD_GLOBAL_SHA}:
        raise AssertionError(f"unexpected saved global manifest SHAs: {sorted(old_global_shas)}")
    if current_manifest_sha != EXPECTED_CURRENT_GLOBAL_SHA:
        raise AssertionError(f"current global manifest SHA drift: {current_manifest_sha}")

    leaves = []
    for (payload_rel, receipt_rel), ref in sorted(unique_bindings.items()):
        if not payload_rel or not receipt_rel:
            raise AssertionError("incomplete saved payload/receipt binding")
        if Path(str(ref.get("source_root", ""))).resolve() != DATA_ROOT.resolve():
            raise AssertionError(f"unexpected source root for {payload_rel}")
        payload_sha_saved = str(ref.get("payload_sha256", ""))
        receipt_sha_saved = str(ref.get("receipt_sha256", ""))
        payload_path = DATA_ROOT / payload_rel
        receipt_path = DATA_ROOT / receipt_rel
        payload_sha_current = sha_file(payload_path)
        receipt_sha_current = sha_file(receipt_path)
        manifest_entry_sha = str(current_manifest.get(payload_rel, ""))
        if payload_sha_current != payload_sha_saved:
            raise AssertionError(f"payload bytes changed: {payload_rel}")
        if receipt_sha_current != receipt_sha_saved:
            raise AssertionError(f"receipt bytes changed: {receipt_rel}")
        if manifest_entry_sha != payload_sha_saved:
            raise AssertionError(f"current manifest entry changed: {payload_rel}")
        leaves.append({
            "payload_path": payload_rel,
            "payload_sha256_saved_and_current": payload_sha_saved,
            "receipt_path": receipt_rel,
            "receipt_sha256_saved_and_current": receipt_sha_saved,
            "current_manifest_entry_sha256": manifest_entry_sha,
            "saved_global_manifest_sha256": ref.get("manifest_sha256"),
            "source_date": ref.get("source_date"),
        })

    # This is a controlled copy-only mutation: the sole edited leaf is the
    # whole-manifest provenance value in each already-consumed source ref.
    variant = copy.deepcopy(materials)
    replacement_global_sha = current_manifest_sha
    changed_ref_count = 0
    for material in variant:
        for ref in material.get("source_refs") or []:
            if ref.get("manifest_sha256") != replacement_global_sha:
                ref["manifest_sha256"] = replacement_global_sha
                changed_ref_count += 1

    if source_ref_count != changed_ref_count:
        raise AssertionError(
            f"not every source ref was changed once: refs={source_ref_count}, changed={changed_ref_count}"
        )
    for before, after in zip(materials, variant):
        if canonical_bytes(strip_only_global_fingerprint(before)) != canonical_bytes(
            strip_only_global_fingerprint(after)
        ):
            raise AssertionError("non-manifest material leaf changed in counterfactual")

    # Execute the exact candidate projection function twice with all other
    # function arguments held fixed. The material array is the only input that
    # differs, and its only changed leaf is the registry-wide fingerprint.
    sys.path.insert(0, str(APP))
    try:
        from v4.manager_research.workspace_projection import build_workspace
    finally:
        sys.path.pop(0)
    fixed_args = {"catalyst": {}, "stage": None, "close": None}
    base_projection = build_workspace("20261009", materials=materials, **fixed_args)
    variant_projection = build_workspace("20261009", materials=variant, **fixed_args)
    base_identity = str(base_projection["input_identity"])
    variant_identity = str(variant_projection["input_identity"])
    if not base_identity or not variant_identity or base_identity == variant_identity:
        raise AssertionError("candidate input identity did not respond to global fingerprint change")

    focus = materials[0]
    focus_ref = (focus.get("source_refs") or [{}])[0]
    focus_leaf = {
        "material_id": focus.get("material_id"),
        "archive_date": focus.get("archive_date"),
        "available_at": focus.get("available_at"),
        "source_kind": focus.get("source_kind"),
        "source_row_sha256": sha_bytes(canonical_bytes(focus.get("source_row"))),
        "payload_path": focus_ref.get("payload_path"),
        "payload_sha256": focus_ref.get("payload_sha256"),
        "source_date": focus_ref.get("source_date"),
        "saved_global_manifest_sha256": focus_ref.get("manifest_sha256"),
    }
    receipt = {
        "status": "PASS_COUNTERFACTUAL_GLOBAL_MANIFEST_COUPLING",
        "evidence_kind": "OFFLINE_DERIVED_COPY_ONLY_MECHANISM_REPRODUCTION",
        "plan_path": str(PLAN),
        "plan_sha256": sha_bytes(plan_bytes),
        "expected_plan_sha256": EXPECTED_PLAN_SHA,
        "target_trade_date": plan.get("target_trade_date"),
        "run_id": plan.get("run_id"),
        "saved_material_count": len(materials),
        "source_ref_count": source_ref_count,
        "unique_payload_receipt_pairs": len(leaves),
        "all_current_payload_receipt_and_manifest_entries_match_saved_bindings": True,
        "saved_global_manifest_sha256": EXPECTED_OLD_GLOBAL_SHA,
        "current_manifest_path": str(manifest_path),
        "current_global_manifest_sha256": current_manifest_sha,
        "current_manifest_entry_count": len(current_manifest),
        "old_global_manifest_raw_bytes_retained": False,
        "old_manifest_semantic_delta_scope": "CANNOT_CONFIRM",
        "focus_real_material_leaf": focus_leaf,
        "counterfactual": {
            "only_changed_material_leaf": "source_refs[*].manifest_sha256",
            "replacement_fingerprint": replacement_global_sha,
            "changed_source_ref_count": changed_ref_count,
            "payload_sha_date_available_at_source_row_content_unchanged": True,
            "candidate_projection_function": "v4.manager_research.workspace_projection.build_workspace",
            "fixed_projection_arguments": {"target_trade_date": "20261009", **fixed_args},
            "base_input_identity": base_identity,
            "counterfactual_input_identity": variant_identity,
            "identity_changed": True,
            "interpretation": "The existing candidate identity chain is sensitive to a registry-wide manifest fingerprint even when all saved consumed payload and receipt bytes, entry hashes, dates, available_at values, and material content are held fixed. This proves a coupling mechanism; it does not prove the sole historical cause of the live stale readback.",
        },
        "current_leaf_comparison": leaves,
        "candidate_source_sha256": {name: sha_file(path) for name, path in SOURCE_FILES.items()},
        "side_effects": {
            "api_calls": 0,
            "service_started": False,
            "business_state_written": False,
            "real_materials_mutated": False,
            "derived_material_copy_mutated_only_manifest_sha": True,
        },
    }
    RECEIPT.write_bytes(canonical_bytes(receipt) + b"\n")
    print(json.dumps({
        "receipt_path": str(RECEIPT),
        "receipt_sha256": sha_file(RECEIPT),
        "status": receipt["status"],
        "plan_sha256": receipt["plan_sha256"],
        "saved_material_count": len(materials),
        "source_ref_count": source_ref_count,
        "unique_payload_receipt_pairs": len(leaves),
        "old_manifest_sha256": EXPECTED_OLD_GLOBAL_SHA,
        "current_manifest_sha256": current_manifest_sha,
        "base_input_identity": base_identity,
        "counterfactual_input_identity": variant_identity,
        "identity_changed": base_identity != variant_identity,
    }, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
