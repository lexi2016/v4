# Frontend boundary review — 2026-10-10

**Result:** REVIEWED. The daily three-channel renderer exists in the candidate source but is not connected to the ManagerSelection page render path. The captured UI result is UI_VERIFIED=FAIL. This is a P2 user-visible omission; I found no evidence that it changes Stage, selection, BUY, or order behavior.

## Evidence and root cause

The E1 browser capture is the real in-app route /manager-selection/?date=20261009 with view dynamic, and records the corresponding GET to /api/v4/manager/research/workspace?date=20261009&view=dynamic. It reports three_channel_summary_visible=false, a stale plan, 693 pending research rows, 695 ledger gaps, and 100 raw observation rows before the main result sections. The main, US-mapping, and pending screenshots have SHA-256 values f8039d009dce035b9d405512dc57744f3901354537269552e4b6c5a95a0bd616, ad8216d470cb28e670fdf9d22506e74631414197d595aea34b7dc239344ec249, and 3fa782e4d087cb57fba171aaf09600f48a7d09b051cc7d88262e1d713f4399c9. The inspection JSON SHA-256 is 11c9b3b5ad9b586094364ee021838f66e621b17036f42f398be0324b83886ac2.

In the E1 candidate, apps/web/dist/manager-selection/index.html (SHA-256 d253e028e0300fb2cca647808b9ee6a224e309b6e1da6a520bdac188b8371f89) loads /assets/managerSelection-BeTXz3Ut.js (SHA-256 e1c820b3abeafb8c6d3b5f4e722a8d921f41406baf1bf4a01db2e2e44c78876f). The page entry apps/web/src/manager-selection/main.ts:1-5 mounts ManagerSelectionView at #manager-selection. ManagerSelectionView.vue:81,2750-2755,2778 imports/mounts only mountCatalystObservations into the catalyst host.

The response contract already has optional ManagerWorkspace.daily_channels at apps/web/src/api/managerWorkspace.ts:191; validateManagerWorkspace validates the field when date bindings are present (1635-1641). The E1 source reference maps this API file SHA 2c02d4cff38d749fcad91b892da83029c8269287fbb867a2216f09ef8aa2c43f to commit c0fc35c7b39502f49e43c2e75139dad7822091cf.

apps/web/src/manager-selection/dailyChannels.ts:190-229 defines renderDailyChannels and validates/builds the heading and three channel cards. Its SHA is c60254b69de369c8b50ef0ffa14dd49c802a3ae56ac4266dd9fe5f39ea40fecc, also mapped by E1 to commit c0fc35c7b39502f49e43c2e75139dad7822091cf. A source-wide search found only the helper definition: no component imports or calls it. In catalystObservationPanel.ts, the imports at lines 1-14 omit it; render(value) at lines 463-467 passes research attention, market attention, selection diagnostics, and US mapping to their renderers, but never passes value.daily_channels. The candidate bundle contains four daily_channels validator references but contains neither renderDailyChannels nor the visible label 每日三路研究结果. This is a renderer wiring omission, not a v-if or stale-plan gate. The stale plan is displayed separately by the plan/business status renderer.

I imported the actual candidate TypeScript helper with Node v24.19.0 --experimental-strip-types and an in-memory minimal DOM shim. A synthetic, valid three-channel payload produced the accessible label and heading 每日三路研究结果 and three CANNOT_CONFIRM cards. This only establishes that the helper can render when called; it does not substitute for the missing page call or verify live API data. A focused source search found no test exercising renderDailyChannels; no repository test suite was run in this read-only diagnosis.

## Upper and lower US fields

The upper 美股：尚未评估 business-status row is calculated by businessStatusRows (businessStatus.ts:8-21,48-52,105-110,154-159). It derives the label from research_attention.us_mapping_diagnostics or the legacy us_market_attention.mapping_diagnostics and its assessment_state / accepted relation count. NOT_EVALUATED maps to 尚未评估. The US snapshot status is used in supporting source-detail text, not as this assessment label.

The lower card is a separate projection: catalystObservationPanel.ts:466-467 passes value.us_mapping_research to renderResearchAttention; researchAttention.ts:209-221 reads mapping.daily_run.status and scopes VALID_EMPTY to the reviewed daily mapping set (the captured card says four reviewed relations, zero matches, limited scope). Therefore the upper and lower US states are not contradictory evidence about the same population. The upper label 美股 is generic and can look inconsistent at a glance; preserving explicit “assessment/completeness” versus “daily US-to-HK reviewed mapping” scope labels will avoid that ambiguity.

The current panel places researchAttentionSection after the stock and background sections in its append order (catalystObservationPanel.ts:151-165). That matches the E1 capture’s result cards appearing after a long observation list. The missing three-channel summary is more fundamental: it has no call site and so cannot appear lower down either.

## Review limits and next acceptance

SOURCE_REFERENCES.json binds the API client and channel helper hashes, but does not record the browser-loaded SHA for ManagerSelectionView.vue, catalystObservationPanel.ts, or the compiled JavaScript. The candidate build artifact is identified above; exact equality between those bytes and the browser-loaded asset is CANNOT_CONFIRM from the supplied capture. I issued no GET, POST, owner run, or service command.

For the recipient patch, the minimum behavioral acceptance is to wire the existing helper into the existing panel render using the validated daily_channels and its explicit date bindings, place the summary before the long result rows, and keep it independent of plan_product.status. Then test the visible heading, all three channel states, and date bindings on synthetic complete, partial, and unavailable inputs. The live capture’s plan identity cause remains the separate CANNOT_CONFIRM result already recorded by the runtime review; this frontend analysis does not identify or alter it.

## Findings

- **P2 — Daily three-channel summary is not mounted.** Exact evidence: dailyChannels.ts:190 defines the renderer; catalystObservationPanel.ts:463-467 omits the daily_channels field and renderer; the candidate bundle omits the renderer label. User-visible result: the captured page has no summary despite the existing response field contract.
- **P2 — Existing US mapping result sits after the long stock/background area.** Exact evidence: catalystObservationPanel.ts:151-165 appends it after stocks and background; E1 capture records 100 raw observation rows before the main result sections.
- **P0/P1 — None found in this frontend-only scope.** The observed defect is a display/wiring issue; no change to selection or BUY behavior is established.
