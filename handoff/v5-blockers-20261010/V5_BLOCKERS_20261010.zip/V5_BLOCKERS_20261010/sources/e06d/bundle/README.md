# 公告预算、HTTP 门禁与 V5 私有 owner 候选

最新：不可变显式决策修订见 [DECISION_REVISION.md](DECISION_REVISION.md)。保留旧产品、同批捕获 run 和恢复 SHA，复用原决策校验/聚合；新增 10 项 Mac 回归候选 NOT_RUN。续读有效状态合并等待真实脱敏合同，本增量不清除门禁。以下为历史记录。

本地最新候选：离线恢复后的 analysis 合同与私有 prepare→注册→验证→导入→读回，见 [OFFLINE_ANALYSIS_CHAIN.md](OFFLINE_ANALYSIS_CHAIN.md)。原 81 项测试逐字不变，新增 7 项待 Mac；本轮未运行产品测试；候选交由既有独立分支固定提交供 Mac 验收。下文为历史交付记录。

当前真实离线恢复遇到失败正文已保留页面合同差异；修复说明见 [FAILED_PARTIAL_PAGES.md](FAILED_PARTIAL_PAGES.md)。保留失败状态/原页面/原错误，新增 11 项候选未运行；V4 和旧证据不变。

最新：780 Mac 恢复测试 13 PASS / 2 FAIL 的 fixture 顺序修复候选见 [RECOVERY_FIXTURE_ORDER.md](RECOVERY_FIXTURE_ORDER.md)。失败预期仍为 1；生产代码未改，待 Mac 单次复验。

最新恢复入口身份加固见 [RECOVERY_IDENTITY_FIX.md](RECOVERY_IDENTITY_FIX.md)。新增原 app 与 identity SHA 必需参数；恢复用例 15 项、总计 70 项待 Mac。以下为历史背景。

当前阶段：874 Mac 55 PASS 后发现真实字节序列化缺陷；只做离线恢复，见 [OFFLINE_RECOVERY.md](OFFLINE_RECOVERY.md)。原 55 项不变，新增 7 项候选，共 62 项；新测试尚未执行。旧 BLOCKED 与证据必须保留，禁止重采。以下为历史交付背景。

最新为 db871765 之后的三项静态审查修复，见 [ISOLATION_REVIEW_FIX.md](ISOLATION_REVIEW_FIX.md)。原 47 项测试未改，新增 8 项，总计 55 项待 Mac 验收。当前五个完整候选包含新增原 CLI IO 接缝；以下为前轮背景。

状态：**IMPLEMENTED_MAC_REVALIDATION_PENDING**。云端只写代码并做静态语法、来源和哈希核验；未执行产品测试、未采集或部署。当前完整交付及 Mac 命令见 [HTTP_OWNER_FIX.md](HTTP_OWNER_FIX.md)。

父任务报告：79fcdf81be908169ca4f1db331899f07d94a0f65 的既有 31 项 Mac 回归通过；8124c9f6cb35ca4385c2e73bcd55482ee8a7bfa8 的 HTTP RED 为 1 PASS / 8 FAIL / 0 ERROR，exit 1。本轮基于该实际 RED 实现 HTTP 策略，既有 40 项测试文件逐字未改，另加 7 项离线私有 owner 验收候选。不能把这些待跑用例写成已通过。

完整生产候选位于 `candidate/`：原 body_batch、announcement_source、hkex_provider 三文件及新增 `ops/run_v5_private_announcement.py`。`pinned/` 和 SOURCE_MANIFEST.json 保持不变，固定原源 0fd5eb374cb155232ed003d5fc4d0d3594252491；OWNER_SOURCE_MANIFEST.json 和 OWNER_DEPENDENCIES.json 固定 0382f753929365048d231a7252d9c328d40f8522 的原成功链依赖，不读取 main 当前版本。

仅修改独立 handoff 目录。未修改主任务 manager_plan、workspace、UI 或 V4 运行文件；owner_dependencies 中 workspace 文件是按清单复制的原样依赖，不是主任务源码变更。V5 初始开发基线 945b89d7c3411a4913f50c4472514a61676c621e；本轮候选差异基线 8124c9f6cb35ca4385c2e73bcd55482ee8a7bfa8。本轮不推分支，由父任务转移固定候选。

历史材料 REVIEW_RED.md、REVIEW_FIX.md、HTTP_POLICY_RED.md 记录对应阶段，当前命令和状态以 HTTP_OWNER_FIX.md 为准。
