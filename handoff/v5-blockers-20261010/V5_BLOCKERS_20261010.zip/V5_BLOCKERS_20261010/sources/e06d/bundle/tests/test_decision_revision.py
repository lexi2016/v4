"""Mac-only synthetic regression candidates for immutable decision revisions."""
import importlib.util
import json
from pathlib import Path
import sys
import unittest

spec = importlib.util.spec_from_file_location('revision_chain_support', Path(__file__).with_name('test_offline_analysis_chain.py'))
support = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = support
spec.loader.exec_module(support)
from v4.manager_research.workspace_projection import digest


class DecisionRevisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        support.OfflineAnalysisChainTests.setUpClass()

    @classmethod
    def tearDownClass(cls):
        support.OfflineAnalysisChainTests.tearDownClass()

    def setUp(self):
        self.fixture = support.OfflineAnalysisChainTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.fixture.register()
        self.fixture.owner.execute(['import'])
        self.parent = self.fixture.derived
        self.product = self.fixture.product()
        self.parent_sha = self.product['sha256']
        self.receipt_path = self.parent / 'workspace_announcements/20261009/eastmoney_date_catalog/20261008/owner_import_receipt.v1.json'
        self.receipt_sha = support.sha(self.receipt_path.read_bytes())
        self.old = {str(p.relative_to(self.parent)): p.read_bytes() for p in self.parent.rglob('*') if p.is_file()}
        self.inputs = self.parent / 'revision_inputs'
        self.inputs.mkdir()
        self.semantic = self.inputs / 'semantic.json'
        self.semantic.write_bytes(self.fixture.semantic.read_bytes())
        decisions = []
        for row in self.product['records']:
            failed = row['body_status'] == 'BODY_CAPTURE_FAILED'
            decisions.append(dict(art_code=row['art_code'], issuer_codes=[x['code'] for x in row['issuer_codes']],
                security_scope=row['security_scope'], semantic_record_sha256=row['semantic_record_sha256'],
                body_record_sha256=row['body_record_sha256'], disposition='NOT_ASSESSED' if failed else 'SELECTED_EVENT',
                selection_basis='NOT_ASSESSED' if failed else 'OPERATING_EVENT',
                reason='Synthetic fixture only: preserve failure' if failed else 'Synthetic fixture only: explicitly selected', risk_notes=[]))
        decisions.sort(key=lambda x: x['art_code'])
        self.decisions = self.inputs / 'decisions.json'
        support.dump(self.decisions, {'article_decisions': decisions})
        reviewer = json.loads(self.fixture.reviewer.read_bytes())
        reviewer.update(decision_status='EXPLICIT_DISPOSITIONS', decision_payload_sha256=digest(decisions),
            decision_revision=dict(revision_id='decision-r1', parent_product_sha256=self.parent_sha,
                parent_owner_receipt_file_sha256=self.receipt_sha, source_recovery_receipt_sha256=self.fixture.recovery_sha,
                source_run_id=self.fixture.run_id))
        self.reviewer = self.inputs / 'reviewer.json'
        support.dump(self.reviewer, reviewer)

    def tearDown(self):
        for name, raw in self.old.items():
            self.assertEqual((self.parent / name).read_bytes(), raw, name)
        self.fixture.tearDown()

    def create(self, **overrides):
        from ops.run_v5_decision_revision import create_revision
        args = dict(parent_root=self.parent, recovery_sha256=self.fixture.recovery_sha, revision_id='decision-r1',
            parent_product_sha256=self.parent_sha, parent_receipt_sha256=self.receipt_sha,
            semantic_catalog=self.semantic, semantic_sha256=support.sha(self.semantic.read_bytes()),
            reviewer_output=self.reviewer, reviewer_sha256=support.sha(self.reviewer.read_bytes()),
            decisions=self.decisions, decisions_sha256=support.sha(self.decisions.read_bytes()))
        args.update(overrides)
        return create_revision(**args)

    def register(self, owner):
        return owner.execute(['register-handoff', '--parent-task-id', 'synthetic-revision-task',
            '--reader-identity', 'fixture-reader', '--reviewer-identity', 'fixture-independent-reviewer'])

    def test_new_decision_import_preserves_old_product_and_same_capture_run(self):
        owner = self.create()
        self.register(owner)
        self.assertEqual(owner.execute(['verify'])['status'], 'REGISTERED_HANDOFF_VERIFIED')
        result = owner.execute(['import'])
        binding = result['manager_binding']
        self.assertEqual(binding['decision_revision']['parent_product_sha256'], self.parent_sha)
        self.assertNotEqual(binding['product_sha256'], self.parent_sha)
        self.assertEqual(binding['evidence_run_id'], self.fixture.run_id)
        readback = owner.get_announcement_analysis('20261009', '2026-10-08')
        self.assertEqual(readback['analysis']['stock_selection']['article_count'], 2)
        self.assertEqual(readback['analysis']['stock_selection']['selected_stock_count'], 1)
        self.assertEqual(len(readback['analysis']['stock_selection']['article_decisions']), 2)
        self.assertEqual(owner.execute(['readback'])['status'], 'OWNER_READBACK_VERIFIED')
        self.assertEqual((owner.root / 'source_recovery_receipt.json').read_bytes(), (self.parent / 'recovery_receipt.json').read_bytes())
        self.assertEqual((owner.root / self.fixture.prefix / 'capture_receipt.json').read_bytes(),
                         (self.parent / self.fixture.prefix / 'capture_receipt.json').read_bytes())

    def test_wrong_parent_product_or_receipt_pin_is_rejected(self):
        for name in ('parent_product_sha256', 'parent_receipt_sha256'):
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'REVISION_PARENT'):
                self.create(**{name: '0' * 64})

    def test_wrong_input_file_sha_is_rejected(self):
        for name in ('semantic_sha256', 'reviewer_sha256', 'decisions_sha256'):
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'REVISION_INPUT_SHA'):
                self.create(**{name: '0' * 64})

    def test_old_or_wrong_revision_reviewer_is_rejected(self):
        value = json.loads(self.reviewer.read_bytes())
        value['decision_revision']['parent_product_sha256'] = '0' * 64
        support.dump(self.reviewer, value)
        with self.assertRaisesRegex(ValueError, 'REVISION_REVIEW_BINDING'):
            self.create()

    def test_wrong_reviewer_decision_payload_sha_is_rejected(self):
        value = json.loads(self.reviewer.read_bytes())
        value['decision_payload_sha256'] = '0' * 64
        support.dump(self.reviewer, value)
        with self.assertRaisesRegex(ValueError, 'REVISION_EXPLICIT_DECISIONS_REVIEW_REQUIRED'):
            self.create()

    def test_failed_body_cannot_be_selected_by_revision(self):
        document = json.loads(self.decisions.read_bytes())
        failed = next(row for row in document['article_decisions'] if row['disposition'] == 'NOT_ASSESSED')
        failed.update(disposition='SELECTED_EVENT', selection_basis='OPERATING_EVENT')
        support.dump(self.decisions, document)
        reviewer = json.loads(self.reviewer.read_bytes())
        reviewer['decision_payload_sha256'] = digest(document['article_decisions'])
        support.dump(self.reviewer, reviewer)
        owner = self.create()
        with self.assertRaisesRegex(ValueError, 'UNASSESSED_CONTENT_SELECTION_MUST_BE_NOT_ASSESSED'):
            self.register(owner)
        self.assertFalse((owner.root / 'manager_binding.v1.json').exists())

    def test_revision_id_reuse_never_overwrites(self):
        owner = self.create()
        before = (owner.root / 'decision_revision.json').read_bytes()
        with self.assertRaises((ValueError, FileExistsError)):
            self.create()
        self.assertEqual((owner.root / 'decision_revision.json').read_bytes(), before)

    def test_copied_source_tampering_is_rejected_before_registration(self):
        owner = self.create()
        path = owner.root / self.fixture.prefix / 'body_corpus.json'
        path.write_bytes(path.read_bytes() + b' ')
        with self.assertRaisesRegex(ValueError, 'REVISION_SOURCE_CHANGED'):
            self.register(owner)

    def test_changed_decision_input_is_rejected_before_registration(self):
        owner = self.create()
        path = owner.root / 'inputs/article_decisions.json'
        path.write_bytes(path.read_bytes() + b' ')
        with self.assertRaisesRegex(ValueError, 'REVISION_INPUT_CHANGED'):
            self.register(owner)

    def test_capture_and_input_overrides_are_rejected(self):
        owner = self.create()
        for argv in (['capture'], ['register-handoff', '--decisions', str(self.decisions)],
                     ['import', '--api-base', 'http://127.0.0.1:8873']):
            with self.subTest(argv=argv), self.assertRaises(ValueError):
                owner.execute(argv)


if __name__ == '__main__':
    unittest.main(verbosity=2)
