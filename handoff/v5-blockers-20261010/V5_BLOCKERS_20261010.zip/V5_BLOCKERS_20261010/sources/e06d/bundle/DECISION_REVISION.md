# 不可变显式决策修订

基线：1a699a040c0b2cd467726bca5ccc7847182cb975。父任务已报告同 run 新 handoff 拒绝、旧产品路径导入报 ANNOUNCEMENT_ANALYSIS_PRODUCT_EXISTS；旧产品 e724d07b39e5b4fb3ccbb0b4536f4519b4badbfd3783cad7ee6506a7af242ad6 没有 stock_selection、article_decision_count=0。这是本次实现依据的实际失败证据；新增自动回归仅候选，云端未运行。

## 交付边界

新增 ops/run_v5_decision_revision.py；原 offline owner 仅加入可覆盖的证据验证和绑定来源方法。保留原 import_product 的不可覆盖规则、原 handoff 注册规则、make_extension、逐篇决策校验和股票聚合实现。没有改经理主分支/UI，没有默认选股算法，也没有生成真实判断。

新版根是已有恢复根下 decision_revisions/<revision_id>。这是决策修订身份，不是新的捕获 run。announcement_agent_runs/<原 source_run_id>/evidence 中的 catalog/body/capture 等字节按原 recovery_receipt 的完整 recovered_files 清单复制并每次验证；捕获回执原 run 完全不变。不生成 v5_owner_identity 或伪造新 recovery_receipt。source_recovery_receipt.json 是原回执逐字副本，parent_analysis.v1.json 和 parent_owner_import_receipt.v1.json 是父版本逐字副本。

decision_revision.json 绑定父产品逻辑 SHA、父 owner receipt 文件 SHA、原 recovery receipt 文件 SHA、原 source_run_id、新版 ID、固定 app SHA 和三项输入文件 SHA。每次命令校验原父产品、owner receipt、registered handoff、原恢复证据和所有新版副本。identity、绑定回执同时携带 revision manifest SHA。新产品和新 owner receipt 沿用原合同，但位于新版根；旧版本不覆盖。不写 current/latest 指针，经理消费层须显式绑定新根及其 SHA。

此最小版本允许同一原恢复 owner 派生多个独立 revision；每个都明确绑定该原 owner 的父产品。暂不支持把 revision 根再当 create 的 parent-root；不能将不存在的父子链宣称已验证。

## 新独审必须提供的实际合同

Mac 复用已审材料生成真实 semantic_catalog、完整 article_decisions 及新独审。decisions 必须覆盖目录每篇公告；本批应为 392 条，301 条有效材料的业务结果由研究者明确给出，91 条未评估仍逐条显式 NOT_ASSESSED。候选不推断、不填默认、不批量清除门禁。

原 reviewer_output 合同全部保留：PASS、不同 reader/reviewer、日期、原 evidence_run_id、catalog_product_sha256、semantic_catalog 文件 SHA、body_corpus 文件 SHA、EXPLICIT_DISPOSITIONS、decision_payload_sha256、reviewed_at。decision_payload_sha256 是原 workspace_projection.digest 对规范化 article_decisions 数组的逻辑摘要，不是 decisions 文件 SHA；条目按 art_code 排序、理由去首尾空白，并使用原 make_extension 接受的准确字段。新 reviewer 顶层另需实际审查后写入：

```json
{
  "decision_revision": {
    "revision_id": "decision-r1",
    "parent_product_sha256": "e724d07b39e5b4fb3ccbb0b4536f4519b4badbfd3783cad7ee6506a7af242ad6",
    "parent_owner_receipt_file_sha256": "<实际父owner回执文件SHA256>",
    "source_recovery_receipt_sha256": "<原恢复回执文件SHA256>",
    "source_run_id": "<原32位evidence_run_id>"
  }
}
```

这只是所需新增字段结构，不是可用 reviewer，也不是新捕获记录。新 reviewer 文件 SHA、semantic 文件 SHA、decisions 文件 SHA 都作为 create 必需参数固定；register 再按原规则验证来源与逻辑 SHA。输入文件放在原恢复根的独立 inputs 子目录，原历史证据不修改。

## Mac 验收

原 88 项测试文件不变。新增 test_decision_revision.py 共 10 项：新旧产品隔离与真实股票投影；父产品/回执 pin；三输入文件 pin；独审修订绑定；独审决策摘要；失败正文不能被选中；revision ID 不可复用；复制源篡改；决策输入篡改；capture/API/输入覆盖拒绝。全部为临时合成材料，不是这 392 篇的研究结果。当前新增 10 项 NOT_RUN。

```bash
shasum -a 256 -c SHA256SUMS || exit 1
python3 -B -I tests/test_decision_revision.py > decision-revision.log 2>&1
REVISION_RC=$?
python3 -B -I tests/test_offline_analysis_chain.py > offline-analysis-regression.log 2>&1
CHAIN_RC=$?
cat decision-revision.log offline-analysis-regression.log
printf 'revision=%s chain=%s\n' "$REVISION_RC" "$CHAIN_RC"
test "$REVISION_RC/$CHAIN_RC" = '0/0'
```

## Mac 真实资料接续（验收后）

使用新的 REVISION_APP 目录组装固定提交；PARENT_ROOT 是已有 VERIFIED/imported 的原恢复根。不要用新 app 重新 adopt 旧身份。所有 SHA 从已有固定回执/真实独审输出核实；不要用试验失败后的输出替换输入 pin。

```bash
python3 -B -I tools/assemble_owner_app.py --out "$REVISION_APP"
python3 -B -I "$REVISION_APP/ops/run_v5_decision_revision.py" create \
  --parent-root "$PARENT_ROOT" --recovery-sha256 "$RECOVERY_RECEIPT_SHA" \
  --revision-id "$REVISION_ID" --parent-product-sha256 "$PARENT_PRODUCT_SHA" \
  --parent-receipt-sha256 "$PARENT_OWNER_RECEIPT_FILE_SHA" \
  --semantic-catalog "$SEMANTIC_CATALOG" --semantic-sha256 "$SEMANTIC_FILE_SHA" \
  --reviewer-output "$REVIEWER_OUTPUT" --reviewer-sha256 "$REVIEWER_FILE_SHA" \
  --decisions "$ARTICLE_DECISIONS" --decisions-sha256 "$DECISIONS_FILE_SHA"
```

create 返回 revision_root、revision_sha256；核对 decision_revision.json 文件 SHA 后设置 REVISION_ROOT、REVISION_SHA。初始化失败的目录保留，禁止手改/清空重用 ID；修复输入后使用新的 revision ID 和对应真实独审绑定。

```bash
python3 -B -I "$REVISION_APP/ops/run_v5_decision_revision.py" run \
  --revision-root "$REVISION_ROOT" --revision-sha256 "$REVISION_SHA" prepare
python3 -B -I "$REVISION_APP/ops/run_v5_decision_revision.py" run \
  --revision-root "$REVISION_ROOT" --revision-sha256 "$REVISION_SHA" register-handoff \
  --parent-task-id "$ACTUAL_PARENT_TASK_ID" --reader-identity "$ACTUAL_READER_IDENTITY" \
  --reviewer-identity "$ACTUAL_REVIEWER_IDENTITY"
python3 -B -I "$REVISION_APP/ops/run_v5_decision_revision.py" run \
  --revision-root "$REVISION_ROOT" --revision-sha256 "$REVISION_SHA" verify
python3 -B -I "$REVISION_APP/ops/run_v5_decision_revision.py" run \
  --revision-root "$REVISION_ROOT" --revision-sha256 "$REVISION_SHA" import
python3 -B -I "$REVISION_APP/ops/run_v5_decision_revision.py" run \
  --revision-root "$REVISION_ROOT" --revision-sha256 "$REVISION_SHA" readback
```

输出路径相对于 REVISION_ROOT：workspace_announcements/20261009/eastmoney_date_catalog/20261008/analysis.v1.json、同目录 owner_import_receipt.v1.json、offline_import_readback.json、manager_binding.v1.json。股票结果在读回 analysis.stock_selection。manager_binding 包含新产品 SHA、decision_revision 父版本身份及 revision manifest SHA，仍标记 manager_ui_integrated=false。父任务负责把经理绑定切换到这个新根，不能复制覆盖旧 e724 产品。

## 续读状态合并：独立待补输入

固定代码的 has_reader_declared_content_gap 只检查 evidence.reader_fact_record.body_read_complete/source_content_gap；已确认没有 continuation_reading 或 effective_body_text_coverage 合同实现。本增量保留它，不批量放行 39 项。

请求 Mac 最小脱敏 JSON：AN202610081830218018 顶层 continuation_reading、effective_body_text_coverage、evidence.reader_fact_record，以及独审身份/PASS/正文与续读 SHA 的字段和区间单位；再给一条 10/8 列表与 10/9 正文冲突记录及现有门禁字段。无需正文，须保留实际字段名、类型和摘要绑定关系。在实际合同到达前，不把覆盖[0,701258)自动解释为验证成功，也不把 PIT 未知归为正文缺页。正文缺页/乱码、披露未提供、日期 PIT 冲突将分开处理；该缺项不阻塞本次不可变决策交付。
