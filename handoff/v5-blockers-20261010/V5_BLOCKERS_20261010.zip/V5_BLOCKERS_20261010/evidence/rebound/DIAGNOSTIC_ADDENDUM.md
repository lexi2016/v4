# 真实owner身份校验补充诊断（不重跑测试、不采集）

Python：CPython 3.14.6 (main, Jul 18 2026, 17:05:49) [Clang 22.1.3 ]，optimization=0，cache_tag=cpython-314，marshal.version=5。
可执行文件：python3.14。

四个实际skip：

- test_rebound_panel_repair.ReboundPanelRepairOriginalMacCandidates.test_real_frozen_owner_identity_and_modified_function_rejection
- test_rebound_panel_repair.ReboundPanelRepairOriginalMacCandidates.test_real_model_assets_and_approved_raw_repair_only_in_private_copy

上述两个属于新68项，原因均为 `Mac explicit original-owner opt-in only`，未设置V5_REBOUND_REPAIR_ORIGINAL_TESTS=1；不是本机Python版本不足的诊断。

- test_rebound_observation.ReboundObservationOriginalMacCandidates.test_extracted_arithmetic_matches_original_owner_for_every_mutation
- test_rebound_observation.ReboundObservationOriginalMacCandidates.test_panel_only_original_run_persists_native_observations_without_master

后两个属于既有13项，原因均为 `Mac opt-in only: original owner needs Python 3.14+ and locked dependencies`，未设置V5_REBOUND_OBSERVATION_ORIGINAL_TESTS=1。上述均是原日志原文。

实际加载链：hk_preselection._source_bytes()校验capsule → sys.meta_path插入_HKLoader → importlib.import_module('upstreams.v3_shared_data.shared_data.hk_0_2')。_HKLoader.exec_module行71执行：

```python
exec(compile(data, module.__file__, 'exec'), module.__dict__)
```

即flags=0，dont_inherit=False，optimize=-1。校验器行64执行：

```python
compiled = compile(raw, str(path), 'exec', dont_inherit=True)
originals = {c.co_name: c for c in compiled.co_consts if isinstance(c, types.CodeType)}
marshal.dumps(originals[node.name]) != marshal.dumps(function.__code__)
```

校验flags=0、optimize=-1，marshal未显式给version，因此为5。两侧co_flags实际相同，不支持把错误归因为future flags不同。

两侧co_filename均为：
sources/ebe5944e/V5/vendor/hk_preselection_baseline/upstreams/v3_shared_data/shared_data/hk_0_2.py

源SHA=27da90f0e623e45fa1a27af7dcc3b6e5e1ff2320bae1c61bd903ed82050beb89。
loader SHA=afb2782626ae7969680f9a3509a05cd0b0b010d32181427481be8f8098d7c29e。

_encode_capture_at_provenance：co_firstlineno=66，co_qualname同名，co_flags=83886083。
其co_consts[5]生成器：co_firstlineno=82，co_qualname=_encode_capture_at_provenance.<locals>.<genexpr>，co_flags=16777267。
双方以下19属性逐项均相等（嵌套code递归检查）：co_argcount/co_posonlyargcount/co_kwonlyargcount/co_nlocals/co_stacksize/co_flags/co_code/co_consts/co_names/co_varnames/co_filename/co_name/co_qualname/co_firstlineno/co_linetable/co_exceptiontable/co_freevars/co_cellvars。

干净加载后、展开属性前，默认marshal两侧均1696字节，SHA256精确复现前次：
expected da49eb1bf5b2a2ad02ee0aeb899fcc2e256ef2465c2505a04e3dd3dcc453e725
actual ee11f63b511f6068e5fbe25e3140d6ba49e736fc39bb6f93aeaf87fabc4a7f69

差异offset/value：440:97/225 (0x61/0xe1)，1472:11/12，1486:12/13，1522:31/32。440位于第一个字符串常量即docstring的序列化标记。
marshal版本3/4/5存在差异，版本2相等，v2双方SHA=8e0f38acef9cc07938beff7b30ab5f8fc5f2519adb85c075933a77bbb845579b。

进一步只保留/释放expected docstring引用的诊断，结果见docstring-reference-diagnostic.json。没有改function/code/global或产品文件。这表明原始marshal字节比较受到对象引用状态影响，不应当作已证明函数语义改动。先前code-object-diagnostic.json是在属性展开后生成，其marshal摘要可与干净比较不同；以marshal-versions-before-inspection.json复现原失败字节，二者均保留，不覆盖。

本轮只写诊断证据。五份raw重新核SHA全部一致，没有网络请求或产品测试执行。待研发新固定增量后继续针对回归及私有真实repair/admission，不绕过现有校验。
