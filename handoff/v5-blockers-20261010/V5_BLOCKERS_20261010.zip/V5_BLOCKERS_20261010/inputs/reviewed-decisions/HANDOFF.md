# 全392条公告研究判定：已独审，待不可变revision接续

独审结论 **PASS_WITH_SOURCE_LIMITATIONS**，实际审核时间 `2026-10-09T16:39:55+00:00`。新V5定性规则下的回看研究候选，不是历史可交易信号或投资效果验证。

|层级|事件入选|业绩入选|观察|不选|未评估|合计|
|---|---:|---:|---:|---:|---:|---:|
|301份现行可用材料的业务判断|2|0|26|270|3|301|
|完整公告决定（原91门禁保留）|2|0|26|270|94|392|
|按原合同去重发行人代码|2|0|26|182|71|281|

同仁堂跨批已统一为不选，保留不同上市主体身份。新增3条未评估分别为216714内部股权优化缺关键方案、217894章程版本生效状态不明、222307股份类别/身份与日期冲突；完整ID及理由见decision文件。两个事件入选为HK.02465龙蟠科技（已生效供货框架及最低采购/补偿约束，保留附属公司归属、质量免责、有效订单/价格/交付风险）和HK.09978方圆生活服务（控制权取得完成并触发无条件强制现金要约，非协同或利润改善结论）。全部观察理由及个案条件见STOCK-RESULTS.md与完整投影。

## 接续的准确输入

- `article-decisions-392.final.json`：canonical decision SHA `e0094a54b123050c11870b8f1ed4a71bf768afd87ccb221605b135f846d468c8`；文件SHA `37607c65e2d822298fe321f8c3278acaf0e33d56f3261fa48b098b6ef2e5a10f`。
- `final-independent-review/reviewer-output.final.json`：文件SHA `981f89ebbcee269701ad69e4c346944f9da37cfcb1693032ca11de65c3e4eb29`；EXPLICIT_DISPOSITIONS，392条，review_conclusion PASS，scope PASS_WITH_SOURCE_LIMITATIONS。
- `policy-v1-final-retrospective.md`：SHA `5b711149cbfa3b92c3a0787ad385f457d7830da8b0e7251e06e40948b96d94a9`。标明本轮新增规则、范围解释及反例，不冒称成熟V4历史策略。
- 原source product logical SHA `e724d07b39e5b4fb3ccbb0b4536f4519b4badbfd3783cad7ee6506a7af242ad6`；文件SHA `acf2683c2fb8e327ecff8ad4bd9cd879871f9ff817bd589c3926a29495f270ca`，未修改。
- 全部来源/语义/body/引用、分批作者及独审身份、政策与文件绝对路径SHA见`DELIVERY-MANIFEST.json`、reviewer JSON和`decision-evidence-392.json`。

## 时间与原合同

实际来源取得时间为2026-10-09T10:16:00至10:22:02 UTC；本轮审核为16:39:55 UTC。原有阅读时间证据保留，不补造缺失时刻。新revision的owner available_at尚未产生，绝不能复用旧导入时间。历史首发及PIT仍CANNOT_CONFIRM。

原代码允许在来源窗口内、真实当前计划cutoff晚于所有采集/审查/新owner可用时间后消费研究引用；并非因PIT字符串未知就一律拒绝当前研究。具体字段、函数行号、两个源码版本SHA及一致的消费函数证据见CURRENT-RESEARCH-ENTRY.md与contract-consumption-comparison.json。旧计划不回填，BUY/Stage不变。

## 尚待执行

请由既有已验收e06d的Mac窗口，使用以上冻结decision及reviewer输入接续新的不可变decision revision，完成注册、导入、owner读回、实际当前研究消费及页面展示核验。此处仅完成研究判定、原合同纯内存结构校验、独立内容审查和股票聚合；**未执行新revision导入或页面验收，整项业务不能标记已完成**。不覆盖旧e724产物，不使用未取得的13项修正包，不把现在的审核回填旧计划。
