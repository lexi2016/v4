# Final independent integration review

**Verdict: PASS_WITH_SOURCE_LIMITATIONS.** I reviewed the frozen 392-row decision payload, its exact source bindings, the four final batch assessments, the preserved 91-row gate, and the issuer-level projection. This is a content and byte-binding review for retrospective research dispositions; it is not a PIT approval, a trading signal, an import receipt, or an investment-performance finding.

Reviewed at: 2026-10-09T16:39:55+00:00  
Reviewer: `/root/t09_import_contract_review`  
Reader identity: `t09_p08_actual_reader_team` — a disclosed team label, not a claim that one person read all 340 source bodies.

## Frozen inputs and exact bindings

- Policy: `policy-v1-final-retrospective.md`, SHA-256 `5b711149cbfa3b92c3a0787ad385f457d7830da8b0e7251e06e40948b96d94a9`.
- Article decisions: `article-decisions-392.final.json`, file SHA-256 `37607c65e2d822298fe321f8c3278acaf0e33d56f3261fa48b098b6ef2e5a10f`; canonical decision payload SHA-256 `e0094a54b123050c11870b8f1ed4a71bf768afd87ccb221605b135f846d468c8`.
- Business assessments: `business-assessments-301.final.json`, file SHA-256 `c145286b943f73991c594e796c4fbf33b217d0027c50644439dd574d99139f6a`; canonical payload SHA-256 `b5facd802682a254ebbc38a6dcba8d1337c968cfb47bd0f04de4f726ab744c6f`.
- Frozen manifest: `final-decision-manifest.json`, SHA-256 `88786370ed46bbba581d4c5821c4f3ea0ad674c53f9c550c7b596b10db20ecb9`. Its four batch paths and SHA values match the final source batches.
- Original product: `announcement-recovery-4cac134/offline-derived/workspace_announcements/20261009/eastmoney_date_catalog/20261008/analysis.v1.json`, file SHA-256 `acf2683c2fb8e327ecff8ad4bd9cd879871f9ff817bd589c3926a29495f270ca`, logical product SHA-256 `e724d07b39e5b4fb3ccbb0b4536f4519b4badbfd3783cad7ee6506a7af242ad6`.
- Source catalog product SHA-256 `edc49c9ec13a7436ae9a6e9015c8b962efb47492dab02b4c28033e1291b7220d`; semantic catalog SHA-256 `ec315a9470b92869dc5db928a29e52a7d83a67fd7b53925d65e36e83bcaaf8ba`; body corpus SHA-256 `638faa283d08adc6dc5dd5dee47f12e43a84ce11f1cff43afaa93db6a17fe74b`.
- Decision evidence: `decision-evidence-392.json`, SHA-256 `9dce31dc263e2034d926865f82b036ba538055d53f33401430c410512d050215`.
- The source records and decision records have the same 392 IDs in the same order. For all 392, issuer codes, security scope, semantic SHA, and body SHA match the frozen source record; every row has a non-empty reason and risk notes. Disposition-to-basis mapping is exact: selected event → `OPERATING_EVENT`, selected performance → `PERFORMANCE_RESEARCH`, watch → `CONDITIONAL_WATCH`, not selected → `NOT_SELECTED`, and not assessed → `NOT_ASSESSED`.

## Results and business consistency

The article-level result is **2 SELECTED_EVENT, 26 CONDITIONAL_WATCH, 270 NOT_SELECTED, and 94 NOT_ASSESSED**. Within the 301 valid-material research set, counts are **2 / 26 / 270 / 3**. The original 91 gated rows remain byte-for-byte equal to their preserved decision rows and bind to the source records: all 91 remain NOT_ASSESSED, including 52 body-capture failures and 39 complete-body records with existing source-content gaps. The other three article-specific NOT_ASSESSED rows are `AN202610081830216714`, `AN202610081830217894`, and `AN202610081830222307`.

The 301 integrated rows match the four reviewed final batch payloads exactly. The final batch bindings are:

- Batch 1, `business-assessments.revised-v1.json`: `09b6a69b7541d54e7ee40eed3eda4dc467d67939d0b5044c11ef6ba01ab92af3`.
- Batch 2, `business-assessments.revised-v1.json`: `14fe6b3d07b0dcbedf8bab77388c06164cede7024c53168c60d17ae54750de0d`.
- Batch 3, `business-assessments.revised-v1.json`: `9ef62944975f2447dd0ab207ba0ec48b6def06136a7c991dde2ebf893c7715b9`.
- Batch 4, `business-assessments.revised-v2.json`: `6fdddddef4650c4b3133332d43bac55e26e960f3a156798d166e81a37d98ae6e`.

I rechecked the final cross-batch boundary cases:

- `AN202610081830222639` is NOT_SELECTED. Final pricing, allotment, and expected listing establish a capital-markets process, but the reviewed record has no proceeds use, operating contribution, earnings, or other positive business fact. Confirming a listing alone would not close a business-research question; the float-concentration and termination risks remain recorded.
- `AN202610081830210850` remains CONDITIONAL_WATCH on its specific core leasing facts: 54 Q3 transactions, seven aircraft deliveries, 17 lease commitments, and 99.2% nine-month customer cash collections. The reason explicitly makes no improvement claim; the condition asks for comparable prior-period operating metrics and later financial evidence of attributable rental revenue, profit, or operating cash flow. That is distinct from `AN202610081830209462`, whose user-count growth was expressly disclaimed by the issuer as not indicating revenue growth and was not tied to cash conversion.
- `AN202610081830212707` remains CONDITIONAL_WATCH only as a specific approved sale-agreement path for all target equity. The final reason and risks state that approval does not prove completion or positive impact; the follow-up requires closing, net proceeds, and target contribution/disposal effects. It is not treated as a completed positive result or as a routine governance vote.

The two selected events are `AN202610081830219564` (completed control acquisition and mandatory unconditional cash offer) and `AN202610081830220560` (five-year supply framework with disclosed minimum-purchase and shortfall-compensation terms). Neither is described as recognized revenue or as a proven earnings improvement; the remaining contractual, attribution, and performance limitations stay in the article risks.

## Issuer projection and V4 contract

`stock-projection.final.json` has file SHA-256 `bfc969b829d75707c69cf8c69501e1054d11cb279ce1e3fe7e1d186dee49681f`, status VERIFIED, and binds to the same decision extension. Its 281 issuer-code groups aggregate to **2 SELECTED, 26 CONDITIONAL_WATCH, 182 NOT_SELECTED, and 71 NOT_ASSESSED**. I independently checked that every source issuer/article pair appears once, each projected article preserves its final disposition/reason/risks, and issuer status precedence reproduces the saved counts. These 71 are stock groups, not article rows; the article-level NOT_ASSESSED count remains 94.

The current contract source manifest is `contract-source-sha256.json`, SHA-256 `5fb721949e009748b9803eea5a0c113540d551e0d0487699f45b6dab1ec02624`. The original Desktop V4 `workspace_announcements.py` SHA is `60839e20df9b61be04629481752ab3072a1088d229c87980e83059b590548e50`; the packaged app copy SHA is `a19991353c932815052c5f04fc1100d3d5cbd2f67e238a45505292a00f01e26a`. The full files differ because the packaged copy includes additional failed-body-page validation. The separate `contract-consumption-comparison.json` (SHA-256 `00132dccdabe9dc039ad1a33296427eb2131d038a383526e02e8dfded039bbad`) records that the relevant `_analysis_time_refs`, `_analysis_pairs`, and `read_reviewed_analysis_references` function ASTs are equal. In the packaged copy they begin at lines 2242, 2273, and 2304. The packaged `announcement_selection.py` matches the bound SHA `0924f1806766fc4b580fb17fa8e39206005a25cdc02467757278b1560e104f21`; its `make_extension` validates explicit source-bound decisions and does not choose dispositions. This review does not report a new import, deployment, or plan-consumption PASS.

## Reader and reviewer scope

The bound roster `announcement-analysis-1a699a0/review-inputs/reader-roster.json` has SHA-256 `bd9fed99759814a755fbac53b16588db445976d2fa967bcd6bcc060f3a302dc0`. It attributes the 340 reviewed records across `/root/t09_reader_1` (64), `/root/t09_reader_2` (77), `/root/t09_reader_3` (99), and `/root/t09_reader_4` (100), with independent group reviewers `/root/t09_review_group1` through `/root/t09_review_group4`. The roster also records `/root/t09_reader1_continue` for the long-body continuation and bounded segment reviews of the second long article. Its own limitations state that the first reader’s raw completion flag remains false despite inherited combined-body coverage, and the long article was reviewed in segments rather than by one person. These identity strings are source-bound declarations, not platform-authenticated identities.

The business-batch author identities are `/root/decision_author_1` through `/root/decision_author_4`, as mapped in `author-receipts.json` (SHA-256 `ff57d6405d2f327b71237ee8b3868139a74ca61873ca514afbab1bb57768ecd7`). The separate gate review is `gated-91-independent-review.json`, SHA-256 `59816bb6a0d035ae3a1a57ed1c601a57d91713de9c2399ff92dba35f106b3c7b`, attributed there to `/root/decision_author_2`.

My role was integration review: I compared all final rows against the frozen source and revised batches, validated the exact gates and projection, and substantively revisited the three cross-batch Watch cases. I did not reread all 340 article bodies; the review relies on the bound team reading records and batch reviews. The inherited semantic review SHA is `f540a4b87c1544a547479a1ab2bb06ddaad8936262bbd6b373a1fbe28b9d2590`; its final-byte-binding evidence SHA is `beba7033dada8116495243d7f72a42020c2321699ef60da40dd4ee47bc19112c`.

## Limitations

The source product’s first HKEX publication time and original point-in-time availability remain `CANNOT_CONFIRM`. The user’s retrospective-scope instruction is applied to the 301 valid-material business review while the original 91 gates remain intact; it does not establish historical availability, a backtest, trading eligibility, or investment performance. The V4 code consumes a registered/currently imported analysis only when the actual source, review, and owner-availability times are complete and no later than the plan cutoff; this review does not create those times or claim the new decisions were imported. No CLI, registration, or import was performed for this final decision set.
