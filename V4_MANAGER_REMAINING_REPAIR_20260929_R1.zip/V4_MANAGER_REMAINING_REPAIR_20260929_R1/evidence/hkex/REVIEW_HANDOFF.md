# R3 两处 P1 候选采用交接

状态：`READY_FOR_REVIEW`。本阶段只采用精确补丁并准备独立审查。Writer 测试、网络请求和部署均未执行。

- 候选：`/Users/lexi/Desktop/学习/agents调试/HKEX_ALL_QUERY_LOCAL_R2_20260928/writer/candidate`
- receipt：`/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/receipt.json`
- ledger：`/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/scope_ledger.json`
- 实际两份修改文件 diff：`/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/actual_candidate_diff.patch`
- 新增 40 项逐文件 SHA 清单：`/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/new_files_manifest.json`
- 精确前像备份：`/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/backup/before`
- 回退清单：`/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/restore_manifest.json`
- 解包包目录：`/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/package`

当前 R3 外层 ZIP SHA256：`63329f49d546af06f2244a41eb3979310003b5d489a54f1646b85fa47eef01f8`。包内 `VALIDATION.json` 的 `input_zip.sha256` `5f47700656847df8f5fb5516228844d26c1c90b53835ca06ac5add2c714ce5e0` 指其上游 130 成员问题包；外层 R3 是 104 成员（其中 103 项受 manifest 管理）。外层 CRC 和 103 项逐文件 size/SHA 均通过。

协议 SHA：`4d85ce9d4d53a2284c82c646c7a4d06efef10dea3a32d80e34b4a8597c033bfb` → `18533687729182e2e479759bb9251464a62054e230b2bcafe70745224038c17c`。`announcement_source.py` 前后 SHA：`e3b90c2c09b6f8c4a39bcfd8c8912e3476011a8faf59b94f4069ccaa81ae0d24`，字节未变。

## 独立 Reviewer 验收命令

```bash
APP='/Users/lexi/Desktop/学习/agents调试/HKEX_ALL_QUERY_LOCAL_R2_20260928/writer/candidate'
PKG='/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/package'
PY='/Users/lexi/Library/Application Support/com.lexi.v4.local/runtime/venvs/v3.5-mac/bin/python'
cd "$APP"
"$PY" -B -m pytest -q -p no:cacheprovider tests/test_hkex_directory_r4.py tests/test_hkex_official_all_r2.py tests/test_hkex_real_failures_r2.py
cd "$PKG"
"$PY" -B -m pytest -q -p no:cacheprovider tool_tests/test_probe_assessment.py
```

## 原 owner 单例执行入口（本阶段未执行）

R3 对应入口：`/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/package/tools/run_original_owner_nonempty.py`（SHA256 `eaf3141783daeb4c3430f43bad816e430ea8276bcd43bf3aa4591d8e53d18d0d`）。既有单例请求：`/Users/lexi/Desktop/学习/agents调试/HKEX_ALL_QUERY_LOCAL_R2_20260928/request_single_00002.json`（SHA256 `69473318df150f1799c305cd0e38cfba5e1f6dae5dd298943c144a9112d673f0`）。入口要求显式 `--allow-public-network`、绝对 `--app/--request/--output`、精确 `--request-sha256`，输出目录需为候选之外的新目录。真实执行前重核日期和合法时窗；原请求过期后只能显式 `--historical-protocol-check` 作协议诊断，不能声称当前盘前业务成功。本阶段没有调用入口。

## 回退

按 `/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/restore_manifest.json` 操作。先核对已改文件仍为 R3 after SHA；任一不等就停，不覆盖后续变化。两个既有文件从 `/Users/lexi/Desktop/学习/agents调试/HKEX_TWO_P1_R3_LOCAL_20260928/backup/before` 恢复；40 个新增路径仅在当前 SHA 与 after SHA 完全一致时逐文件移除。恢复后核对前像 SHA 和 protected 文件 SHA；不做全仓 reset/checkout。
