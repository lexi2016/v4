# V4 经理工作台 / HKEX 新会话交接

更新时间：2026-09-28 21:24 港时。

## 1. 先看结论

本轮没有完成HKEX本机补修，也没有部署。外部R2在隔离候选已应用，独立82项定向测试与10项工具测试通过；但原owner真实查询三家均失败，独立裁决FAIL，存在两处已确认P1。现已打好真实失败问题包，用户将交Chat精修，拿回新包后再由Codex验收、集成、发布和读回。

不要把“测试通过”“HTTP200”“旧空目录可读”解释成公告正文链已成功。新会话不必重建历史，只读本文件、问题包入口和两项裁决即可。

## 2. 用户目标与最高执行偏好

业务目标：统一V4经理工作台能形成有真实证券身份、来源、方向、风险、观察与撤销条件的研究候选，并最终形成合法时段的有效计划；研究排序不能冒充BUY。

当前有界目标：修好HKEX原查询链的两处真实缺陷，通过正确POST→实际回显→目录GET→真实正文→原MaterialStore读回，随后验证对应运行消费者实际采用。

用户明确要求：禁止钻没有实际意义的牛角尖。本机实际运行什么Python就用什么；只有影响运行或结果正确性的差异才处理。已通过的无变化证据复用，不围绕版本号、整包接收或重复测试拖延。若真实行为失败，直接定位问题或交完整问题包，不无止尽承诺“马上修”。

本机服务当前使用：
`/Users/lexi/Library/Application Support/com.lexi.v4.local/runtime/venvs/v3.5-mac/bin/python`

遵守就近AGENTS：主控协调/只读/集成，Luna Max唯一Writer，另一身份Luna Max独立Reviewer；不并发写同一文件。无需重开架构或添加流程批准。

## 3. 当前真实运行基线

本交接写作时再次只读核对：8873监听PID 98408，进程工作目录为：
`/Users/lexi/Library/Application Support/com.lexi.v4.local/releases/20260928-manager-business-chain-r3/app`

正式源码项目：
`/Users/lexi/Desktop/学习/v4_app`

canonical存在大量既有未提交修改，不等于当前运行代码；不要整包覆盖canonical或活动release。

scheduler保持用户冻结的`20260926-manager-closure-r1`，本轮未切换；该条是保留的运行基线约束，本次写交接没有重新全面审计scheduler。Vibe8910源码、配置、服务保持原样。没有更新BUY、发送订单或改排序权重。

原R4＋HKEX R1 revision2隔离候选：
`/Users/lexi/Desktop/学习/agents调试/V4_MANAGER_SOURCE_CHAIN_R4_LOCAL_20260928/writer/api-candidate`

外部HKEX R2已应用的新隔离候选：
`/Users/lexi/Desktop/学习/agents调试/HKEX_ALL_QUERY_LOCAL_R2_20260928/writer/candidate`

它不是已发布版本。当前两个运行文件仍与外部R2 after SHA一致；本机两P1源码修正尚未落地，只另存了部分真实HTML fixture及前像。

## 4. 用户应提交Chat的唯一最新问题包

`/Users/lexi/Downloads/HKEX_R2_REAL_FAILURES_FOR_CHAT_20260928.zip`

大小：1,382,869 bytes；成员130；CRC与逐文件SHA通过。
SHA256：
`5f47700656847df8f5fb5516228844d26c1c90b53835ca06ac5add2c714ce5e0`

包入口：`00_提交Chat精修.md`。
包含当前源码前像、真实POST/HTML、官方脚本、原store、独立裁决、来源索引和最小验收要求。`decoded_originals`只是原响应直接解码，未改写。公开页面包含当次session标识，只用于证据，不重用旧会话。

解包目录：
`/Users/lexi/Desktop/学习/agents调试/HKEX_R2_REAL_FAILURES_FOR_CHAT_20260928`

外部待修包来源（不是最新已通过版本）：
`/Users/lexi/Downloads/HKEX_ALL_QUERY_REPAIR_R2_20260928.zip`
SHA256：`fc8f2bc50230e913e59776a2f61696ce47791583e23112bebcd1df307ce5d41e`

## 5. 两处明确P1及修正要求

### P1-01：拒绝合法session表单地址

实际HK.00001页面HTTP200、官方搜索脚本齐全，但form action为`/search/titlesearch.xhtml;jsessionid=…`。候选`v4/manager_research/hkex_directory_protocol.py`约41行只接受精确路径，误拒并报`HKEX_PRIME_SEARCH_SHELL_UNCONFIRMED`。

修正要求：安全接受同一官方端点的合法session后缀，同时保留host/path/表单身份限制；以真实prime HTML做回归，不开放任意端点或任意后缀。

### P1-02：混淆POST的ALL输入与服务器回显

HK.00002/3实际POST的documentType/t1code/t2Gcode/t2code均为空；服务器回显为selectedDocType=-1、tierOneId/tierTwoGpId/tierTwoId=-2，发行人和日期正确。

`attest_form_echo`约260–277行强求回显仍为空；`servlet_request`约131–144行又将后续GET硬编码为空，因此在目录GET前失败`HKEX_ALL_FORM_ECHO_MISMATCH`。

已有官方`titlesearch_research.js`约390–415行明确读取服务器返回的hidden字段，并转换日期后构造GET。修正应分层核验POST空输入、已证实的服务器表示和GET参数，不能删除echo gate，也不能把POST改回旧的-1/-2。

原测试`tests/test_hkex_official_all_r2.py`约73行人工将回页-1/-2替换为空，漏掉真实行为。新增正例必须使用未改写原件；负例覆盖错误issuer/date/filter/host/path及冲突回显。

允许变更优先仅protocol.py＋针对测试/fixture，确需announcement_source.py须说明直接关联。不要借机改其他模块。

## 6. 本机证据与实际验收边界

证据总根：
`/Users/lexi/Desktop/学习/agents调试/HKEX_ALL_QUERY_LOCAL_R2_20260928`

- 独立裁决：`reviewer/VERDICT_R2_INITIAL.json`，SHA `165d307c9a60909da7013e918907c63ef66986aed63e50e0cf989a93703941ef`。
- 唯一真实attempt：`actual-owner/original_owner_attempt.json`，SHA `c3f1c91ce67e09e1f511a77e77fe310c1cbebe942c972c957a77b0f1497355a3`。
- 原件：`actual-owner/materials`；包含请求、返回HTML和脚本。
- 原请求：`writer/request.json`，SHA `3537468c3be5aea0f82347ca6f184b84d88510965f9f0d3ad3de0902622777a8`；与旧receipt语义一致，HK.00001/00002/00003，目标20260928，窗口起点2026-09-24 16:10、cutoff2026-09-28 18:29:55.388780港时。
- 请求范围核对：`request_scope_gate.json`。
- 回显诊断：`writer/REAL_ECHO_DIAGNOSIS.json`。
- 最小返修前像：`minimal_fix/before`与`before_sha256.json`。
- 当前执行账本：`scope_ledger.json`及`CURRENT_STATUS_ZH.md`。

真实调用发生于20:28:46—20:29:04港时，晚于固定cutoff，属于协议诊断，不是盘前或自然业务成功。三家FAILED、目录页0、正文0。原store失败原件可读不等于正文通路通过。没有第二次联网查询。

已准备但未执行的单例请求：`request_single_00002.json`，SHA `69473318df150f1799c305cd0e38cfba5e1f6dae5dd298943c144a9112d673f0`；保持原context，仅缩为HK.00002。不得在新日期静默当作当前业务；重开时先判断合法日期/窗口，旧请求只能明确协议诊断。

独立82＋10已通过且有裁决。Writer最初误用Xcode Python的82结果只属辅助；已由独立Reviewer在实际服务环境完成验收，不再纠缠版本或重复补跑。失败是上述两项真实行为，不是解释器原因。

## 7. 下一会话应怎么做

若用户尚未带回Chat精修包：告知最新问题包位置即可，不自行重开全套修复或重查脚本。

用户带回精修包后，按同一任务连续推进：

1. 对照current_source和候选实际SHA核新前像，只处理漂移路径；不得修改expected SHA强过。
2. 唯一Writer在隔离候选应用一次两P1补丁，保留精确diff和恢复点。
3. 独立Reviewer复跑受影响真实原件回归，核POST→echo→GET语义。未变化的既有验收复用；不把合成测试当实际HKEX目录成功。
4. 代码通过后原允许范围内单例实际查询；固定请求、真实时钟、保存原件。首个协议失败先定位，禁止同错三家重复或扩大到690家。
5. 非空目录中真实返回URL才能进入正文parser和原store；至少一份真实正文成功读回，才算正文通路通过。空目录不算通过，不手塞URL、扩大历史窗或伪造时钟凑正例。
6. 若有真实正例且消费者兼容，通过已有assembler/发布控制器完成授权内对应API/owner采用，并读回Manager。保持scheduler冻结，自动公告enabled不擅改。不要新写部署器。
7. 分开报告IMPLEMENTED、TESTED、REVIEWED、INTEGRATED、DEPLOYED、API/UI、正文业务和NATURAL。缺自然窗口保留条件，不补写过期盘前计划。

两项仍失败则直接交带原件、具体代码位置的最小问题包；不要再次只报“马上修”。执行端无实际产出且无外部阻塞时及时收口，不无止尽等待。

## 8. 其他经理台问题单独保留

更大业务问题包：
`/Users/lexi/Downloads/V4_MANAGER_BUSINESS_BLOCKERS_20260928.zip`
SHA `00496d562577c15cefb3c7f91deb416ea9794c4f682afae9c36ecf0f15cde4ab`。

此前19:11固定响应有22股票对象、3318材料、9 focus；这只是历史现场快照，不能当成新会话当前状态。相关问题包括NEAR被标“市场确认”、计划行情读取FileNotFoundError、US关系时间/来源拒绝、Stage输入绑定、15:30子结果校验、材料owner与冻结计划衔接。HKEX单支线通过不能宣布这些全部解决，也不得让它们无限扩大本次两P1范围。

## 9. 可直接复制的新会话指令

请按本交接继续。先确认我是否已提供针对两项真实P1的Chat精修包；未提供则直接指出最新问题包，别重做诊断。有新包就对本机确切前像最小应用、独立验收，再原范围单例验证POST回显、目录、真实正文及原store。通过后完成已授权对应部署和Manager读回；失败直接保留原件和首个具体断点。使用本机实际服务Python，复用未变验收，不重开架构、不重复旧补丁、不切scheduler、不改Vibe/PIT/BUY，不将旧cutoff诊断冒充盘前。
