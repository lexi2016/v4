# V4_FORMULA_MARGIN_SHADOW_V1_R2.2 Frozen Contract

## Decision

R2.1 ends as `ENGINEERING_SCOPE_PASS / OVERALL_FAIL / REAL_AUTHORITY_OWNER_PENDING / natural_sample_count=0`.
R2.2 is limited to invocation identity and frozen-provenance closure. It must not change margin/tau/H/same-lane selection logic, membership owner, close owner, scheduler, BUY gate, or trading path.

Allowed edits only:
- `stage_center/formula_margin_shadow.py`
- `tests/test_formula_margin_shadow.py`
- `docs/formula_margin_shadow_v1.md`

Locked unchanged:
- `stage_center/selection.py` SHA256 `1f93525ced647bfdc8fbf53ad3efb157a112206997003ade3f06dcfb91919549`
- `ops/run_formula_margin_shadow.py` SHA256 `3365e6eccc414288f2d7a6087f802571b60e0e73751609895f4328cf1dc17e1e`

`REAL_AUTHORITY` remains fail-closed pending existing membership/final-close owner contracts. R2.2 does not satisfy or simulate those contracts.

---

## 1. Actual selector invocation identity

### Root cause

The callback executes before `select_hk_four_lane()` constructs and returns its selection envelope. Therefore callback `context.run_id` / caller `metadata.run_id` cannot be accepted as the production run identity.

No new runner/owner dependency is needed for engineering invocation identity. `capture_selector_snapshot()` already receives the real selector return envelope after the callback. R2.2 must bind the receipt to that returned envelope.

### Required implementation boundary

`_capture_time_receipt_payload()` must no longer derive `production_run_id` from callback context or metadata.

For an invocation-verified capture, the receipt must be built only after `select_hk_four_lane()` returns, using its actual returned envelope.

Required selector-return fields:
- `run_id`
- `artifact_id`
- `algorithm_sha256`
- `raw_artifact_sha256`
- `selection_status`
- `trade_date`
- `stage_id`
- `market`
- `rows`

Required checks before freeze:
1. returned `trade_date` == capture trade date;
2. returned `stage_id` == capture stage;
3. returned `market` == `HK_CONNECT`;
4. returned `raw_artifact_sha256` == verified source/raw artifact SHA;
5. returned Top10 codes == callback `production_rows` Top10 codes;
6. returned Top10 codes == shadow-built baseline Top10 codes;
7. returned `run_id`, `artifact_id`, `algorithm_sha256` are present and valid;
8. selector return envelope hash is computed from canonical bytes and persisted.

If caller metadata contains `run_id` or `artifact_id`, it is non-authoritative. If supplied and different from the actual selector return, reject with a mismatch reason; never copy it into the authoritative receipt.

### Receipt v2 fields

Bump the capture receipt schema because identity semantics change.

Required fields:

```text
schema_version = v4.formula_margin_shadow.capture_time_receipt.v2
source = FORMULA_MARGIN_SHADOW_CAPTURE_RUNTIME_V1
invocation_verified = true
invocation_verification_basis = SELECTOR_RETURN_ENVELOPE_AND_CALLBACK_PARITY_V1
trade_date
stage
cutoff_ts
selector_started_at
selector_finished_at
production_run_id                  # from actual selector return
production_artifact_id             # from actual selector return
production_algorithm_sha256        # from actual selector return
selector_result_sha256             # canonical actual returned envelope
shadow_invocation_id               # runtime-generated local event id, not caller supplied
raw_input_sha256
raw_artifact_sha256
source_artifact_sha256             # independent explicit field
production_rule_sha256
d1_manifest_sha256
formula_input_sha256
formula_state_artifact_sha256
formula_rule_sha256
formula_rule_artifact_sha256
shadow_rule_version
comparator_version
selector_invocation = stage_center.selection.select_hk_four_lane
selector_invocation_status = COMPLETED
```

Under the current R2 source contract:

```text
raw_artifact_sha256 == source_artifact_sha256
```

Both fields remain explicit and both are independently validated.

`production_run_id` is the selector's deterministic returned run/content identity. `shadow_invocation_id` is the unique local capture event identity. Do not describe the deterministic production run_id as a unique process invocation nonce.

### Direct freeze API boundary

`freeze_snapshot()` is an engineering freeze API, not proof that the real selector ran.

A direct call to `freeze_snapshot()` must never create or preserve `invocation_verified=true`.

Frozen engineering artifacts must state:

```text
capture_origin = DIRECT_ENGINEERING_FREEZE
invocation_verified = false
invocation_status = NOT_VERIFIED_ENGINEERING_FREEZE
counts_as_forward_day = false
natural_sample_count = 0
```

A caller-supplied `capture_time_receipt` claiming `selector_invocation_status=COMPLETED` must be rejected by the direct freeze path, rather than being accepted as runtime proof.

Only the internal path used by `capture_selector_snapshot()` after a real selector return may create an invocation-verified receipt. This is an API/control-flow guarantee, not a cryptographic anti-forgery security boundary.

---

## 2. Frozen provenance versus external source revalidation

### Required frozen bytes

At invocation-verified freeze time, copy the exact bytes actually verified/consumed into the immutable run root, for example under `provenance/`:

- production source artifact bytes;
- production rule artifact bytes;
- D1 manifest artifact bytes;
- formula state artifact bytes;
- formula rule artifact bytes;
- actual selector return envelope as `selector_result.json`.

Do not symlink. Persist exact bytes and record each SHA256 in `selection_receipt.json`.

The existing frozen members/baseline/candidate/capture receipt remain unchanged in purpose.

### Local verification scope

`verify_frozen_artifacts(run_root)` must verify:
- members/baseline/candidate/selection receipt;
- capture receipt when present;
- selector_result artifact when invocation-verified;
- all sealed provenance copies;
- SHA and identity cross-bindings;
- baseline == selector returned Top10 for invocation-verified capture.

Its result means only:

```text
frozen_integrity_status = PASS
integrity_scope = LOCAL_FROZEN_AND_SEALED_PROVENANCE
```

It must not claim that external original paths still contain the same bytes.

### Optional external revalidation

Provide either a separate helper or an optional verification flag that re-hashes the original external artifact paths recorded at capture.

Status is separate:

```text
external_source_revalidation = NOT_REQUESTED | PASS | DRIFTED | MISSING
```

Later external drift/missing does not retroactively invalidate a frozen sample when the exact consumed bytes were sealed locally and remain hash-valid. It is an audit status, not a rewrite of historical frozen integrity.

If an invocation-verified future capture lacks the local sealed provenance set, it cannot claim source-replayable frozen integrity.

---

## 3. REAL authority remains owner-pending

R2.2 does not implement membership or final-close authority.

Required batch end state if engineering tests pass:

```text
ENGINEERING_ADMISSION_HARDENING = PASS
INVOCATION_IDENTITY_ENGINEERING = PASS
FROZEN_PROVENANCE_ENGINEERING = PASS
REAL_AUTHORITY = BLOCKED_OWNER_PENDING
NATURAL_CANARY = BLOCKED
natural_sample_count = 0
```

Do not turn owner-pending cases into engineering substitutes.

Previous REAL cases involving:
- membership manifest/receipt chain;
- close exact-membership equality;
- missing/extra close members;
- real hit READY with markout semantics missing;

must be reported as:

```text
BLOCKED_OWNER_PENDING / NOT_RUN_AS_REAL
```

Engineering analogs may be tested, but must be labelled `ENGINEERING_ANALOG_PASS`, never `REAL_CASE_PASS`.

---

## 4. Required focused counterexamples

At minimum add/retain these focused cases.

### Invocation identity

1. Caller supplies `metadata.run_id=CALLER_FORGED_RUN_ID`; actual selector returns a different run_id -> capture rejects mismatch or receipt uses only actual selector identity according to the frozen policy; caller value must never become authoritative.
2. Caller directly calls `freeze_snapshot()` with a hand-built `capture_time_receipt` claiming completed selector invocation -> reject; no invocation-verified freeze.
3. Real `capture_selector_snapshot()` invocation -> receipt `production_run_id` equals actual returned selector envelope `run_id`.
4. Receipt `production_run_id` changed after freeze -> local verify fails.
5. Receipt `production_artifact_id` changed -> local verify fails.
6. `selector_result.json` changed -> local verify fails.
7. Callback production Top10 differs from actual returned selector envelope Top10 -> capture invalid; nothing counted/frozen as verified invocation.
8. Shadow-built baseline differs from actual returned selector envelope Top10 -> capture invalid.

### Explicit source artifact identity

9. `source_artifact_sha256` absent from invocation receipt -> reject.
10. `source_artifact_sha256 != actual sealed source bytes` -> reject.
11. `raw_artifact_sha256 != source_artifact_sha256` under current contract -> reject.

### Local versus external provenance

12. Invocation capture seals source/rule/D1/formula bytes; mutate original external source path afterward -> `verify_frozen_artifacts` local integrity remains PASS; external revalidation reports DRIFTED.
13. Delete original external path afterward -> local integrity remains PASS; external revalidation reports MISSING.
14. Mutate a sealed provenance copy inside run root -> local verify fails.
15. Remove a required sealed provenance copy -> local verify fails.

### Existing R2.1 protections retained

16. runtime previous/next Shanghai date -> reject.
17. runtime outside stage window -> reject.
18. 99/101 D1 members -> reject.
19. source/formula/rule SHA mismatch -> reject.
20. alias conflict -> reject.
21. selector/shadow callback failure cannot alter production selector result.
22. ENGINEERING_FIXTURE truth remains engineering-only and never increments natural sample count.

### REAL owner-pending reporting

23. REAL capture/truth owner-gated cases remain blocked with `natural_sample_count=0`; tests assert the blocked state, not fake READY.
24. REAL case8 (hit READY + markout CANNOT_CONFIRM) remains `BLOCKED_OWNER_PENDING / NOT_RUN_AS_REAL` until owner truth contract exists; an engineering analog may test hit/markout separation only.

---

## 5. Acceptance and stop conditions

R2.2 passes only if:

- only the three allowed files changed;
- locked `selection.py` and `ops` SHAs remain unchanged;
- focused tests above pass in the complete local V4 environment;
- previous R2.1 engineering protections remain green;
- direct freeze cannot claim a verified selector invocation;
- actual capture receipt identity is derived from the actual selector returned envelope;
- explicit `source_artifact_sha256` is present and cross-bound;
- exact consumed provenance bytes are sealed locally and verified;
- REAL authority remains blocked and natural sample count remains zero.

Do not start a 5-day natural canary after R2.2 engineering PASS. Natural canary remains blocked until the existing membership owner and final-close owner contracts required by R2.1 are independently available and admitted.

No margin/tau/H/same-lane changes, no third rule, no model research, no second market-data bottom board, no 20260911 recovery work.

```text
RESEARCH_ONLY=true
shadow_only=true
production_allowed=false
buy_gate_updated=false
orders_sent=false
automation_created=false
natural_sample_count=0
```
