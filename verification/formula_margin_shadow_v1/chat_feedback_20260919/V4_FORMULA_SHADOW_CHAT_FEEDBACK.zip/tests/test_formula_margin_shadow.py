from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

import pytest

from stage_center.formula_margin_shadow import (
    COMPARATOR_VERSION,
    EXPERIMENT_ID,
    ShadowInvalid,
    TRUTH_SCOPE,
    append_labels,
    build_shadow,
    evaluate_run,
    evaluate_runs,
    freeze_snapshot,
    preflight_input,
    verify_frozen_artifacts,
    build_selector_capture_payload,
    capture_selector_snapshot,
    canonical_json,
    sha256_bytes,
)
from stage_center.selection import select_hk_four_lane


def _metadata() -> dict:
    return {
        "experiment_id": EXPERIMENT_ID,
        "observation_mode": "FORWARD_NATURAL",
        "captured_at": "2026-09-21T09:35:05+08:00",
        "trade_date": "20260921",
        "stage": "STAGE_0930_0935",
        "cutoff_ts": "2026-09-21T09:35:05+08:00",
        "market": "HK_CONNECT",
        "source_version": "v4.hk.production.snapshot.v1",
        "input_sha256": "a" * 64,
        "rule_sha256": "b" * 64,
        "comparator_version": COMPARATOR_VERSION,
        "run_id": "hk-natural-20260921-093505",
        "formula_provenance": {
            "source_version": "hk-formula-state-v1",
            "input_sha256": "c" * 64,
            "rule_sha256": "d" * 64,
            "source_asof": "2026-09-20",
            "frozen_at": "2026-09-20T18:00:00+08:00",
        },
    }


def _rows() -> list[dict]:
    rows = []
    for rank in range(1, 16):
        rows.append(
            {
                "security_id": f"HK.C{rank:02d}",
                "eligible": True,
                "lane": ["LANE_MAIN", "LANE_THEME"],
                "stage_score": 92.0 - (rank - 1) * 0.2,
                "production_rank": rank,
                "candidate_bucket": "FOUR_LANE_OBSERVATION",
                "trade_status_contract": "WATCH_ONLY",
                "pct_chg": 3.0,
                "volume_ratio": 2.0,
                "f1_state": "N",
                "f2_state": "N",
                "f3_state": "N",
                "f4_state": "N",
                "stage_price": 10.0 + rank / 100,
                "price_ts": "2026-09-21T09:35:05+08:00",
                "currency": "HKD",
                "adjustment_mode": "RAW",
                "price_source": "V4_HK_STAGE_SNAPSHOT",
            }
        )
    rows[10]["f1_state"] = "H"  # C11 can enter the boundary.
    rows[11]["f2_state"] = "H"
    rows[12]["f3_state"] = "U"  # U is not a penalty and is not a bonus.
    rows[13]["f4_state"] = "H"
    return rows


def _payload() -> dict:
    return {**_metadata(), "rows": _rows()}


def _persistent_payload(tmp_path: Path, *, stage: str = "STAGE_0930_0935") -> dict:
    payload = _payload()
    rows = []
    for rank in range(1, 101):
        row = dict(payload["rows"][(rank - 1) % len(payload["rows"])])
        row["security_id"] = f"HK.C{rank:02d}"
        row["code"] = row["security_id"]
        row["production_rank"] = rank
        row["stage_score"] = 92.0 - (rank - 1) * 0.2
        row["stage_price"] = 10.0 + rank / 100
        rows.append(row)
    payload["rows"] = rows
    payload["stage"] = stage
    payload["cutoff_ts"] = f"2026-09-21T{ {'STAGE_0930_0935':'09:35:05','STAGE_0945_1030':'10:30:00','STAGE_1445_1500':'15:00:00'}[stage] }+08:00"
    payload["captured_at"] = payload["cutoff_ts"]
    payload["run_id"] = f"hk-natural-20260921-{stage}"

    source_path = tmp_path / f"source-{stage}.json"
    source_path.write_text(json.dumps({"rows": rows}, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    source_sha = hashlib.sha256(source_path.read_bytes()).hexdigest()
    rule_path = tmp_path / f"rule-{stage}.txt"
    rule_path.write_text("formula-margin-shadow-rule-v1", encoding="utf-8")
    rule_sha = hashlib.sha256(rule_path.read_bytes()).hexdigest()
    formula_rows = [
        {
            "security_id": row["security_id"],
            "f1_state": row.get("f1_state", "N"),
            "f2_state": row.get("f2_state", "N"),
            "f3_state": row.get("f3_state", "N"),
            "f4_state": row.get("f4_state", "N"),
        }
        for row in rows
    ]
    formula_path = tmp_path / f"formula-{stage}.json"
    formula_path.write_text(json.dumps({"rows": formula_rows}, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    formula_sha = hashlib.sha256(formula_path.read_bytes()).hexdigest()
    d1_path = tmp_path / f"d1-{stage}.json"
    d1_path.write_text(json.dumps({"rows": rows}, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    d1_sha = hashlib.sha256(d1_path.read_bytes()).hexdigest()
    payload["input_sha256"] = source_sha
    payload["rule_sha256"] = rule_sha
    payload["source_artifact"] = {"path": str(source_path), "sha256": source_sha}
    payload["rule_artifact"] = {"path": str(rule_path), "sha256": rule_sha}
    payload["formula_provenance"] = {
        "source_version": "hk-formula-state-v1",
        "input_sha256": formula_sha,
        "rule_sha256": rule_sha,
        "source_asof": "2026-09-20",
        "frozen_at": "2026-09-20T18:00:00+08:00",
        "artifact": {"path": str(formula_path), "sha256": formula_sha},
    }
    payload["d1_manifest"] = {
        "version": "hk-d1-manifest-v1",
        "manifest_sha256": d1_sha,
        "artifact": {"path": str(d1_path), "sha256": d1_sha},
    }
    payload["time_evidence"] = {"source": "test-selector", "captured_at": payload["captured_at"]}
    payload["raw_artifact_sha256"] = source_sha
    return payload


def _truth_universe_rows() -> list[dict]:
    top20 = [f"HK.C{i:02d}" for i in range(1, 10)] + [f"HK.C{i:02d}" for i in range(11, 22)]
    all_codes = [*top20, "HK.C10", *[f"HK.C{i:02d}" for i in range(22, 41)]]
    return [
        {
            "security_id": code,
            "close": 100.0 + (len(all_codes) - index) if code in top20 else 80.0 - index,
            "pre_close": 100.0,
        }
        for index, code in enumerate(all_codes)
    ]


def _labels(tmp_path: Path) -> dict:
    universe_rows = _truth_universe_rows()
    canonical_truth = [
        {
            "security_id": row["security_id"],
            "close_price": float(row["close"]),
            "pre_close_price": float(row["pre_close"]),
            "close_gain": float(row["close"]) / float(row["pre_close"]) - 1.0,
        }
        for row in universe_rows
    ]
    source_path = tmp_path / "truth-source.json"
    source_path.write_text(
        json.dumps({"truth_scope": TRUTH_SCOPE, "rows": universe_rows}, ensure_ascii=False, sort_keys=True),
        encoding="utf-8",
    )
    source_sha = hashlib.sha256(source_path.read_bytes()).hexdigest()
    rank_by_code = {code: rank for rank, code in enumerate([row["security_id"] for row in sorted(canonical_truth, key=lambda row: (-row["close_gain"], row["security_id"]))[:20]], start=1)}
    top20 = list(rank_by_code)
    return {
        "schema_version": "v4.formula_margin_shadow.labels.v1",
        "experiment_id": EXPERIMENT_ID,
        "trade_date": "20260921",
        "truth_scope": TRUTH_SCOPE,
        "truth_universe_version": "hk-connect-members-20260921-v1",
        "truth_source_version": "hk-close-gain-source-v1",
        "truth_input_sha256": sha256_bytes(canonical_json(canonical_truth)),
        "truth_manifest_sha256": source_sha,
        "truth_source_artifact": {"path": str(source_path), "sha256": source_sha},
        "truth_complete": True,
        "truth_universe_count": len(universe_rows),
        "truth_coverage_ratio": 1.0,
        "truth_top20_codes": top20,
        "truth_tie_break": "gain_desc_then_security_id_asc",
        "gain_definition": "close/pre_close-1_raw",
        "labels_captured_at": "2026-09-21T16:10:00+08:00",
        "rows": [
            {
                "security_id": row["security_id"],
                "close_top20_rank": rank_by_code.get(row["security_id"]),
                "hit_top20": row["security_id"] in rank_by_code,
                "close_price": 11.0,
                "close_price_source": "HK_CONNECT_FULL_CLOSE_V1",
                "currency": "HKD",
                "adjustment_mode": "RAW",
            }
            for row in _rows()
        ],
    }


def test_real_comparator_baseline_and_margin_candidate_are_bounded() -> None:
    built = build_shadow(_payload())

    assert built["baseline"]["codes"] == [f"HK.C{i:02d}" for i in range(1, 11)]
    assert built["candidate"]["codes"] == [
        *[f"HK.C{i:02d}" for i in range(1, 9)],
        "HK.C11",
        "HK.C09",
    ]
    assert built["receipt"]["selection"]["tau"] == pytest.approx(0.2)
    assert built["receipt"]["selection"]["changed_in"] == ["HK.C11"]
    assert built["receipt"]["selection"]["changed_out"] == ["HK.C10"]
    assert built["receipt"]["pre_score_key_order"] == ["bucket_weight", "no_trade_gate"]
    assert all(row["selection_reason"] for row in built["members"]["rows"])


def test_formula_states_are_h_n_u_and_missing_or_future_inputs_fail_closed() -> None:
    bad_state = _payload()
    bad_state["rows"][0]["f1_state"] = "P"
    with pytest.raises(ShadowInvalid, match="H, N, or U"):
        build_shadow(bad_state)

    future_formula = _payload()
    future_formula["formula_provenance"]["source_asof"] = "2026-09-21T09:36:00+08:00"
    with pytest.raises(ShadowInvalid, match="after the stage cutoff"):
        build_shadow(future_formula)


def test_immutable_freeze_labels_and_truth_scope(tmp_path: Path) -> None:
    persistent = _persistent_payload(tmp_path)
    frozen = freeze_snapshot(persistent, tmp_path)
    run_root = Path(frozen["run_root"])
    verified = verify_frozen_artifacts(run_root)
    assert verified["status"] == "PASS"
    assert frozen["safety"]["production_allowed"] is False

    with pytest.raises(ShadowInvalid, match="refusing to overwrite"):
        freeze_snapshot(persistent, tmp_path)

    labels = append_labels(run_root, _labels(tmp_path))
    assert labels["status"] == "READY"
    result = evaluate_run(run_root)
    assert result["status"] == "READY"
    assert result["baseline_hit_count"] == 9
    assert result["candidate_hit_count"] == 10
    assert result["delta_hit_count"] == 1
    assert result["d1_pool_recall"] == pytest.approx(1.0)
    aggregate = evaluate_runs([run_root])
    assert aggregate["fixed_p10_denominator"] == 10
    assert aggregate["fixed_recall20_denominator"] == 20
    assert aggregate["delta_p_points"] == pytest.approx(0.1)
    assert aggregate["changed_in_count"] == 1

    invalid = _labels(tmp_path)
    invalid["truth_scope"] = "CONDITIONAL_POSITIVE_CAP_TOP20_ONLY"
    second_payload = _persistent_payload(tmp_path, stage="STAGE_0945_1030")
    second = freeze_snapshot(second_payload, tmp_path)
    invalid_result = append_labels(Path(second["run_root"]), invalid)
    assert invalid_result["status"] == "CANNOT_CONFIRM"
    assert "labels/invalid_ledger.json" in str(Path(second["run_root"]) / "labels" / "invalid_ledger.json")


def test_preflight_rejects_legacy_archive_and_does_not_count_a_natural_day() -> None:
    payload = _metadata()
    payload.update({"source_mode": "LEGACY_ARCHIVE", "rows": _rows()})
    result = preflight_input(payload)
    assert result["status"] == "REJECTED"
    assert result["forward_eligible"] is False
    assert "LEGACY_OR_PROXY_SOURCE_REJECTED" in result["reasons"]
    assert result["natural_sample_count"] == 0
    assert result["counts_as_forward_day"] is False


def test_tampering_with_frozen_baseline_is_detected(tmp_path: Path) -> None:
    frozen = freeze_snapshot(_persistent_payload(tmp_path), tmp_path)
    path = Path(frozen["run_root"]) / "baseline_top10.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    data["codes"][0] = "HK.TAMPERED"
    path.write_text(json.dumps(data), encoding="utf-8")
    with pytest.raises(ShadowInvalid, match="hash mismatch"):
        verify_frozen_artifacts(Path(frozen["run_root"]))


def test_tampering_with_labels_is_cannot_confirm(tmp_path: Path) -> None:
    frozen = freeze_snapshot(_persistent_payload(tmp_path), tmp_path)
    run_root = Path(frozen["run_root"])
    assert append_labels(run_root, _labels(tmp_path))["status"] == "READY"
    labels_path = run_root / "labels" / "labels.json"
    payload = json.loads(labels_path.read_text(encoding="utf-8"))
    payload["rows"][0]["hit_top20"] = False
    labels_path.write_text(json.dumps(payload), encoding="utf-8")
    result = evaluate_run(run_root)
    assert result["status"] == "CANNOT_CONFIRM"
    assert result["invalid_reasons"] == ["LABEL_HASH_MISMATCH"]


def _selector_rows() -> list[dict]:
    return [
        {
            "code": f"HK.S{index:03d}",
            "candidate_lanes": ["LIVE_HKCONNECT_GAINER", "LOW_FLOAT_FILTER"],
            "platform_circular_market_cap_hkd_yi": 80.0,
            "offer_float_market_cap_hkd_yi": 15.0,
            "pct_chg": 20.0 - index / 10.0,
            "volume_ratio": 2.0,
            "turnover_hkd_yi": 0.5,
            "turnover_rate": 5.0,
            "last_price": 10.0 + index / 100,
            "update_time": "2026-09-21T09:34:00+08:00",
            "currency": "HKD",
            "adjustment_mode": "RAW",
            "price_source": "HK_SELECTOR_TEST",
            "stage_id": "STAGE_0930_0935",
        }
        for index in range(1, 101)
    ]


def _selector_capture_input(tmp_path: Path) -> dict:
    rows = _selector_rows()
    source_path = tmp_path / "selector-source.json"
    source_path.write_text(json.dumps({"rows": rows}, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    source_sha = hashlib.sha256(source_path.read_bytes()).hexdigest()
    rule_path = tmp_path / "selector-rule.txt"
    rule_path.write_text("selector-rule-v1", encoding="utf-8")
    rule_sha = hashlib.sha256(rule_path.read_bytes()).hexdigest()
    formula_rows = [
        {
            "security_id": row["code"],
            "f1_state": "H" if index == 11 else "N",
            "f2_state": "N",
            "f3_state": "U" if index == 12 else "N",
            "f4_state": "N",
        }
        for index, row in enumerate(rows, start=1)
    ]
    formula_path = tmp_path / "selector-formula.json"
    formula_path.write_text(json.dumps({"rows": formula_rows}, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    formula_sha = hashlib.sha256(formula_path.read_bytes()).hexdigest()
    d1_path = tmp_path / "selector-d1.json"
    d1_path.write_text(json.dumps({"rows": rows}, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    d1_sha = hashlib.sha256(d1_path.read_bytes()).hexdigest()
    return {
        "metadata": {
            "experiment_id": EXPERIMENT_ID,
            "observation_mode": "FORWARD_NATURAL",
            "captured_at": "2026-09-21T09:35:00+08:00",
            "trade_date": "20260921",
            "stage": "STAGE_0930_0935",
            "cutoff_ts": "2026-09-21T09:35:05+08:00",
            "market": "HK_CONNECT",
            "source_version": "v4.hk.production.selector.v1",
            "input_sha256": source_sha,
            "rule_sha256": rule_sha,
            "comparator_version": COMPARATOR_VERSION,
            "run_id": "hk-selector-capture-20260921-093505",
            "raw_artifact_sha256": source_sha,
            "source_artifact": {"path": str(source_path), "sha256": source_sha},
            "rule_artifact": {"path": str(rule_path), "sha256": rule_sha},
            "formula_provenance": {
                "source_version": "hk-formula-state-v1",
                "input_sha256": formula_sha,
                "rule_sha256": rule_sha,
                "source_asof": "2026-09-20",
                "frozen_at": "2026-09-20T18:00:00+08:00",
                "artifact": {"path": str(formula_path), "sha256": formula_sha},
            },
            "source_evidence": ["selection_contract=V3_TOP10_RECOMMENDATION"],
            "requested_rows": 100,
        },
        "rows": rows,
        "formula_manifest": {
            "version": "hk-formula-manifest-v1",
            "manifest_sha256": formula_sha,
            "input_sha256": formula_sha,
            "rule_sha256": rule_sha,
            "artifact": {"path": str(formula_path), "sha256": formula_sha},
            "rows": formula_rows,
        },
        "time_evidence": {"source": "selector-test", "captured_at": "2026-09-21T09:35:00+08:00"},
        "d1_manifest": {
            "version": "hk-d1-manifest-v1",
            "manifest_sha256": d1_sha,
            "artifact": {"path": str(d1_path), "sha256": d1_sha},
        },
    }


def test_selector_shadow_hook_is_default_off_full_sorted_and_failure_isolated() -> None:
    rows = _selector_rows()
    kwargs = {
        "source_evidence": ("selection_contract=V3_TOP10_RECOMMENDATION",),
    }
    off = select_hk_four_lane(rows, "20260921", "STAGE_0930_0935", "a" * 64, **kwargs)
    captured: list[dict] = []
    on = select_hk_four_lane(
        rows,
        "20260921",
        "STAGE_0930_0935",
        "a" * 64,
        shadow_capture=lambda **value: captured.append(value),
        **kwargs,
    )
    assert on == off
    assert len(captured) == 1
    assert len(captured[0]["raw_rows"]) == 100
    assert len(captured[0]["sorted_rows"]) == 100
    assert all(row["selection_eligible"] is True for row in captured[0]["sorted_rows"])
    assert all(row["formal_eligible"] is False for row in captured[0]["production_rows"])
    assert [row["code"] for row in captured[0]["sorted_rows"][:10]] == [row["code"] for row in off["rows"]]

    def broken(**_: object) -> None:
        raise OSError("shadow disk unavailable")

    assert select_hk_four_lane(rows, "20260921", "STAGE_0930_0935", "a" * 64, shadow_capture=broken, **kwargs) == off


def test_real_selector_capture_assigns_ranks_and_freezes_baseline(tmp_path: Path) -> None:
    payload = _selector_capture_input(tmp_path)
    captured: list[dict] = []
    selected = select_hk_four_lane(
        payload["rows"],
        "20260921",
        "STAGE_0930_0935",
        payload["metadata"]["raw_artifact_sha256"],
        source_evidence=tuple(payload["metadata"]["source_evidence"]),
        shadow_capture=lambda **value: captured.append(value),
        shadow_context=payload["metadata"],
    )
    assert selected["rows"]
    shadow_payload = build_selector_capture_payload(
        metadata=payload["metadata"],
        raw_rows=captured[0]["raw_rows"],
        sorted_rows=captured[0]["sorted_rows"],
        production_rows=captured[0]["production_rows"],
        formula_manifest=payload["formula_manifest"],
        time_evidence=payload["time_evidence"],
        d1_manifest=payload["d1_manifest"],
        raw_artifact_sha256=payload["metadata"]["raw_artifact_sha256"],
    )
    built = build_shadow(shadow_payload, require_full_pool=True, require_artifacts=True)
    assert built["baseline"]["codes"] == [row["code"] for row in selected["rows"]]
    assert sorted(row["production_rank"] for row in built["members"]["rows"]) == list(range(1, 101))
    manual = capture_selector_snapshot(payload, tmp_path / "shadow-output")
    assert manual["status"] == "READY"
    assert manual["capture"]["status"] == "FROZEN"
    assert manual["capture"]["selector_top10_codes"] == [row["code"] for row in selected["rows"]]


def test_persistent_freeze_requires_full_pool_and_real_artifact_binding(tmp_path: Path) -> None:
    with pytest.raises(ShadowInvalid, match="complete 100-row D1 pool"):
        freeze_snapshot(_payload(), tmp_path)
    payload = _persistent_payload(tmp_path)
    payload["input_sha256"] = "a" * 64
    with pytest.raises(ShadowInvalid, match="source_artifact SHA is not bound"):
        freeze_snapshot(payload, tmp_path)


def test_alias_conflict_and_preflight_short_rows_fail_closed() -> None:
    conflict = _payload()
    conflict["rows"][0]["bucket_weight"] = 0
    with pytest.raises(ShadowInvalid, match="bucket_weight conflicts"):
        build_shadow(conflict)
    short = _metadata()
    short["rows"] = []
    result = preflight_input(short)
    assert result["status"] == "REJECTED"
    assert result["forward_eligible"] is False
    assert any(reason.startswith("INPUT_VALIDATION:") for reason in result["reasons"])


def test_truth_is_computed_from_verified_full_universe_and_fake_top20_is_rejected(tmp_path: Path) -> None:
    frozen = freeze_snapshot(_persistent_payload(tmp_path), tmp_path)
    labels = _labels(tmp_path)
    labels["truth_top20_codes"] = [f"HK.C{i:02d}" for i in range(1, 21)]
    result = append_labels(Path(frozen["run_root"]), labels)
    assert result["status"] == "CANNOT_CONFIRM"
    assert any("verified full-universe" in reason for reason in result["invalid_reasons"])


def test_hit_evaluation_survives_missing_markout_semantics(tmp_path: Path) -> None:
    frozen = freeze_snapshot(_persistent_payload(tmp_path), tmp_path)
    labels = _labels(tmp_path)
    labels["rows"][0].pop("currency")
    labels["rows"][0].pop("adjustment_mode")
    labels["rows"][0].pop("close_price_source")
    result = append_labels(Path(frozen["run_root"]), labels)
    assert result["status"] == "READY"
    assert result["markout_invalid_reasons"]
    evaluation = evaluate_run(Path(frozen["run_root"]))
    assert evaluation["status"] == "READY"
    assert evaluation["baseline_hit_count"] == 9
    assert evaluation["candidate_hit_count"] == 10
    assert evaluation["markout"]["status"] == "CANNOT_CONFIRM"


def test_evaluate_runs_reports_planned_valid_invalid_without_zero_filling(tmp_path: Path) -> None:
    first = freeze_snapshot(_persistent_payload(tmp_path), tmp_path)
    assert append_labels(Path(first["run_root"]), _labels(tmp_path))["status"] == "READY"
    second = freeze_snapshot(_persistent_payload(tmp_path, stage="STAGE_0945_1030"), tmp_path)
    aggregate = evaluate_runs([first["run_root"], second["run_root"]])
    assert aggregate["planned_units"] == 2
    assert aggregate["valid_units"] == 1
    assert aggregate["invalid_units"] == 1
    assert aggregate["evaluation_status"] == "CANNOT_CONFIRM"
    assert aggregate["fixed_p10_denominator"] == 10
    assert aggregate["changed_in_count"] == 1
