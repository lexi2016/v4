"""Frozen, read-only V4 formula-margin shadow experiment.

This module is deliberately a small boundary around an *already materialized*
V4 HK Connect snapshot.  It does not collect quotes, calculate any formula,
call the production selector, alter a BUY gate, or create a scheduled job.
The caller supplies the real production rows and the verified H/N/U formula
states, then this module records two immutable arms:

* B: the production comparator's Top10;
* F: the same order, with a frozen formula tie-break inside the rank-10
  score-margin class only.

The close truth is a separate append-only input.  In particular, a historic
fixture or a conditional/positive-market-cap Top20 cannot satisfy the current
truth contract.  The implementation keeps that separation in code so a
retrospective archive cannot silently become a forward observation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import statistics
import tempfile
from datetime import date, datetime, time
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
from zoneinfo import ZoneInfo


EXPERIMENT_ID = "V4_FORMULA_MARGIN_SHADOW_V1"
SCHEMA_VERSION = "v4.formula_margin_shadow.v1"
INPUT_SCHEMA_VERSION = "v4.formula_margin_shadow.input.v1"
LABEL_SCHEMA_VERSION = "v4.formula_margin_shadow.labels.v1"
RULE_VERSION = "formula_margin_shadow_v1.frozen"

TRUTH_SCOPE = "HK_CONNECT_FULL_UNIVERSE_CLOSE_GAIN_TOP20"
MARKET = "HK_CONNECT"
TOP_K = 10
TRUTH_K = 20
POOL_LIMIT = 100
FORMULA_STATES = ("H", "N", "U")
SHANGHAI = ZoneInfo("Asia/Shanghai")
SHA256_LENGTH = 64

# This is the only natural forward schedule admitted by this experiment.
STAGE_CUTOFFS: dict[str, str] = {
    "STAGE_0930_0935": "09:35:05",
    "STAGE_0945_1030": "10:30:00",
    "STAGE_1445_1500": "15:00:00",
}

# hk_legacy_stage_sort_key is a descending tuple.  The first two components
# are the score-before keys and therefore are part of the equivalence class.
COMPARATOR_VERSION = "hk_legacy_stage_sort_key"
COMPARATOR_KEY_NAMES = (
    "bucket_weight",
    "no_trade_gate",
    "stage_score",
    "pct_chg",
    "volume_ratio",
)
PRE_SCORE_KEY_NAMES = COMPARATOR_KEY_NAMES[:2]

SAFETY_FLAGS = {
    "research_only": True,
    "shadow_only": True,
    "production_allowed": False,
    "buy_gate_updated": False,
    "orders_sent": False,
    "automation_created": False,
}


class ShadowInvalid(ValueError):
    """Raised when a snapshot or label cannot satisfy the frozen contract."""


def canonical_json(value: Any) -> bytes:
    """Return the hash/signature encoding used by every immutable artifact."""

    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha256_file(path: Path | str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _is_sha(value: Any) -> bool:
    if not isinstance(value, str) or len(value) != SHA256_LENGTH:
        return False
    try:
        int(value, 16)
    except ValueError:
        return False
    return True


def _finite(value: Any) -> float:
    if isinstance(value, bool) or value in (None, ""):
        raise ShadowInvalid("finite numeric value is required")
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise ShadowInvalid(f"not a numeric value: {value!r}") from error
    if not math.isfinite(result):
        raise ShadowInvalid("non-finite numeric value")
    return result


def _exact_date(value: Any, label: str) -> str:
    text = str(value or "").strip().replace("-", "")
    if len(text) != 8 or not text.isdigit():
        raise ShadowInvalid(f"{label} must be YYYYMMDD")
    try:
        date(int(text[:4]), int(text[4:6]), int(text[6:8]))
    except ValueError as error:
        raise ShadowInvalid(f"{label} is not a calendar date") from error
    return text


def _parse_timestamp(value: Any, trade_date: str, label: str) -> datetime:
    """Parse an explicit Shanghai timestamp; a time-only value uses the date."""

    text = str(value or "").strip()
    if not text:
        raise ShadowInvalid(f"{label} is missing")
    if len(text) == 8 and text.isdigit():
        text = f"{text[:4]}-{text[4:6]}-{text[6:]}T00:00:00"
    elif len(text) <= 8 and text.count(":") in (1, 2):
        text = f"{trade_date[:4]}-{trade_date[4:6]}-{trade_date[6:]}T{text}"
    else:
        text = text.replace("/", "-").replace("Z", "+00:00")
        if "T" not in text and " " in text:
            text = text.replace(" ", "T", 1)
        if "T" not in text and len(text) == 10:
            text += "T00:00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as error:
        raise ShadowInvalid(f"{label} is not an ISO timestamp: {value!r}") from error
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=SHANGHAI)
    return parsed.astimezone(SHANGHAI)


def _canonical_code(value: Any) -> str:
    text = str(value or "").strip().upper()
    if not text:
        raise ShadowInvalid("security_id/code is required")
    return text


def _lane_labels(value: Any, label: str = "lane") -> tuple[str, ...]:
    """Canonicalize lane labels without guessing from a delimited string.

    A string remains one literal lane label.  A list/tuple/set is a genuine
    multi-label value and compares order-insensitively.  We never map
    ``candidate_bucket`` or ``formal_eligible`` to a lane.
    """

    if isinstance(value, str):
        labels = [value.strip()]
    elif isinstance(value, (list, tuple, set, frozenset)):
        labels = [str(item).strip() for item in value]
    else:
        raise ShadowInvalid(f"{label} must be a lane label or label list")
    labels = [item for item in labels if item]
    if not labels:
        raise ShadowInvalid(f"{label} cannot be empty")
    return tuple(sorted(dict.fromkeys(labels)))


def _formula_state(row: Mapping[str, Any], name: str) -> str:
    value = row.get(name)
    if value not in FORMULA_STATES:
        raise ShadowInvalid(f"{name} must be exactly H, N, or U")
    return str(value)


def _bucket_weight(row: Mapping[str, Any]) -> int:
    derived: int | None = None
    if "candidate_bucket" in row:
        derived = {
            "SMALLCAP_DEMON_MAIN": 2,
            "FOUR_LANE_OBSERVATION": 1,
        }.get(str(row.get("candidate_bucket") or ""), 0)
    if "bucket_weight" in row:
        value = row.get("bucket_weight")
        if isinstance(value, bool):
            raise ShadowInvalid("bucket_weight cannot be bool")
        try:
            numeric = int(value)
        except (TypeError, ValueError) as error:
            raise ShadowInvalid("bucket_weight must be an integer") from error
        if numeric not in (0, 1, 2):
            raise ShadowInvalid("bucket_weight is outside hk comparator domain")
        if derived is not None and numeric != derived:
            raise ShadowInvalid("bucket_weight conflicts with candidate_bucket")
        return numeric
    if "candidate_bucket" not in row:
        raise ShadowInvalid("candidate_bucket/bucket_weight is required")
    return int(derived)


def _no_trade_gate(row: Mapping[str, Any]) -> int:
    derived: int | None = None
    if "trade_status_contract" in row or "trade_status" in row:
        contract = str(row.get("trade_status_contract") or row.get("trade_status") or "")
        derived = 0 if contract == "NO_TRADE" else 1
    if "no_trade_gate" in row:
        value = row.get("no_trade_gate")
        if isinstance(value, bool):
            raise ShadowInvalid("no_trade_gate cannot be bool")
        try:
            numeric = int(value)
        except (TypeError, ValueError) as error:
            raise ShadowInvalid("no_trade_gate must be an integer") from error
        if numeric not in (0, 1):
            raise ShadowInvalid("no_trade_gate is outside hk comparator domain")
        if derived is not None and numeric != derived:
            raise ShadowInvalid("no_trade_gate conflicts with trade_status_contract")
        return numeric
    if "trade_status_contract" not in row and "trade_status" not in row:
        raise ShadowInvalid("trade_status_contract/trade_status is required")
    return int(derived)


def hk_legacy_stage_sort_key(row: Mapping[str, Any]) -> tuple[int, int, float, float, float]:
    """The frozen production comparator used for the HK shadow baseline.

    This is a read-only parity copy.  It intentionally does not call or
    modify the production selection module, so the shadow cannot become a
    second production selector.
    """

    bucket_weight = _bucket_weight(row)
    no_trade_gate = _no_trade_gate(row)
    stage_score = _finite(row.get("stage_score"))
    # The production comparator's ``or`` behavior is part of the frozen
    # comparator contract.  Snapshot validation still requires the fields to
    # exist and be finite so a missing sorting input cannot be disguised.
    pct_raw = _finite(row.get("pct_chg"))
    volume_raw = _finite(row.get("volume_ratio"))
    pct_chg = pct_raw or -999.0
    volume_ratio = volume_raw or 0.0
    return bucket_weight, no_trade_gate, stage_score, pct_chg, volume_ratio


def _row_score(row: Mapping[str, Any]) -> float:
    # ``stage_score`` is authoritative.  ``production_score`` is accepted only
    # as an explicit serialized alias; a display ``score`` is never used.
    if row.get("stage_score") not in (None, ""):
        return _finite(row.get("stage_score"))
    if row.get("production_score") not in (None, ""):
        return _finite(row.get("production_score"))
    raise ShadowInvalid("real stage_score/production_score is required")


def _source_binding(metadata: Mapping[str, Any], *, require_artifacts: bool = False) -> dict[str, Any]:
    source_version = str(metadata.get("source_version") or "").strip()
    input_sha = metadata.get("input_sha256", metadata.get("input_sha"))
    rule_sha = metadata.get("rule_sha256", metadata.get("rule_sha"))
    comparator_version = str(metadata.get("comparator_version") or "").strip()
    run_id = str(metadata.get("run_id") or "").strip()
    if not source_version:
        raise ShadowInvalid("production source_version is required")
    if not _is_sha(input_sha):
        raise ShadowInvalid("production input_sha256 is required")
    if not _is_sha(rule_sha):
        raise ShadowInvalid("production rule_sha256 is required")
    if comparator_version != COMPARATOR_VERSION:
        raise ShadowInvalid(
            f"comparator_version must be {COMPARATOR_VERSION}, got {comparator_version!r}"
        )
    if not run_id:
        raise ShadowInvalid("production run_id is required for baseline binding")
    rule_artifact = _checked_file_artifact(
        metadata.get("rule_artifact"),
        "rule_artifact",
        expected_sha=str(rule_sha).lower(),
        required=require_artifacts,
    )
    return {
        "source_version": source_version,
        "input_sha256": str(input_sha).lower(),
        "rule_sha256": str(rule_sha).lower(),
        "comparator_version": comparator_version,
        "run_id": run_id,
        "rule_artifact": rule_artifact,
    }


def _checked_file_artifact(
    artifact: Any,
    label: str,
    *,
    expected_sha: str | None = None,
    required: bool = False,
) -> dict[str, Any] | None:
    if artifact is None:
        if required:
            raise ShadowInvalid(f"{label} actual artifact bytes are required")
        return None
    if not isinstance(artifact, Mapping):
        raise ShadowInvalid(f"{label} must be an object")
    path = Path(str(artifact.get("path") or "")).expanduser()
    declared = artifact.get("sha256", artifact.get("manifest_sha256"))
    if not path.is_file() or path.is_symlink() or not _is_sha(declared):
        raise ShadowInvalid(f"{label} path/SHA is invalid")
    actual = sha256_file(path)
    if actual != str(declared).lower():
        raise ShadowInvalid(f"{label} SHA mismatch")
    if expected_sha is not None and actual != str(expected_sha).lower():
        raise ShadowInvalid(f"{label} SHA is not bound to the declared input SHA")
    return {"path": str(path.resolve()), "sha256": actual, "bytes": path.stat().st_size}


def _formula_provenance(
    metadata: Mapping[str, Any],
    trade_date: str,
    cutoff: datetime,
    *,
    require_artifact: bool = False,
) -> dict[str, Any]:
    raw = metadata.get("formula_provenance")
    if not isinstance(raw, Mapping):
        raise ShadowInvalid("formula_provenance is required; formula states cannot be inferred")
    source_version = str(raw.get("source_version") or raw.get("version") or "").strip()
    input_sha = raw.get("input_sha256", raw.get("input_sha"))
    rule_sha = raw.get("rule_sha256", raw.get("rule_sha"))
    if not source_version:
        raise ShadowInvalid("formula source_version is required")
    if any(token in source_version.upper() for token in ("LEGACY", "ARCHIVE", "HISTORICAL", "FIXTURE", "REPLAY", "PROXY")):
        raise ShadowInvalid("legacy/archive/proxy formula state cannot be a forward input")
    if not _is_sha(input_sha) or not _is_sha(rule_sha):
        raise ShadowInvalid("formula input_sha256 and rule_sha256 must be SHA-256")
    asof_value = raw.get("source_asof", raw.get("asof"))
    frozen_value = raw.get("frozen_at", raw.get("formula_frozen_at"))
    asof = _parse_timestamp(asof_value, trade_date, "formula source_asof")
    frozen = _parse_timestamp(frozen_value, trade_date, "formula frozen_at")
    if asof > cutoff or frozen > cutoff:
        raise ShadowInvalid("formula source_asof/frozen_at is after the stage cutoff")
    # A same-day formula source is allowed only up to the cutoff.  A date-only
    # D/D-1 source is therefore naturally safe, while a post-cutoff T source
    # is rejected.
    if asof.strftime("%Y%m%d") > trade_date or frozen.strftime("%Y%m%d") > trade_date:
        raise ShadowInvalid("formula provenance uses a future trade date")
    artifact_record = _checked_file_artifact(
        raw.get("artifact"),
        "formula artifact",
        expected_sha=str(input_sha).lower(),
        required=require_artifact,
    )
    return {
        "source_version": source_version,
        "input_sha256": str(input_sha).lower(),
        "rule_sha256": str(rule_sha).lower(),
        "source_asof": asof.isoformat(),
        "frozen_at": frozen.isoformat(),
        "artifact": artifact_record,
    }


def _verify_formula_artifact_rows(
    artifact: Mapping[str, Any] | None,
    rows: Sequence[Mapping[str, Any]],
) -> None:
    """Ensure persisted formula states agree with the verified artifact bytes."""

    if not isinstance(artifact, Mapping):
        return
    artifact_payload = _read_json(Path(str(artifact["path"])))
    if not isinstance(artifact_payload, Mapping):
        raise ShadowInvalid("formula artifact must contain an object")
    source = artifact_payload.get("states")
    if source is None:
        source = artifact_payload.get("rows")
    if source is None:
        source = artifact_payload.get("by_code")
    if isinstance(source, Mapping):
        iterable = [dict(value, security_id=key) if isinstance(value, Mapping) else value for key, value in source.items()]
    elif isinstance(source, list):
        iterable = source
    else:
        raise ShadowInvalid("formula artifact states/rows are required")
    actual: dict[str, tuple[str, str, str, str]] = {}
    for raw in iterable:
        if not isinstance(raw, Mapping):
            raise ShadowInvalid("formula artifact state rows must be objects")
        code = _canonical_code(raw.get("security_id", raw.get("code")))
        actual[code] = tuple(_formula_state(raw, f"f{i}_state") for i in range(1, 5))
    expected = {
        _canonical_code(row.get("security_id", row.get("code"))): tuple(
            _formula_state(row, f"f{i}_state") for i in range(1, 5)
        )
        for row in rows
    }
    if actual != expected:
        raise ShadowInvalid("formula states do not match the verified artifact bytes")


def _stage_contract(metadata: Mapping[str, Any]) -> tuple[str, str, str, datetime]:
    trade_date = _exact_date(metadata.get("trade_date"), "trade_date")
    stage_id = str(metadata.get("stage") or metadata.get("stage_id") or "").strip()
    if stage_id not in STAGE_CUTOFFS:
        raise ShadowInvalid(f"stage must be one of {tuple(STAGE_CUTOFFS)}")
    cutoff = _parse_timestamp(metadata.get("cutoff_ts"), trade_date, "cutoff_ts")
    expected = time.fromisoformat(STAGE_CUTOFFS[stage_id])
    if cutoff.strftime("%H:%M:%S") != expected.strftime("%H:%M:%S"):
        raise ShadowInvalid(f"{stage_id} cutoff must be {STAGE_CUTOFFS[stage_id]}")
    if cutoff.strftime("%Y%m%d") != trade_date:
        raise ShadowInvalid("cutoff_ts must be on trade_date")
    if str(metadata.get("market") or MARKET) != MARKET:
        raise ShadowInvalid("formula margin shadow is HK_CONNECT only")
    return trade_date, stage_id, cutoff.isoformat(), cutoff


def _validate_price(row: Mapping[str, Any], cutoff: datetime) -> dict[str, Any]:
    price = _finite(row.get("stage_price"))
    if price <= 0:
        raise ShadowInvalid("stage_price must be positive")
    price_ts = _parse_timestamp(row.get("price_ts"), cutoff.strftime("%Y%m%d"), "price_ts")
    if price_ts > cutoff:
        raise ShadowInvalid("stage price was captured after the cutoff")
    currency = str(row.get("currency") or "").strip().upper()
    adjustment = str(row.get("adjustment_mode") or "").strip()
    source = str(row.get("price_source") or "").strip()
    if not currency or not adjustment or not source:
        raise ShadowInvalid("stage price currency/adjustment_mode/price_source are required")
    return {
        "stage_price": price,
        "price_ts": price_ts.isoformat(),
        "currency": currency,
        "adjustment_mode": adjustment,
        "price_source": source,
    }


def _normalise_row(row: Mapping[str, Any], cutoff: datetime) -> dict[str, Any]:
    if not isinstance(row, Mapping):
        raise ShadowInvalid("snapshot rows must be objects")
    code = _canonical_code(row.get("security_id", row.get("code")))
    if type(row.get("eligible")) is not bool:
        raise ShadowInvalid(f"{code}: eligible must be an explicit bool")
    if "selection_eligible" in row:
        if type(row.get("selection_eligible")) is not bool:
            raise ShadowInvalid(f"{code}: selection_eligible must be an explicit bool")
        if row.get("selection_eligible") is not row.get("eligible"):
            raise ShadowInvalid(f"{code}: selection_eligible/eligible disagree")
    lane_value = row.get("lane", row.get("lane_labels"))
    lane = _lane_labels(lane_value)
    score = _row_score(row)
    if "stage_score" not in row and "production_score" in row:
        # Preserve the explicit alias but make the canonical score visible.
        row = {**row, "stage_score": score}
    comparator = hk_legacy_stage_sort_key(row)
    raw_rank = row.get("production_rank")
    if row["eligible"]:
        if isinstance(raw_rank, bool) or not isinstance(raw_rank, int) or raw_rank < 1:
            raise ShadowInvalid(f"{code}: eligible row needs positive production_rank")
        rank: int | None = raw_rank
    else:
        if raw_rank not in (None, ""):
            raise ShadowInvalid(f"{code}: ineligible row must not carry production_rank")
        rank = None
    result: dict[str, Any] = {
        "security_id": code,
        "code": code,
        "eligible": bool(row["eligible"]),
        "lane": list(lane),
        "stage_score": score,
        "production_score": score,
        "production_rank": rank,
        "comparator_key": list(comparator),
        "pre_score_key": list(comparator[:2]),
        "comparator_version": COMPARATOR_VERSION,
        "f1_state": _formula_state(row, "f1_state"),
        "f2_state": _formula_state(row, "f2_state"),
        "f3_state": _formula_state(row, "f3_state"),
        "f4_state": _formula_state(row, "f4_state"),
        **_validate_price(row, cutoff),
    }
    for optional in (
        "name",
        "candidate_bucket",
        "trade_status_contract",
        "trade_status",
        "pct_chg",
        "volume_ratio",
        "formal_eligible",
        "selection_eligible",
    ):
        if optional in row:
            result[optional] = row[optional]
    result["formula_any_H"] = any(result[f"f{i}_state"] == "H" for i in range(1, 5))
    return result


def _validate_rows(rows: Sequence[Mapping[str, Any]], cutoff: datetime, *, require_full_pool: bool) -> list[dict[str, Any]]:
    if not isinstance(rows, Sequence) or isinstance(rows, (str, bytes)):
        raise ShadowInvalid("rows must be a sequence")
    if len(rows) < TOP_K:
        raise ShadowInvalid("at least ten D1 members are required")
    if require_full_pool and len(rows) != POOL_LIMIT:
        raise ShadowInvalid(f"full D1 Top100 is required; got {len(rows)} rows")
    normalised = [_normalise_row(row, cutoff) for row in rows]
    codes = [row["security_id"] for row in normalised]
    if len(set(codes)) != len(codes):
        raise ShadowInvalid("duplicate security_id in D1 snapshot")
    eligible = [row for row in normalised if row["eligible"]]
    if len(eligible) < TOP_K:
        raise ShadowInvalid("fewer than ten eligible production rows")
    ranks = [row["production_rank"] for row in eligible]
    if sorted(ranks) != list(range(1, len(eligible) + 1)):
        raise ShadowInvalid("eligible production_rank must be contiguous from one")
    eligible.sort(key=lambda item: int(item["production_rank"]))
    for previous, current in zip(eligible, eligible[1:]):
        if tuple(previous["comparator_key"]) < tuple(current["comparator_key"]):
            raise ShadowInvalid("production_rank conflicts with hk_legacy_stage_sort_key")
    return normalised


def _equivalence_class(row: Mapping[str, Any]) -> tuple[Any, ...]:
    return (tuple(row["lane"]), *tuple(row["pre_score_key"]))


def _derive_candidate(eligible: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    ordered = [dict(row) for row in sorted(eligible, key=lambda item: int(item["production_rank"]))]
    baseline = ordered[:TOP_K]
    rank10 = baseline[-1]
    by_rank = {int(row["production_rank"]): row for row in ordered}
    rank10_class = _equivalence_class(rank10)
    gaps: list[float] = []
    gap_pairs: list[dict[str, Any]] = []
    for rank in range(6, 15):
        left = by_rank.get(rank)
        right = by_rank.get(rank + 1)
        if left is None or right is None:
            continue
        if _equivalence_class(left) != rank10_class or _equivalence_class(right) != rank10_class:
            continue
        left_score = _finite(left["stage_score"])
        right_score = _finite(right["stage_score"])
        gap = left_score - right_score
        if gap < 0:
            raise ShadowInvalid("score order conflict inside rank10 equivalent class")
        gaps.append(gap)
        gap_pairs.append({"upper_rank": rank, "lower_rank": rank + 1, "gap": gap})
    if not gaps:
        raise ShadowInvalid("no valid rank6..15 score gap in rank10 equivalent class")
    tau = float(statistics.median(gaps))
    if not math.isfinite(tau) or tau < 0:
        raise ShadowInvalid("tau is not finite/non-negative")
    ambiguous = [
        row
        for row in ordered
        if _equivalence_class(row) == rank10_class
        and abs(_finite(row["stage_score"]) - _finite(rank10["stage_score"])) <= tau
    ]
    ambiguous_codes = {str(row["security_id"]) for row in ambiguous}
    reordered_ambiguous = sorted(
        ambiguous,
        key=lambda row: (not bool(row["formula_any_H"]), int(row["production_rank"])),
    )
    candidate_order = list(ordered)
    replacements = iter(reordered_ambiguous)
    for index, row in enumerate(candidate_order):
        if str(row["security_id"]) in ambiguous_codes:
            candidate_order[index] = next(replacements)
    candidate = candidate_order[:TOP_K]
    baseline_codes = {str(row["security_id"]) for row in baseline}
    candidate_codes = {str(row["security_id"]) for row in candidate}
    for row in candidate_order:
        code = str(row["security_id"])
        row["baseline_selected"] = code in baseline_codes
        row["candidate_selected"] = code in candidate_codes
        if row["baseline_selected"] and row["candidate_selected"]:
            reason = "BASELINE_AND_CANDIDATE"
        elif row["candidate_selected"]:
            reason = "FORMULA_ANY_H_IN_AMBIGUOUS_CLASS"
        elif row["baseline_selected"]:
            reason = "BASELINE_ONLY"
        elif code in ambiguous_codes:
            reason = "AMBIGUOUS_STABLE_REORDER_OUTSIDE_TOP10"
        else:
            reason = "OUTSIDE_AMBIGUOUS_CLASS"
        row["selection_reason"] = reason
        row["ambiguous"] = code in ambiguous_codes
    details = {
        "rank10_code": str(rank10["security_id"]),
        "rank10_equivalence_class": {
            "lane": list(rank10_class[0]),
            "pre_score_key": list(rank10_class[1:]),
        },
        "tau": tau,
        "tau_zero_tie_only": tau == 0.0,
        "gap_pairs": gap_pairs,
        "ambiguous_codes": sorted(ambiguous_codes),
        "baseline_codes": [str(row["security_id"]) for row in baseline],
        "candidate_codes": [str(row["security_id"]) for row in candidate],
        "changed_in": sorted(candidate_codes - baseline_codes),
        "changed_out": sorted(baseline_codes - candidate_codes),
    }
    return candidate_order, details


def _metadata_from_input(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    metadata = payload.get("metadata")
    if isinstance(metadata, Mapping):
        merged = dict(metadata)
        for key, value in payload.items():
            if key not in {"metadata", "rows"} and key not in merged:
                merged[key] = value
        return merged
    return payload


def _read_json(path: Path | str) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ShadowInvalid(f"JSON is unreadable: {path}") from error


def _immutable_json(path: Path, payload: Any) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        raise ShadowInvalid(f"refusing to overwrite immutable artifact: {path}")
    encoded = canonical_json(payload)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    temporary_path = Path(temporary)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.link(temporary_path, path)
        except FileExistsError as error:
            raise ShadowInvalid(f"immutable artifact raced with another writer: {path}") from error
    finally:
        try:
            temporary_path.unlink()
        except FileNotFoundError:
            pass
    return sha256_bytes(encoded)


def _ensure_output_root(root: Path | str) -> Path:
    path = Path(root).expanduser()
    if not path.is_absolute():
        raise ShadowInvalid("shadow output root must be absolute")
    if path.is_symlink():
        raise ShadowInvalid("shadow output root cannot be symlinked")
    text = str(path)
    if any(marker in text for marker in ("/Library/Application Support/", "/releases/", "/.runtime/")):
        raise ShadowInvalid("shadow output root cannot target formal/runtime state")
    path.mkdir(parents=True, exist_ok=True)
    return path.resolve()


def _source_artifact_check(
    metadata: Mapping[str, Any],
    *,
    expected_sha: str | None = None,
    required: bool = False,
) -> dict[str, Any] | None:
    return _checked_file_artifact(
        metadata.get("source_artifact"),
        "source_artifact",
        expected_sha=expected_sha,
        required=required,
    )


def _verify_source_artifact_rows(
    artifact: Mapping[str, Any] | None,
    rows: Sequence[Mapping[str, Any]],
) -> None:
    """Check the selector snapshot's member identities and shared inputs."""

    if not isinstance(artifact, Mapping):
        return
    payload = _read_json(Path(str(artifact["path"])))
    if not isinstance(payload, Mapping):
        raise ShadowInvalid("source_artifact must contain an object")
    source_rows = payload.get("rows", payload.get("members"))
    if not isinstance(source_rows, list):
        raise ShadowInvalid("source_artifact rows are required")
    source_by_code: dict[str, Mapping[str, Any]] = {}
    for raw in source_rows:
        if not isinstance(raw, Mapping):
            raise ShadowInvalid("source_artifact rows must be objects")
        code = _canonical_code(raw.get("security_id", raw.get("code")))
        if code in source_by_code:
            raise ShadowInvalid(f"duplicate source_artifact row: {code}")
        source_by_code[code] = raw
    expected_by_code = {
        _canonical_code(row.get("security_id", row.get("code"))): row
        for row in rows
    }
    if set(source_by_code) != set(expected_by_code):
        raise ShadowInvalid("source_artifact rows do not match the snapshot members")
    shared_keys = (
        "stage_score",
        "pct_chg",
        "volume_ratio",
        "candidate_bucket",
        "trade_status_contract",
        "stage_price",
        "price_ts",
    )
    for code, source in source_by_code.items():
        expected = expected_by_code[code]
        for key in shared_keys:
            if key not in source or source.get(key) in (None, "") or key not in expected or expected.get(key) in (None, ""):
                continue
            left = source.get(key)
            right = expected.get(key)
            if key in {"stage_score", "pct_chg", "volume_ratio", "stage_price"}:
                if abs(_finite(left) - _finite(right)) > 1e-12:
                    raise ShadowInvalid(f"source_artifact {key} mismatch: {code}")
            elif left != right:
                raise ShadowInvalid(f"source_artifact {key} mismatch: {code}")


def _reject_archive_or_proxy_metadata(metadata: Mapping[str, Any]) -> None:
    """Reject labels that identify a historical/proxy source at the boundary."""

    values = (
        str(metadata.get("source_mode") or ""),
        str(metadata.get("source_kind") or ""),
        str(metadata.get("source_version") or ""),
    )
    blocked = ("LEGACY", "ARCHIVE", "HISTORICAL", "FIXTURE", "REPLAY", "PROXY", "CF")
    if any(token in value.upper() for value in values for token in blocked):
        raise ShadowInvalid("legacy/archive/proxy source cannot be a forward snapshot")


def _verified_manifest_binding(
    value: Any,
    label: str,
    *,
    require_artifact: bool = False,
) -> dict[str, Any]:
    """Return a small, hash-bound manifest descriptor for a capture input."""

    if not isinstance(value, Mapping):
        raise ShadowInvalid(f"{label} is required for a selector capture")
    binding = dict(value)
    version = str(
        binding.get("source_version")
        or binding.get("manifest_version")
        or binding.get("version")
        or ""
    ).strip()
    digest = binding.get(
        "manifest_sha256",
        binding.get("sha256", binding.get("input_sha256")),
    )
    if not version:
        raise ShadowInvalid(f"{label} version is required for a selector capture")
    if not _is_sha(digest):
        raise ShadowInvalid(f"{label} SHA is required for a selector capture")
    binding["version"] = version
    binding["sha256"] = str(digest).lower()
    artifact_record = _checked_file_artifact(
        binding.get("artifact"),
        f"{label} artifact",
        expected_sha=binding["sha256"],
        required=require_artifact,
    )
    if artifact_record is not None:
        binding["artifact"] = artifact_record
    return binding


def _formula_manifest_states(manifest: Mapping[str, Any]) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    """Extract explicit per-code H/N/U states without calculating formulas."""

    binding = _verified_manifest_binding(manifest, "formula_manifest", require_artifact=True)
    formula_input_sha = manifest.get("input_sha256", manifest.get("input_sha"))
    formula_rule_sha = manifest.get("rule_sha256", manifest.get("rule_sha"))
    if not _is_sha(formula_input_sha) or not _is_sha(formula_rule_sha):
        raise ShadowInvalid("formula_manifest input_sha256/rule_sha256 are required")
    binding["input_sha256"] = str(formula_input_sha).lower()
    binding["rule_sha256"] = str(formula_rule_sha).lower()
    source: Any = manifest.get("states")
    if source is None:
        source = manifest.get("rows")
    if source is None:
        source = manifest.get("by_code")
    if source is None and all(key in manifest for key in ("f1_state", "f2_state", "f3_state", "f4_state")):
        source = [manifest]
    if isinstance(source, Mapping):
        iterable = [dict(value, security_id=key) if isinstance(value, Mapping) else value for key, value in source.items()]
    elif isinstance(source, list):
        iterable = source
    else:
        raise ShadowInvalid("formula_manifest states/rows are required")
    states: dict[str, dict[str, Any]] = {}
    for raw in iterable:
        if not isinstance(raw, Mapping):
            raise ShadowInvalid("formula_manifest state rows must be objects")
        code = _canonical_code(raw.get("security_id", raw.get("code")))
        if code in states:
            raise ShadowInvalid(f"duplicate formula_manifest state: {code}")
        state_row = {
            f"f{i}_state": _formula_state(raw, f"f{i}_state")
            for i in range(1, 5)
        }
        states[code] = state_row
    if not states:
        raise ShadowInvalid("formula_manifest contains no per-code states")
    artifact_record = binding.get("artifact")
    if not isinstance(artifact_record, Mapping):
        raise ShadowInvalid("formula_manifest actual artifact is required")
    artifact_payload = _read_json(Path(str(artifact_record["path"])))
    if not isinstance(artifact_payload, Mapping):
        raise ShadowInvalid("formula_manifest artifact must contain an object")
    artifact_source: Any = artifact_payload.get("states")
    if artifact_source is None:
        artifact_source = artifact_payload.get("rows")
    if artifact_source is None:
        artifact_source = artifact_payload.get("by_code")
    if isinstance(artifact_source, Mapping):
        artifact_iterable = [
            dict(value, security_id=key) if isinstance(value, Mapping) else value
            for key, value in artifact_source.items()
        ]
    elif isinstance(artifact_source, list):
        artifact_iterable = artifact_source
    else:
        raise ShadowInvalid("formula_manifest artifact states/rows are required")
    artifact_states: dict[str, dict[str, str]] = {}
    for raw in artifact_iterable:
        if not isinstance(raw, Mapping):
            raise ShadowInvalid("formula_manifest artifact state rows must be objects")
        code = _canonical_code(raw.get("security_id", raw.get("code")))
        artifact_states[code] = {
            f"f{i}_state": _formula_state(raw, f"f{i}_state")
            for i in range(1, 5)
        }
    if artifact_states != states:
        raise ShadowInvalid("formula_manifest states do not match the verified artifact bytes")
    return states, binding


def _capture_price_alias(row: Mapping[str, Any], *names: str) -> Any:
    for name in names:
        if row.get(name) not in (None, ""):
            return row.get(name)
    return None


def build_selector_capture_payload(
    *,
    metadata: Mapping[str, Any],
    raw_rows: Sequence[Mapping[str, Any]],
    sorted_rows: Sequence[Mapping[str, Any]],
    production_rows: Sequence[Mapping[str, Any]],
    formula_manifest: Mapping[str, Any],
    time_evidence: Mapping[str, Any],
    d1_manifest: Mapping[str, Any],
    raw_artifact_sha256: str | None = None,
) -> dict[str, Any]:
    """Adapt a real selector hook capture into a frozen shadow input.

    The adapter assigns ``production_rank`` from the selector's full sorted
    output.  It never accepts a caller-supplied rank and never derives
    eligibility from ``formal_eligible``: rows that the selector actually
    ranked carry ``selection_eligible=True`` and become the shadow's explicit
    eligible set.  Formula states are joined only from the verified manifest;
    no formula producer or fallback is called here.
    """

    if not isinstance(metadata, Mapping):
        raise ShadowInvalid("selector capture metadata is required")
    if not isinstance(time_evidence, Mapping) or not time_evidence:
        raise ShadowInvalid("verified time_evidence is required for a selector capture")
    d1_binding = _verified_manifest_binding(d1_manifest, "d1_manifest", require_artifact=True)
    formula_states, formula_binding = _formula_manifest_states(formula_manifest)
    metadata_copy = dict(metadata)
    if raw_artifact_sha256 is None:
        raw_artifact_sha256 = metadata_copy.get("raw_artifact_sha256")
    if not _is_sha(raw_artifact_sha256):
        raise ShadowInvalid("raw_artifact_sha256 is required for a selector capture")
    source_record = _checked_file_artifact(
        metadata_copy.get("source_artifact"),
        "source_artifact",
        expected_sha=str(metadata_copy.get("input_sha256") or "").lower(),
        required=True,
    )
    rule_record = _checked_file_artifact(
        metadata_copy.get("rule_artifact"),
        "rule_artifact",
        expected_sha=str(metadata_copy.get("rule_sha256") or "").lower(),
        required=True,
    )
    metadata_copy["source_artifact"] = source_record
    metadata_copy["rule_artifact"] = rule_record
    formula_provenance = metadata_copy.get("formula_provenance")
    if not isinstance(formula_provenance, Mapping):
        raise ShadowInvalid("formula_provenance is required for a selector capture")
    formula_provenance_copy = dict(formula_provenance)
    if (
        str(formula_provenance_copy.get("input_sha256", formula_provenance_copy.get("input_sha")) or "").lower()
        != str(formula_binding["input_sha256"]).lower()
        or str(formula_provenance_copy.get("rule_sha256", formula_provenance_copy.get("rule_sha")) or "").lower()
        != str(formula_binding["rule_sha256"]).lower()
    ):
        raise ShadowInvalid("formula_manifest hashes do not match formula_provenance")
    formula_provenance_copy["artifact"] = formula_binding["artifact"]
    metadata_copy["formula_provenance"] = formula_provenance_copy
    metadata_copy["d1_manifest"] = d1_binding
    metadata_copy["time_evidence"] = dict(time_evidence)
    metadata_copy["formula_manifest_binding"] = formula_binding
    raw_input_sha = sha256_bytes(canonical_json(list(raw_rows)))
    declared_raw_input_sha = metadata_copy.get("raw_input_sha256")
    if declared_raw_input_sha not in (None, "") and str(declared_raw_input_sha).lower() != raw_input_sha:
        raise ShadowInvalid("raw_input_sha256 does not match selector input rows")
    metadata_copy["raw_input_sha256"] = raw_input_sha
    metadata_copy["raw_artifact_sha256"] = str(raw_artifact_sha256).lower()

    if not isinstance(raw_rows, Sequence) or isinstance(raw_rows, (str, bytes)):
        raise ShadowInvalid("selector raw_rows must be a sequence")
    if not isinstance(sorted_rows, Sequence) or isinstance(sorted_rows, (str, bytes)):
        raise ShadowInvalid("selector sorted_rows must be a sequence")
    if not isinstance(production_rows, Sequence) or isinstance(production_rows, (str, bytes)):
        raise ShadowInvalid("selector production_rows must be a sequence")
    if len(sorted_rows) != POOL_LIMIT:
        raise ShadowInvalid(f"full selector sorted rows are required; got {len(sorted_rows)}")
    if len(production_rows) < TOP_K:
        raise ShadowInvalid("selector production Top10 rows are missing")

    raw_by_code: dict[str, Mapping[str, Any]] = {}
    for raw in raw_rows:
        if not isinstance(raw, Mapping):
            raise ShadowInvalid("selector raw rows must be objects")
        code = _canonical_code(raw.get("security_id", raw.get("code")))
        if code in raw_by_code:
            raise ShadowInvalid(f"duplicate selector raw row: {code}")
        raw_by_code[code] = raw
    d1_artifact = d1_binding.get("artifact")
    if not isinstance(d1_artifact, Mapping):
        raise ShadowInvalid("d1_manifest actual artifact is required")
    d1_payload = _read_json(Path(str(d1_artifact["path"])))
    if not isinstance(d1_payload, Mapping):
        raise ShadowInvalid("d1_manifest artifact must contain an object")
    d1_source = d1_payload.get("rows", d1_payload.get("members"))
    if not isinstance(d1_source, list):
        raise ShadowInvalid("d1_manifest artifact rows are required")
    d1_codes = {
        _canonical_code(row.get("security_id", row.get("code")))
        for row in d1_source
        if isinstance(row, Mapping)
    }
    if d1_codes != set(raw_by_code):
        raise ShadowInvalid("d1_manifest artifact members do not match selector raw input")
    source_artifact = metadata_copy.get("source_artifact")
    if not isinstance(source_artifact, Mapping):
        raise ShadowInvalid("source_artifact actual bytes are required")
    source_payload = _read_json(Path(str(source_artifact["path"])))
    if not isinstance(source_payload, Mapping):
        raise ShadowInvalid("source_artifact must contain an object")
    source_rows = source_payload.get("rows", source_payload.get("members"))
    if not isinstance(source_rows, list):
        raise ShadowInvalid("source_artifact rows are required")
    source_codes = {
        _canonical_code(row.get("security_id", row.get("code")))
        for row in source_rows
        if isinstance(row, Mapping)
    }
    if source_codes != set(raw_by_code):
        raise ShadowInvalid("source_artifact rows do not match selector raw input")
    sorted_codes: list[str] = []
    capture_rows: list[dict[str, Any]] = []
    for rank, selected in enumerate(sorted_rows, start=1):
        if not isinstance(selected, Mapping):
            raise ShadowInvalid("selector sorted rows must be objects")
        code = _canonical_code(selected.get("security_id", selected.get("code")))
        sorted_codes.append(code)
        source = raw_by_code.get(code)
        if source is None:
            raise ShadowInvalid(f"selector raw input is missing ranked member: {code}")
        if selected.get("selection_eligible") is not True:
            raise ShadowInvalid(f"{code}: selection_eligible must come from the selector hook")
        states = formula_states.get(code)
        if states is None:
            raise ShadowInvalid(f"formula_manifest state is missing: {code}")
        merged = dict(source)
        # Comparator fields and lane labels come from the actual selector
        # output.  The raw source remains responsible for explicit price/time
        # semantics and for the original member identity.
        merged.update(dict(selected))
        merged["security_id"] = code
        merged["code"] = code
        merged["eligible"] = True
        merged["selection_eligible"] = True
        merged["production_rank"] = rank
        lane = selected.get("candidate_lanes")
        if not isinstance(lane, (list, tuple)) or not lane:
            raise ShadowInvalid(f"{code}: selector candidate_lanes are required")
        merged["lane"] = list(lane)
        merged["stage_score"] = selected.get("stage_score")
        merged["candidate_bucket"] = selected.get("candidate_bucket")
        merged["trade_status_contract"] = selected.get("trade_status_contract")
        merged["pct_chg"] = selected.get("pct_chg")
        merged["volume_ratio"] = selected.get("volume_ratio")
        merged.update(states)
        merged["stage_price"] = _capture_price_alias(merged, "stage_price", "last_price", "price", "lastPrice")
        merged["price_ts"] = _capture_price_alias(merged, "price_ts", "update_time", "source_last_bar_time")
        merged["currency"] = _capture_price_alias(merged, "currency", "quote_currency", "price_currency")
        merged["adjustment_mode"] = _capture_price_alias(merged, "adjustment_mode")
        merged["price_source"] = _capture_price_alias(merged, "price_source")
        capture_rows.append(merged)

    production_codes = [
        _canonical_code(row.get("security_id", row.get("code")))
        for row in production_rows
        if isinstance(row, Mapping)
    ]
    if len(production_codes) < TOP_K:
        raise ShadowInvalid("selector production rows contain fewer than ten codes")
    if production_codes[:TOP_K] != sorted_codes[:TOP_K]:
        raise ShadowInvalid("production Top10 does not match the selector's pre-cap sorted rows")
    if len(set(sorted_codes)) != len(sorted_codes):
        raise ShadowInvalid("duplicate selector sorted row code")
    if set(sorted_codes) != set(raw_by_code):
        raise ShadowInvalid("selector raw input/member set does not match full sorted rows")
    metadata_copy["d1_pool_size"] = len(capture_rows)
    metadata_copy["selector_capture_binding"] = {
        "raw_artifact_sha256": str(raw_artifact_sha256).lower(),
        "raw_input_sha256": raw_input_sha,
        "d1_manifest": d1_binding,
        "formula_manifest": formula_binding,
        "time_evidence": dict(time_evidence),
        "production_top10_codes": production_codes[:TOP_K],
        "selection_eligible_definition": "rows returned by select_hk_four_lane before public Top10 cap",
    }
    return {**metadata_copy, "rows": capture_rows}


def build_shadow(
    payload: Mapping[str, Any],
    *,
    require_full_pool: bool = False,
    require_artifacts: bool = False,
) -> dict[str, Any]:
    """Validate one input and build the frozen B/F artifacts in memory.

    No output is written by this function.  The returned object is suitable
    for ``freeze_snapshot`` and is also useful for a small deterministic
    canary test.
    """

    if not isinstance(payload, Mapping):
        raise ShadowInvalid("input snapshot must be an object")
    metadata = _metadata_from_input(payload)
    if metadata.get("experiment_id", EXPERIMENT_ID) != EXPERIMENT_ID:
        raise ShadowInvalid("experiment_id mismatch")
    trade_date, stage_id, cutoff_iso, cutoff = _stage_contract(metadata)
    if metadata.get("observation_mode") not in ("FORWARD_NATURAL", "FORWARD_SHADOW"):
        raise ShadowInvalid("observation_mode must be FORWARD_NATURAL/FORWARD_SHADOW")
    _reject_archive_or_proxy_metadata(metadata)
    captured_at = _parse_timestamp(metadata.get("captured_at"), trade_date, "captured_at")
    if captured_at > cutoff:
        raise ShadowInvalid("captured_at is after the stage cutoff")
    binding = _source_binding(metadata, require_artifacts=require_artifacts)
    production_source_artifact = _source_artifact_check(
        metadata,
        expected_sha=binding["input_sha256"],
        required=require_artifacts,
    )
    formula = _formula_provenance(
        metadata,
        trade_date,
        cutoff,
        require_artifact=require_artifacts,
    )
    rows = payload.get("rows")
    if rows is None:
        raise ShadowInvalid("input snapshot rows are missing")
    normalised = _validate_rows(rows, cutoff, require_full_pool=require_full_pool)
    _verify_source_artifact_rows(production_source_artifact, normalised)
    _verify_formula_artifact_rows(formula.get("artifact"), normalised)
    declared_pool_size = metadata.get("d1_pool_size")
    if declared_pool_size not in (None, ""):
        if isinstance(declared_pool_size, bool) or int(declared_pool_size) != len(normalised):
            raise ShadowInvalid("d1_pool_size does not match the recorded member rows")
    eligible = [row for row in normalised if row["eligible"]]
    original_order = sorted(eligible, key=lambda item: int(item["production_rank"]))
    candidate_order, candidate_details = _derive_candidate(eligible)
    # The B arm is always the original production order.  It must be taken
    # before the formula-only reorder; using candidate_order here would make
    # the baseline silently inherit the F arm.
    candidate_by_code = {str(row["security_id"]): row for row in candidate_order}
    baseline = [candidate_by_code[str(row["security_id"])] for row in original_order[:TOP_K]]
    # The candidate order is allowed to differ only inside the frozen class.
    # This explicit check makes a future code change fail closed.
    changed = [
        (str(left["security_id"]), str(right["security_id"]))
        for left, right in zip(sorted(eligible, key=lambda x: int(x["production_rank"])), candidate_order)
        if str(left["security_id"]) != str(right["security_id"])
    ]
    if any(
        _equivalence_class(next(row for row in eligible if str(row["security_id"]) == left))
        != _equivalence_class(next(row for row in candidate_order if str(row["security_id"]) == right))
        for left, right in changed
    ):
        raise ShadowInvalid("candidate attempted a cross-equivalence-class reorder")
    full_rows = [dict(row) for row in candidate_order]
    baseline_payload = {
        "schema_version": SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "trade_date": trade_date,
        "stage": stage_id,
        "cutoff_ts": cutoff_iso,
        "market": MARKET,
        "arm": "B",
        "codes": [str(row["security_id"]) for row in baseline],
        "rows": [dict(row) for row in baseline],
        **SAFETY_FLAGS,
    }
    candidate_payload = {
        "schema_version": SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "trade_date": trade_date,
        "stage": stage_id,
        "cutoff_ts": cutoff_iso,
        "market": MARKET,
        "arm": "F",
        "codes": [str(row["security_id"]) for row in candidate_order[:TOP_K]],
        "rows": [dict(row) for row in candidate_order[:TOP_K]],
        "selection_rule": RULE_VERSION,
        "tau": candidate_details["tau"],
        **SAFETY_FLAGS,
    }
    members_payload = {
        "schema_version": SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "trade_date": trade_date,
        "stage": stage_id,
        "cutoff_ts": cutoff_iso,
        "market": MARKET,
        "d1_pool_count": len(full_rows),
        "eligible_count": len(eligible),
        "rows": full_rows,
        **SAFETY_FLAGS,
    }
    receipt = {
        "schema_version": SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "trade_date": trade_date,
        "stage": stage_id,
        "cutoff_ts": cutoff_iso,
        "market": MARKET,
        "rule_version": RULE_VERSION,
        "comparator_version": COMPARATOR_VERSION,
        "comparator_key_order": list(COMPARATOR_KEY_NAMES),
        "pre_score_key_order": list(PRE_SCORE_KEY_NAMES),
        "production_binding": binding,
        "production_source_artifact": production_source_artifact,
        "formula_provenance": formula,
        **(
            {"selector_capture_binding": dict(metadata["selector_capture_binding"])}
            if isinstance(metadata.get("selector_capture_binding"), Mapping)
            else {}
        ),
        "selection": candidate_details,
        "d1_pool_count": len(full_rows),
        "eligible_count": len(eligible),
        "artifacts": {
            "members": {"path": "members.json"},
            "baseline": {"path": "baseline_top10.json"},
            "candidate": {"path": "candidate_top10.json"},
        },
        "labels": {"status": "PENDING_AFTER_CUTOFF", "path": "labels/labels.json"},
        "truth_scope": TRUTH_SCOPE,
        **SAFETY_FLAGS,
    }
    return {
        "root_metadata": {
            "trade_date": trade_date,
            "stage": stage_id,
            "cutoff_ts": cutoff_iso,
            "market": MARKET,
            "production_binding": binding,
            "formula_provenance": formula,
        },
        "members": members_payload,
        "baseline": baseline_payload,
        "candidate": candidate_payload,
        "receipt": receipt,
    }


def freeze_snapshot(
    payload: Mapping[str, Any],
    output_root: Path | str,
    *,
    require_full_pool: bool = True,
) -> dict[str, Any]:
    """Freeze a stage before any close label can be accepted.

    Files are created with hard-link publication and never replaced.  A
    second call for the same date/stage therefore fails instead of silently
    superseding the first baseline.
    """

    if require_full_pool is not True:
        raise ShadowInvalid("persistent freeze requires the complete 100-row D1 pool")
    raw_rows = payload.get("rows") if isinstance(payload, Mapping) else None
    if not isinstance(raw_rows, Sequence) or isinstance(raw_rows, (str, bytes)) or len(raw_rows) != POOL_LIMIT:
        raise ShadowInvalid("persistent freeze requires the complete 100-row D1 pool")
    built = build_shadow(
        payload,
        require_full_pool=True,
        require_artifacts=True,
    )
    root_meta = built["root_metadata"]
    output_path = _ensure_output_root(output_root)
    date_root = output_path / root_meta["trade_date"]
    if date_root.is_symlink():
        raise ShadowInvalid("shadow date root cannot be symlinked")
    run_root = date_root / root_meta["stage"]
    if run_root.is_symlink():
        raise ShadowInvalid("shadow run root cannot be symlinked")
    run_root.mkdir(parents=True, exist_ok=True)
    expected_paths = (
        run_root / "members.json",
        run_root / "baseline_top10.json",
        run_root / "candidate_top10.json",
        run_root / "selection_receipt.json",
    )
    if any(path.exists() or path.is_symlink() for path in expected_paths):
        raise ShadowInvalid("refusing to overwrite an existing frozen run")
    # Do not create any file until all in-memory validation has passed.
    members_sha = _immutable_json(run_root / "members.json", built["members"])
    baseline_sha = _immutable_json(run_root / "baseline_top10.json", built["baseline"])
    candidate_sha = _immutable_json(run_root / "candidate_top10.json", built["candidate"])
    receipt = dict(built["receipt"])
    receipt["artifacts"] = {
        "members": {"path": "members.json", "sha256": members_sha},
        "baseline": {"path": "baseline_top10.json", "sha256": baseline_sha},
        "candidate": {"path": "candidate_top10.json", "sha256": candidate_sha},
    }
    receipt_without_self_hash = dict(receipt)
    receipt["receipt_payload_sha256"] = sha256_bytes(canonical_json(receipt_without_self_hash))
    receipt_sha = _immutable_json(run_root / "selection_receipt.json", receipt)
    return {
        "status": "FROZEN",
        "run_root": str(run_root),
        "artifacts": {
            "members": members_sha,
            "baseline": baseline_sha,
            "candidate": candidate_sha,
            "receipt": receipt_sha,
        },
        "baseline_codes": built["baseline"]["codes"],
        "candidate_codes": built["candidate"]["codes"],
        "changed_in": built["receipt"]["selection"]["changed_in"],
        "changed_out": built["receipt"]["selection"]["changed_out"],
        "safety": dict(SAFETY_FLAGS),
    }


def record_invalid_capture(
    output_root: Path | str,
    metadata: Mapping[str, Any] | None,
    reasons: Iterable[Any],
    *,
    context: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Write one immutable pre-freeze capture invalid ledger.

    This is intentionally separate from ``labels/invalid_ledger.json``:
    capture failures happen before a baseline can be frozen and therefore
    must never look like a labelled run.  The function is best-effort for the
    selector observer boundary and returns ``CANNOT_CONFIRM`` on write
    failure instead of raising a second error into production selection.
    """

    raw_metadata = dict(metadata) if isinstance(metadata, Mapping) else {}
    trade_text = str(raw_metadata.get("trade_date") or "").replace("-", "")
    trade_component = trade_text if len(trade_text) == 8 and trade_text.isdigit() else "unknown_date"
    stage_text = str(raw_metadata.get("stage") or raw_metadata.get("stage_id") or "")
    stage_component = stage_text if stage_text in STAGE_CUTOFFS else "unknown_stage"
    reason_list = list(dict.fromkeys(str(reason) for reason in reasons if str(reason)))
    if not reason_list:
        reason_list = ["CAPTURE_INVALID"]
    try:
        root = _ensure_output_root(output_root)
        date_root = root / trade_component
        stage_root = date_root / stage_component
        if date_root.is_symlink() or stage_root.is_symlink():
            raise ShadowInvalid("capture invalid-ledger directory cannot be symlinked")
        invalid_path = stage_root / "invalid_ledger.json"
        safe_context: Any = {}
        if isinstance(context, Mapping):
            try:
                safe_context = json.loads(json.dumps(dict(context), ensure_ascii=False, default=str))
            except (TypeError, ValueError):
                safe_context = {"context_serialization": "FAILED"}
        payload = {
            "schema_version": SCHEMA_VERSION,
            "experiment_id": EXPERIMENT_ID,
            "trade_date": trade_text or None,
            "stage": stage_text or None,
            "status": "CANNOT_CONFIRM",
            "invalid_reasons": reason_list,
            "source_version": raw_metadata.get("source_version"),
            "input_sha256": raw_metadata.get("input_sha256"),
            "raw_input_sha256": raw_metadata.get("raw_input_sha256"),
            "raw_artifact_sha256": raw_metadata.get("raw_artifact_sha256"),
            "run_id": raw_metadata.get("run_id"),
            "comparator_version": raw_metadata.get("comparator_version"),
            "d1_manifest": raw_metadata.get("d1_manifest"),
            "formula_manifest_binding": raw_metadata.get("formula_manifest_binding"),
            "time_evidence": raw_metadata.get("time_evidence"),
            "context": safe_context,
            "recorded_before_selection_freeze": True,
            **SAFETY_FLAGS,
        }
        ledger_sha = _immutable_json(invalid_path, payload)
        return {
            "status": "CANNOT_CONFIRM",
            "run_root": str(stage_root),
            "invalid_ledger": str(invalid_path),
            "invalid_ledger_sha256": ledger_sha,
            "invalid_reasons": reason_list,
            "safety": dict(SAFETY_FLAGS),
        }
    except Exception as error:
        return {
            "status": "CANNOT_CONFIRM",
            "invalid_reasons": [*reason_list, f"INVALID_LEDGER_WRITE_FAILED:{error}"],
            "safety": dict(SAFETY_FLAGS),
        }


def _read_frozen(run_root: Path | str) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    root = Path(run_root).expanduser().resolve()
    paths = {
        "members": root / "members.json",
        "baseline": root / "baseline_top10.json",
        "candidate": root / "candidate_top10.json",
        "receipt": root / "selection_receipt.json",
    }
    for label, path in paths.items():
        if not path.is_file() or path.is_symlink():
            raise ShadowInvalid(f"frozen {label} artifact is missing")
    members = _read_json(paths["members"])
    baseline = _read_json(paths["baseline"])
    candidate = _read_json(paths["candidate"])
    receipt = _read_json(paths["receipt"])
    if not isinstance(members, dict) or not isinstance(baseline, dict) or not isinstance(candidate, dict) or not isinstance(receipt, dict):
        raise ShadowInvalid("frozen artifacts must be JSON objects")
    receipt_payload_sha = receipt.get("receipt_payload_sha256")
    if not _is_sha(receipt_payload_sha):
        raise ShadowInvalid("selection receipt payload SHA is missing")
    receipt_without_self_hash = dict(receipt)
    receipt_without_self_hash.pop("receipt_payload_sha256", None)
    if sha256_bytes(canonical_json(receipt_without_self_hash)) != str(receipt_payload_sha).lower():
        raise ShadowInvalid("selection receipt payload hash mismatch")
    artifacts = receipt.get("artifacts")
    if not isinstance(artifacts, Mapping):
        raise ShadowInvalid("selection receipt artifact map is missing")
    for label, path in paths.items():
        if label == "receipt":
            continue
        detail = artifacts.get(label)
        if not isinstance(detail, Mapping) or not _is_sha(detail.get("sha256")):
            raise ShadowInvalid(f"selection receipt {label} SHA is missing")
        if sha256_file(path) != str(detail["sha256"]).lower():
            raise ShadowInvalid(f"frozen {label} hash mismatch")
    for artifact in (members, baseline, candidate, receipt):
        if any(artifact.get(flag) != expected for flag, expected in SAFETY_FLAGS.items()):
            raise ShadowInvalid("safety flags changed in frozen artifact")
    if receipt.get("truth_scope") != TRUTH_SCOPE:
        raise ShadowInvalid("frozen receipt truth_scope mismatch")
    if baseline.get("arm") != "B" or candidate.get("arm") != "F":
        raise ShadowInvalid("frozen arm labels are invalid")
    if baseline.get("codes") != [row.get("security_id") for row in baseline.get("rows", [])]:
        raise ShadowInvalid("baseline codes/rows mismatch")
    if candidate.get("codes") != [row.get("security_id") for row in candidate.get("rows", [])]:
        raise ShadowInvalid("candidate codes/rows mismatch")
    return members, baseline, candidate, receipt


def verify_frozen_artifacts(run_root: Path | str) -> dict[str, Any]:
    members, baseline, candidate, receipt = _read_frozen(run_root)
    return {
        "status": "PASS",
        "run_root": str(Path(run_root).expanduser().resolve()),
        "trade_date": receipt.get("trade_date"),
        "stage": receipt.get("stage"),
        "baseline_codes": list(baseline.get("codes", [])),
        "candidate_codes": list(candidate.get("codes", [])),
        "member_count": len(members.get("rows", [])),
        "receipt_rule_version": receipt.get("rule_version"),
        "safety": {flag: receipt.get(flag) for flag in SAFETY_FLAGS},
    }


def _truth_metadata(labels: Mapping[str, Any], trade_date: str, cutoff: datetime) -> tuple[dict[str, Any], list[Mapping[str, Any]], list[str]]:
    if labels.get("schema_version") not in (LABEL_SCHEMA_VERSION, None):
        raise ShadowInvalid("label schema_version mismatch")
    if labels.get("experiment_id", EXPERIMENT_ID) != EXPERIMENT_ID:
        raise ShadowInvalid("label experiment_id mismatch")
    if _exact_date(labels.get("trade_date"), "label trade_date") != trade_date:
        raise ShadowInvalid("label trade_date mismatch")
    if labels.get("truth_scope") != TRUTH_SCOPE:
        raise ShadowInvalid("label truth_scope is not the frozen full-universe contract")
    truth_version = str(labels.get("truth_universe_version") or "").strip()
    truth_source_version = str(labels.get("truth_source_version") or "").strip()
    truth_input_sha = labels.get("truth_input_sha256", labels.get("truth_input_sha"))
    truth_manifest_sha = labels.get("truth_manifest_sha256", labels.get("truth_manifest_sha"))
    if not truth_version or not truth_source_version:
        raise ShadowInvalid("truth universe/source version is required")
    if not _is_sha(truth_input_sha) or not _is_sha(truth_manifest_sha):
        raise ShadowInvalid("truth input/manifest SHA is required")
    if labels.get("truth_complete") is not True:
        raise ShadowInvalid("truth_complete must be true")
    try:
        universe_count = int(labels.get("truth_universe_count"))
    except (TypeError, ValueError) as error:
        raise ShadowInvalid("truth_universe_count is required") from error
    if universe_count < TRUTH_K:
        raise ShadowInvalid("truth universe has fewer than twenty members")
    try:
        coverage = float(labels.get("truth_coverage_ratio"))
    except (TypeError, ValueError) as error:
        raise ShadowInvalid("truth_coverage_ratio is required") from error
    if not math.isfinite(coverage) or coverage != 1.0:
        raise ShadowInvalid("truth universe coverage is incomplete")
    tie_break = str(labels.get("truth_tie_break") or "").strip()
    gain_definition = str(labels.get("gain_definition") or "").strip()
    if tie_break != "gain_desc_then_security_id_asc":
        raise ShadowInvalid("truth tie-break must be gain_desc_then_security_id_asc")
    if gain_definition != "close/pre_close-1_raw":
        raise ShadowInvalid("truth gain definition must be close/pre_close-1_raw")
    source_artifact = _checked_file_artifact(
        labels.get("truth_source_artifact"),
        "truth_source_artifact",
        expected_sha=str(truth_manifest_sha).lower(),
        required=True,
    )
    if not isinstance(source_artifact, Mapping):
        raise ShadowInvalid("truth source artifact is required")
    source_payload = _read_json(Path(str(source_artifact["path"])))
    if not isinstance(source_payload, Mapping):
        raise ShadowInvalid("truth source artifact must contain an object")
    source_scope = str(source_payload.get("truth_scope") or source_payload.get("scope") or "").strip()
    if source_scope and source_scope != TRUTH_SCOPE:
        raise ShadowInvalid("truth source artifact scope mismatch")
    universe_rows = source_payload.get("rows", source_payload.get("members", source_payload.get("universe")))
    if not isinstance(universe_rows, list):
        raise ShadowInvalid("truth source artifact complete membership rows are required")
    if len(universe_rows) != universe_count:
        raise ShadowInvalid("truth universe count does not match the verified source artifact")
    canonical_truth_rows: list[dict[str, Any]] = []
    seen_codes: set[str] = set()
    for raw in universe_rows:
        if not isinstance(raw, Mapping):
            raise ShadowInvalid("truth universe rows must be objects")
        code = _canonical_code(raw.get("security_id", raw.get("code")))
        if code in seen_codes:
            raise ShadowInvalid(f"duplicate truth universe member: {code}")
        seen_codes.add(code)
        close_price = _finite(raw.get("close_price", raw.get("close")))
        pre_close = _finite(raw.get("pre_close_price", raw.get("pre_close")))
        if close_price <= 0 or pre_close <= 0:
            raise ShadowInvalid(f"truth close/pre_close must be positive: {code}")
        gain = close_price / pre_close - 1.0
        declared_gain = raw.get("close_gain", raw.get("gain"))
        if declared_gain not in (None, "") and abs(_finite(declared_gain) - gain) > 1e-12:
            raise ShadowInvalid(f"truth gain does not match close/pre_close: {code}")
        canonical_truth_rows.append({
            "security_id": code,
            "close_price": close_price,
            "pre_close_price": pre_close,
            "close_gain": gain,
        })
    computed_input_sha = sha256_bytes(canonical_json(canonical_truth_rows))
    if computed_input_sha != str(truth_input_sha).lower():
        raise ShadowInvalid("truth input SHA does not match verified membership/close rows")
    top20_codes = [
        row["security_id"]
        for row in sorted(
            canonical_truth_rows,
            key=lambda row: (-float(row["close_gain"]), str(row["security_id"])),
        )[:TRUTH_K]
    ]
    if len(top20_codes) != TRUTH_K:
        raise ShadowInvalid("verified truth source produced fewer than twenty members")
    declared_top20 = labels.get("truth_top20_codes")
    if declared_top20 is not None:
        if not isinstance(declared_top20, list) or [_canonical_code(value) for value in declared_top20] != top20_codes:
            raise ShadowInvalid("truth_top20_codes does not match verified full-universe close ranking")
    captured_at = _parse_timestamp(labels.get("labels_captured_at"), trade_date, "labels_captured_at")
    if captured_at <= cutoff:
        raise ShadowInvalid("close labels must be captured after the stage cutoff")
    if captured_at.strftime("%Y%m%d") != trade_date:
        raise ShadowInvalid("close labels are late/expired for the stage trade date")
    return (
        {
            "truth_scope": TRUTH_SCOPE,
            "truth_universe_version": truth_version,
            "truth_source_version": truth_source_version,
            "truth_input_sha256": str(truth_input_sha).lower(),
            "truth_manifest_sha256": str(truth_manifest_sha).lower(),
            "truth_universe_count": universe_count,
            "truth_coverage_ratio": 1.0,
            "truth_top20_codes": top20_codes,
            "truth_tie_break": tie_break,
            "gain_definition": gain_definition,
            "truth_source_artifact": dict(source_artifact),
            "labels_captured_at": captured_at.isoformat(),
        },
        labels.get("rows") if isinstance(labels.get("rows"), list) else [],
        top20_codes,
    )


def _normalise_label_rows(
    label_rows: Sequence[Mapping[str, Any]],
    members: Mapping[str, Any],
    top20_codes: Sequence[str],
) -> tuple[list[dict[str, Any]], list[str], list[str]]:
    member_rows = members.get("rows")
    if not isinstance(member_rows, list):
        raise ShadowInvalid("members artifact rows are missing")
    member_codes = [str(row.get("security_id") or "") for row in member_rows]
    by_code: dict[str, Mapping[str, Any]] = {}
    for row in label_rows:
        if not isinstance(row, Mapping):
            raise ShadowInvalid("label rows must be objects")
        code = _canonical_code(row.get("security_id", row.get("code")))
        if code in by_code:
            raise ShadowInvalid(f"duplicate label row: {code}")
        by_code[code] = row
    invalid: list[str] = []
    markout_invalid: list[str] = []
    normalised: list[dict[str, Any]] = []
    top20_set = set(top20_codes)
    expected_rank_by_code = {code: index + 1 for index, code in enumerate(top20_codes)}
    observed_ranks: set[int] = set()
    for member in member_rows:
        code = str(member["security_id"])
        raw = by_code.get(code)
        expected_hit = code in top20_set
        expected_rank = expected_rank_by_code.get(code)
        if raw is None:
            # Full-universe truth already determines hit membership.  A
            # missing per-D1 quote makes markout unavailable, but it must not
            # turn a verified Top20 hit into a false zero.
            markout_invalid.append(f"MISSING_CLOSE_LABEL:{code}")
            normalised.append({
                "security_id": code,
                "close_top20_rank": expected_rank,
                "hit_top20": expected_hit,
                "close_price": None,
                "close_price_source": "",
                "currency": "",
                "adjustment_mode": "",
                "invalid_reason": "MISSING_CLOSE_LABEL",
            })
            continue
        rank = raw.get("close_top20_rank")
        if rank in (None, ""):
            rank_value = expected_rank
        elif isinstance(rank, bool) or not isinstance(rank, int) or not 1 <= rank <= TRUTH_K:
            invalid.append(f"INVALID_CLOSE_TOP20_RANK:{code}")
            rank_value = None
        else:
            rank_value = rank
            if rank_value in observed_ranks:
                invalid.append(f"DUPLICATE_CLOSE_TOP20_RANK:{code}")
            observed_ranks.add(rank_value)
        if rank_value is not None and rank_value != expected_rank_by_code.get(code):
            invalid.append(f"CLOSE_TOP20_RANK_ORDER_MISMATCH:{code}")
        if rank_value is not None and not expected_hit:
            invalid.append(f"NON_TOP20_CODE_HAS_RANK:{code}")
        if raw.get("hit_top20") is not expected_hit:
            invalid.append(f"HIT_FLAG_MISMATCH:{code}")
        close_price: float | None
        try:
            close_price = _finite(raw.get("close_price"))
            if close_price <= 0:
                raise ShadowInvalid("close price must be positive")
        except ShadowInvalid:
            close_price = None
            markout_invalid.append(f"MISSING_OR_INVALID_CLOSE_PRICE:{code}")
        source = str(raw.get("close_price_source") or "").strip()
        currency = str(raw.get("currency") or "").strip().upper()
        adjustment = str(raw.get("adjustment_mode") or "").strip()
        if not source or not currency or not adjustment:
            markout_invalid.append(f"CLOSE_PRICE_SEMANTICS_MISSING:{code}")
        row_payload = {
            "security_id": code,
            "close_top20_rank": rank_value,
            "hit_top20": expected_hit,
            "close_price": close_price,
            "close_price_source": source,
            "currency": currency,
            "adjustment_mode": adjustment,
        }
        row_reasons = [
            *[reason for reason in invalid if reason.endswith(f":{code}")],
            *[reason for reason in markout_invalid if reason.endswith(f":{code}")],
        ]
        if row_reasons:
            row_payload["invalid_reason"] = "|".join(row_reasons)
        normalised.append(row_payload)
    unknown = sorted(set(by_code) - set(member_codes))
    invalid.extend(f"LABEL_NOT_IN_D1_POOL:{code}" for code in unknown)
    expected_member_top20_ranks = {
        row["close_top20_rank"]
        for row in normalised
        if row.get("close_top20_rank") is not None
    }
    if len(expected_member_top20_ranks) != sum(1 for code in member_codes if code in top20_set):
        invalid.append("DUPLICATE_OR_MISSING_D1_TOP20_RANKS")
    if set(member_codes) != set(by_code):
        # Full D1 label coverage is required for markout and for explicit
        # missing-label accounting; unknown rows cannot repair a missing row.
        pass
    return normalised, invalid, markout_invalid


def append_labels(run_root: Path | str, labels: Mapping[str, Any]) -> dict[str, Any]:
    """Append close labels after the frozen selection files exist.

    Invalid/incomplete truth is recorded as an immutable invalid ledger and is
    never converted to a zero or a negative hit.  The function never rewrites
    any selection artifact.
    """

    members, baseline, candidate, receipt = _read_frozen(run_root)
    if not isinstance(labels, Mapping):
        labels = {}
    cutoff = _parse_timestamp(receipt["cutoff_ts"], str(receipt["trade_date"]), "cutoff_ts")
    run_root_path = Path(run_root).expanduser().resolve()
    label_dir = run_root_path / "labels"
    label_path = label_dir / "labels.json"
    invalid_path = label_dir / "invalid_ledger.json"
    if label_dir.is_symlink() or label_path.is_symlink() or invalid_path.is_symlink():
        raise ShadowInvalid("label directory/artifact cannot be symlinked")
    try:
        truth, raw_rows, top20_codes = _truth_metadata(labels, str(receipt["trade_date"]), cutoff)
        label_rows, invalid_reasons, markout_invalid_reasons = _normalise_label_rows(raw_rows, members, top20_codes)
    except ShadowInvalid as error:
        truth = {
            "truth_scope": labels.get("truth_scope"),
            "status": "CANNOT_CONFIRM",
        }
        label_rows = []
        invalid_reasons = [str(error)]
        markout_invalid_reasons = []
    status = "READY" if not invalid_reasons else "CANNOT_CONFIRM"
    label_payload = {
        "schema_version": LABEL_SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "trade_date": receipt["trade_date"],
        "stage": receipt["stage"],
        "cutoff_ts": receipt["cutoff_ts"],
        "status": status,
        "truth": truth,
        "rows": label_rows,
        "invalid_reasons": invalid_reasons,
        "markout_invalid_reasons": markout_invalid_reasons,
        "selection_receipt_sha256": sha256_file(run_root_path / "selection_receipt.json"),
        **SAFETY_FLAGS,
    }
    label_sha = _immutable_json(label_path, label_payload)
    invalid_payload = {
        "schema_version": LABEL_SCHEMA_VERSION,
        "experiment_id": EXPERIMENT_ID,
        "trade_date": receipt["trade_date"],
        "stage": receipt["stage"],
        "status": status,
        "invalid_reasons": invalid_reasons,
        "markout_invalid_reasons": markout_invalid_reasons,
        "labels_sha256": label_sha,
        "recorded_after_selection_freeze": True,
        **SAFETY_FLAGS,
    }
    invalid_sha = _immutable_json(invalid_path, invalid_payload)
    return {
        "status": status,
        "run_root": str(run_root_path),
        "labels_sha256": label_sha,
        "invalid_ledger_sha256": invalid_sha,
        "invalid_reasons": invalid_reasons,
        "markout_invalid_reasons": markout_invalid_reasons,
        "label_count": len(label_rows),
        "safety": dict(SAFETY_FLAGS),
    }


def _summary(values: Sequence[float]) -> dict[str, Any]:
    if not values:
        return {"count": 0, "average": None, "median": None, "positive_ratio": None, "worst": None}
    return {
        "count": len(values),
        "average": sum(values) / len(values),
        "median": statistics.median(values),
        "positive_ratio": sum(value > 0 for value in values) / len(values),
        "worst": min(values),
    }


def _markout_for_codes(rows: Sequence[Mapping[str, Any]], label_by_code: Mapping[str, Mapping[str, Any]], codes: Sequence[str]) -> tuple[list[float], list[str]]:
    values: list[float] = []
    invalid: list[str] = []
    for code in codes:
        member = next((row for row in rows if str(row.get("security_id")) == str(code)), None)
        label = label_by_code.get(str(code))
        if member is None or label is None:
            invalid.append(f"MISSING_MARKOUT_ROW:{code}")
            continue
        try:
            stage_price = _finite(member.get("stage_price"))
            close_price = _finite(label.get("close_price"))
        except ShadowInvalid:
            invalid.append(f"MISSING_MARKOUT_PRICE:{code}")
            continue
        if stage_price <= 0 or close_price <= 0:
            invalid.append(f"INVALID_MARKOUT_PRICE:{code}")
            continue
        if str(member.get("currency")) != str(label.get("currency")):
            invalid.append(f"MARKOUT_CURRENCY_MISMATCH:{code}")
            continue
        if str(member.get("adjustment_mode")) != str(label.get("adjustment_mode")):
            invalid.append(f"MARKOUT_ADJUSTMENT_MISMATCH:{code}")
            continue
        values.append(close_price / stage_price - 1.0)
    return values, invalid


def evaluate_run(run_root: Path | str) -> dict[str, Any]:
    """Evaluate one frozen unit; labels are never used to rebuild a candidate."""

    members, baseline, candidate, receipt = _read_frozen(run_root)
    label_path = Path(run_root).expanduser().resolve() / "labels" / "labels.json"
    if not label_path.is_file() or label_path.is_symlink():
        return {
            "status": "CANNOT_CONFIRM",
            "trade_date": receipt.get("trade_date"),
            "stage": receipt.get("stage"),
            "invalid_reasons": ["LABELS_NOT_APPENDED_AFTER_FREEZE"],
        }
    labels = _read_json(label_path)
    ledger_path = Path(run_root).expanduser().resolve() / "labels" / "invalid_ledger.json"
    if not ledger_path.is_file() or ledger_path.is_symlink():
        return {
            "status": "CANNOT_CONFIRM",
            "trade_date": receipt.get("trade_date"),
            "stage": receipt.get("stage"),
            "invalid_reasons": ["LABEL_INVALID_LEDGER_MISSING"],
        }
    ledger = _read_json(ledger_path)
    if not isinstance(ledger, Mapping) or ledger.get("labels_sha256") != sha256_file(label_path):
        return {
            "status": "CANNOT_CONFIRM",
            "trade_date": receipt.get("trade_date"),
            "stage": receipt.get("stage"),
            "invalid_reasons": ["LABEL_HASH_MISMATCH"],
        }
    if not isinstance(labels, Mapping) or labels.get("selection_receipt_sha256") != sha256_file(Path(run_root).expanduser().resolve() / "selection_receipt.json"):
        return {
            "status": "CANNOT_CONFIRM",
            "trade_date": receipt.get("trade_date"),
            "stage": receipt.get("stage"),
            "invalid_reasons": ["LABEL_SELECTION_RECEIPT_BINDING_MISMATCH"],
        }
    if not isinstance(labels, Mapping) or labels.get("status") != "READY":
        return {
            "status": "CANNOT_CONFIRM",
            "trade_date": receipt.get("trade_date"),
            "stage": receipt.get("stage"),
            "invalid_reasons": list(labels.get("invalid_reasons", [])) if isinstance(labels, Mapping) else ["LABEL_PAYLOAD_INVALID"],
        }
    label_by_code = {str(row.get("security_id")): row for row in labels.get("rows", []) if isinstance(row, Mapping)}
    truth = labels.get("truth") if isinstance(labels.get("truth"), Mapping) else {}
    top20 = set(str(code) for code in truth.get("truth_top20_codes", []))
    baseline_codes = [str(code) for code in baseline.get("codes", [])]
    candidate_codes = [str(code) for code in candidate.get("codes", [])]
    baseline_hits = sum(code in top20 for code in baseline_codes)
    candidate_hits = sum(code in top20 for code in candidate_codes)
    pool_codes = {str(row.get("security_id")) for row in members.get("rows", [])}
    pool_truth = len(pool_codes & top20)
    entered = sorted(set(candidate_codes) - set(baseline_codes))
    exited = sorted(set(baseline_codes) - set(candidate_codes))
    member_rows = members.get("rows", [])
    baseline_markout, baseline_markout_invalid = _markout_for_codes(member_rows, label_by_code, baseline_codes)
    candidate_markout, candidate_markout_invalid = _markout_for_codes(member_rows, label_by_code, candidate_codes)
    entered_markout, entered_invalid = _markout_for_codes(member_rows, label_by_code, entered)
    exited_markout, exited_invalid = _markout_for_codes(member_rows, label_by_code, exited)
    return {
        "status": "READY",
        "trade_date": receipt["trade_date"],
        "stage": receipt["stage"],
        "truth_scope": truth.get("truth_scope"),
        "baseline_hit_count": baseline_hits,
        "candidate_hit_count": candidate_hits,
        "delta_hit_count": candidate_hits - baseline_hits,
        "d1_pool_truth_count": pool_truth,
        "d1_pool_recall": pool_truth / TRUTH_K,
        "baseline_codes": baseline_codes,
        "candidate_codes": candidate_codes,
        "entered_codes": entered,
        "exited_codes": exited,
        "markout": {
            "status": "READY" if not (baseline_markout_invalid + candidate_markout_invalid) else "CANNOT_CONFIRM",
            "baseline": _summary(baseline_markout),
            "candidate": _summary(candidate_markout),
            "entered": _summary(entered_markout),
            "exited": _summary(exited_markout),
            "invalid_reasons": baseline_markout_invalid + candidate_markout_invalid + entered_invalid + exited_invalid,
        },
    }


def evaluate_runs(run_roots: Iterable[Path | str]) -> dict[str, Any]:
    units = [evaluate_run(root) for root in run_roots]
    valid = [unit for unit in units if unit.get("status") == "READY"]
    invalid = [unit for unit in units if unit.get("status") != "READY"]
    planned = len(units)
    valid_count = len(valid)
    baseline_hits = sum(int(unit["baseline_hit_count"]) for unit in valid)
    candidate_hits = sum(int(unit["candidate_hit_count"]) for unit in valid)
    denominator = TOP_K * valid_count
    recall_denominator = TRUTH_K * valid_count
    changed_in = sum(len(unit.get("entered_codes", [])) for unit in valid)
    changed_out = sum(len(unit.get("exited_codes", [])) for unit in valid)
    required_capacity = math.ceil(0.05 * TOP_K * planned)
    all_truth_hits = sum(int(unit.get("d1_pool_truth_count", 0)) for unit in valid)
    result: dict[str, Any] = {
        "experiment_id": EXPERIMENT_ID,
        "truth_scope": TRUTH_SCOPE,
        "planned_units": planned,
        "valid_units": valid_count,
        "invalid_units": len(invalid),
        "invalid_reasons": [reason for unit in invalid for reason in unit.get("invalid_reasons", [])],
        "fixed_p10_denominator": denominator if valid_count else None,
        "fixed_recall20_denominator": recall_denominator if valid_count else None,
        "baseline_hit_count": baseline_hits if valid_count else None,
        "candidate_hit_count": candidate_hits if valid_count else None,
        "delta_hit_count": (candidate_hits - baseline_hits) if valid_count else None,
        "baseline_p_at_10": baseline_hits / denominator if denominator else None,
        "candidate_p_at_10": candidate_hits / denominator if denominator else None,
        "delta_p_points": (candidate_hits - baseline_hits) / denominator if denominator else None,
        "baseline_recall_at_20": baseline_hits / recall_denominator if recall_denominator else None,
        "candidate_recall_at_20": candidate_hits / recall_denominator if recall_denominator else None,
        "d1_pool_recall_at_20": all_truth_hits / recall_denominator if recall_denominator else None,
        "selection_ceiling_at_20": all_truth_hits / recall_denominator if recall_denominator else None,
        "changed_in_count": changed_in,
        "changed_out_count": changed_out,
        "capacity_required_for_5pp": required_capacity,
        "capacity_status": (
            "INSUFFICIENT_INTERVENTION_CAPACITY_FOR_5PP"
            if changed_in < required_capacity
            else "CAPACITY_REACHED_FOR_5PP_REVIEW"
        ),
        "units": units,
        **SAFETY_FLAGS,
    }
    result["evaluation_status"] = "CANNOT_CONFIRM" if not valid_count or invalid else "READY"
    # Stages are reported independently while the aggregate remains the only
    # verdict; no best-stage selection is allowed.
    by_stage: dict[str, list[dict[str, Any]]] = {}
    by_date: dict[str, list[dict[str, Any]]] = {}
    for unit in valid:
        by_stage.setdefault(str(unit["stage"]), []).append(unit)
        by_date.setdefault(str(unit["trade_date"]), []).append(unit)
    result["by_stage"] = {
        stage: {
            "units": len(items),
            "baseline_hits": sum(int(item["baseline_hit_count"]) for item in items),
            "candidate_hits": sum(int(item["candidate_hit_count"]) for item in items),
            "delta_hits": sum(int(item["delta_hit_count"]) for item in items),
        }
        for stage, items in sorted(by_stage.items())
    }
    result["by_trade_date"] = {
        trade_date: {
            "units": len(items),
            "baseline_hits": sum(int(item["baseline_hit_count"]) for item in items),
            "candidate_hits": sum(int(item["candidate_hit_count"]) for item in items),
            "delta_hits": sum(int(item["delta_hit_count"]) for item in items),
        }
        for trade_date, items in sorted(by_date.items())
    }
    return result


def preflight_input(payload_or_path: Mapping[str, Any] | Path | str) -> dict[str, Any]:
    """Check whether an input is eligible for a forward manual observation.

    Existing archives, fixtures, replays, and CF/proxy inputs are deliberately
    rejected.  This is an engineering preflight and never counts as a natural
    canary day.
    """

    payload = _read_json(payload_or_path) if isinstance(payload_or_path, (Path, str)) else payload_or_path
    reasons: list[str] = []
    if not isinstance(payload, Mapping):
        return {"status": "REJECTED", "forward_eligible": False, "reasons": ["INPUT_NOT_OBJECT"], "natural_sample_count": 0}
    metadata = _metadata_from_input(payload)
    mode = str(metadata.get("observation_mode") or "").upper()
    source_mode = str(metadata.get("source_mode") or metadata.get("source_kind") or "").upper()
    if mode not in {"FORWARD_NATURAL", "FORWARD_SHADOW"}:
        reasons.append("FORWARD_OBSERVATION_MODE_REQUIRED")
    if any(token in source_mode for token in ("LEGACY", "ARCHIVE", "HISTORICAL", "FIXTURE", "REPLAY", "CF", "PROXY")):
        reasons.append("LEGACY_OR_PROXY_SOURCE_REJECTED")
    try:
        _reject_archive_or_proxy_metadata(metadata)
    except ShadowInvalid:
        if "LEGACY_OR_PROXY_SOURCE_REJECTED" not in reasons:
            reasons.append("LEGACY_OR_PROXY_SOURCE_REJECTED")
    try:
        _stage_contract(metadata)
    except ShadowInvalid as error:
        reasons.append(str(error))
    try:
        _source_binding(metadata)
    except ShadowInvalid as error:
        reasons.append(str(error))
    if not isinstance(metadata.get("rows", payload.get("rows")), list):
        reasons.append("ROWS_MISSING")
    # A preflight never claims that a historical date is natural merely because
    # the file is readable.  The producer must mark the observation explicitly.
    captured = metadata.get("captured_at")
    if not captured:
        reasons.append("CAPTURED_AT_REQUIRED")
    else:
        try:
            trade_date = _exact_date(metadata.get("trade_date"), "trade_date")
            cutoff = _parse_timestamp(metadata.get("cutoff_ts"), trade_date, "cutoff_ts")
            captured_at = _parse_timestamp(captured, trade_date, "captured_at")
            if captured_at > cutoff:
                reasons.append("CAPTURED_AT_AFTER_CUTOFF")
        except ShadowInvalid as error:
            reasons.append(str(error))
    # Preflight must exercise the same full-pool and row-shape gates as the
    # persistent freeze path.  A readable JSON file with an empty or short
    # rows list is therefore never reported as forward-eligible.
    try:
        build_payload = dict(payload)
        if isinstance(payload.get("metadata"), Mapping):
            build_payload["metadata"] = dict(payload["metadata"])
        build_shadow(build_payload, require_full_pool=True, require_artifacts=True)
    except ShadowInvalid as error:
        reasons.append(f"INPUT_VALIDATION:{error}")
    return {
        "status": "PASS" if not reasons else "REJECTED",
        "forward_eligible": not reasons,
        "reasons": reasons,
        "natural_sample_count": 0,
        "counts_as_forward_day": False,
        "observation_mode": mode,
        "source_mode": source_mode,
    }


def capture_selector_snapshot(
    payload_or_path: Mapping[str, Any] | Path | str,
    output_root: Path | str,
) -> dict[str, Any]:
    """Capture a real HK four-lane selector call through its opt-in hook.

    The input contains the same raw rows and verified provenance consumed by
    the selector.  This function invokes ``select_hk_four_lane`` and lets the
    hook assign ranks from the real full sorted output; callers never provide a
    hand-ranked production list.  A failed shadow capture is recorded as an
    immutable invalid ledger while the returned selector envelope remains the
    production result.
    """

    payload = _read_json(payload_or_path) if isinstance(payload_or_path, (Path, str)) else payload_or_path
    if not isinstance(payload, Mapping):
        return record_invalid_capture(output_root, {}, ["CAPTURE_INPUT_NOT_OBJECT"])
    metadata = dict(_metadata_from_input(payload))
    rows = payload.get("rows")
    formula_manifest = payload.get("formula_manifest", metadata.get("formula_manifest"))
    time_evidence = payload.get("time_evidence", metadata.get("time_evidence"))
    d1_manifest = payload.get("d1_manifest", metadata.get("d1_manifest"))
    trade_date = str(metadata.get("trade_date") or "").replace("-", "")
    stage_id = str(metadata.get("stage") or metadata.get("stage_id") or "")
    raw_artifact_sha = metadata.get("raw_artifact_sha256")
    capture_result: dict[str, Any] = {}

    def _record(result: Mapping[str, Any]) -> None:
        capture_result.clear()
        capture_result.update(dict(result))

    def _capture_callback(
        *,
        raw_rows: Sequence[Mapping[str, Any]],
        sorted_rows: Sequence[Mapping[str, Any]],
        production_rows: Sequence[Mapping[str, Any]],
        context: Mapping[str, Any],
    ) -> None:
        try:
            shadow_payload = build_selector_capture_payload(
                metadata=metadata,
                raw_rows=raw_rows,
                sorted_rows=sorted_rows,
                production_rows=production_rows,
                formula_manifest=formula_manifest,
                time_evidence=time_evidence,
                d1_manifest=d1_manifest,
                raw_artifact_sha256=str(context.get("raw_artifact_sha256") or raw_artifact_sha or ""),
            )
            production_codes = [
                _canonical_code(row.get("security_id", row.get("code")))
                for row in production_rows
                if isinstance(row, Mapping)
            ][:TOP_K]
            built = build_shadow(shadow_payload, require_full_pool=True)
            if built.get("baseline", {}).get("codes") != production_codes:
                raise ShadowInvalid("frozen baseline does not equal the real selector Top10")
            frozen = freeze_snapshot(shadow_payload, output_root, require_full_pool=True)
            _record({
                "status": "FROZEN",
                "selector_top10_codes": production_codes,
                "capture": frozen,
            })
        except ShadowInvalid as error:
            _record(record_invalid_capture(
                output_root,
                metadata,
                [str(error)],
                context={"hook_context": dict(context)},
            ))
        except Exception as error:  # pragma: no cover - external filesystem/runtime failures
            _record(record_invalid_capture(
                output_root,
                metadata,
                [f"CAPTURE_EXCEPTION:{error}"],
                context={"hook_context": dict(context)},
            ))

    def _capture_error(*, error: Exception, context: Mapping[str, Any]) -> None:
        _record(record_invalid_capture(
            output_root,
            metadata,
            [f"SHADOW_CALLBACK_FAILED:{error}"],
            context={"hook_context": dict(context)},
        ))

    if not isinstance(rows, list):
        invalid = record_invalid_capture(output_root, metadata, ["CAPTURE_ROWS_REQUIRED"])
        return {"status": "CANNOT_CONFIRM", "capture": invalid}
    if stage_id not in STAGE_CUTOFFS:
        invalid = record_invalid_capture(output_root, metadata, [f"UNSUPPORTED_STAGE:{stage_id}"])
        return {"status": "CANNOT_CONFIRM", "capture": invalid}
    try:
        # Import lazily so the frozen shadow module remains a consumer of the
        # selector hook rather than a second selector implementation.
        from .selection import select_hk_four_lane

        selected = select_hk_four_lane(
            rows,
            trade_date,
            stage_id,
            str(raw_artifact_sha or ""),
            source_status=str(metadata.get("source_status") or "READY"),
            requested_rows=metadata.get("requested_rows"),
            missing_symbols=tuple(metadata.get("missing_symbols") or ()),
            cannot_confirm=tuple(metadata.get("cannot_confirm") or ()),
            source_evidence=tuple(metadata.get("source_evidence") or ()),
            cap_limit_yi=float(metadata.get("cap_limit_yi", 100.0)),
            shadow_capture=_capture_callback,
            shadow_context=metadata,
            shadow_capture_error=_capture_error,
        )
    except Exception as error:
        if not capture_result:
            _record(record_invalid_capture(
                output_root,
                metadata,
                [f"SELECTOR_CAPTURE_FAILED:{error}"],
                context={"stage": stage_id, "trade_date": trade_date},
            ))
        return {
            "status": "CANNOT_CONFIRM",
            "selector_error": str(error),
            "capture": dict(capture_result),
        }
    if not capture_result:
        _record(record_invalid_capture(
            output_root,
            metadata,
            ["SHADOW_CAPTURE_NOT_INVOKED"],
            context={"stage": stage_id, "trade_date": trade_date},
        ))
    return {
        "status": "READY" if capture_result.get("status") == "FROZEN" else "CANNOT_CONFIRM",
        "selector_status": selected.get("selection_status"),
        "production_top10_codes": [str(row.get("code")) for row in selected.get("rows", [])[:TOP_K]],
        "selector": selected,
        "capture": dict(capture_result),
        **SAFETY_FLAGS,
    }


def _cli() -> int:
    parser = argparse.ArgumentParser(description="V4 formula-margin shadow manual, read-only tool")
    sub = parser.add_subparsers(dest="command", required=True)
    preflight = sub.add_parser("preflight")
    preflight.add_argument("--input", type=Path, required=True)
    capture = sub.add_parser("capture")
    capture.add_argument("--input", type=Path, required=True)
    capture.add_argument("--output-root", type=Path, required=True)
    freeze = sub.add_parser("freeze")
    freeze.add_argument("--input", type=Path, required=True)
    freeze.add_argument("--output-root", type=Path, required=True)
    label = sub.add_parser("label")
    label.add_argument("--run-root", type=Path, required=True)
    label.add_argument("--input", type=Path, required=True)
    verify = sub.add_parser("verify")
    verify.add_argument("--run-root", type=Path, required=True)
    evaluate = sub.add_parser("evaluate")
    evaluate.add_argument("--run-root", type=Path, action="append", required=True)
    args = parser.parse_args()
    try:
        if args.command == "preflight":
            result = preflight_input(args.input)
        elif args.command == "capture":
            result = capture_selector_snapshot(args.input, args.output_root)
        elif args.command == "freeze":
            result = freeze_snapshot(
                _read_json(args.input),
                args.output_root,
                require_full_pool=True,
            )
        elif args.command == "label":
            result = append_labels(args.run_root, _read_json(args.input))
        elif args.command == "verify":
            result = verify_frozen_artifacts(args.run_root)
        else:
            result = evaluate_runs(args.run_root)
    except ShadowInvalid as error:
        result = {"status": "CANNOT_CONFIRM", "error": str(error)}
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if result.get("status") not in {"CANNOT_CONFIRM", "REJECTED"} else 2


if __name__ == "__main__":  # pragma: no cover - exercised through the CLI tests
    raise SystemExit(_cli())


__all__ = [
    "COMPARATOR_KEY_NAMES",
    "COMPARATOR_VERSION",
    "EXPERIMENT_ID",
    "FORMULA_STATES",
    "INPUT_SCHEMA_VERSION",
    "LABEL_SCHEMA_VERSION",
    "MARKET",
    "POOL_LIMIT",
    "RULE_VERSION",
    "SAFETY_FLAGS",
    "SCHEMA_VERSION",
    "ShadowInvalid",
    "STAGE_CUTOFFS",
    "TOP_K",
    "TRUTH_K",
    "TRUTH_SCOPE",
    "append_labels",
    "build_shadow",
    "build_selector_capture_payload",
    "capture_selector_snapshot",
    "canonical_json",
    "evaluate_run",
    "evaluate_runs",
    "freeze_snapshot",
    "hk_legacy_stage_sort_key",
    "preflight_input",
    "record_invalid_capture",
    "sha256_file",
    "verify_frozen_artifacts",
]
