# V4_FORMULA_MARGIN_SHADOW_V1 — R2 Minimal Fix Specification

Review basis: uploaded `V4_FORMULA_SHADOW_CHAT_FEEDBACK.zip`, SHA256 `f1590f77f347294c04f740fe0de6615eb3a8a94bf9a4fc8890da842457ef70ca`.
Checkpoint state from package manifest: `STOPPED_AT_USER_CORRECTION_UNREVIEWED_CHECKPOINT`; `natural_sample_count=0`.

## Decision lock

Do not change the selection rule. Do not add a third rule, model, factor search, scheduler, BUY gate, production write path, or trading action.

Truth objective remains: same-day closing-gain Top20 among the entire exact-date HK Connect eligible universe, without market-cap filtering, D1 restriction, or post-hoc exclusion of high-gainers. D1 Top100 is selection input only.

## Current checkpoint adjudication

1. Full-universe truth: PARTIALLY FIXED, STILL P1 BLOCKER. The code now computes Top20 from source rows and rejects a mismatching self-declared Top20, but the source rows are not bound to an authoritative exact-date HK Connect membership source. A hash-consistent self-made universe can still become READY. Gain definition and security-id tie-break are hard-coded without evidence that they match the existing authoritative source.
2. Production/formula provenance: PARTIALLY FIXED, STILL P1 BLOCKER. Production source/rule artifacts and formula-state artifact bytes are checked, but `raw_artifact_sha256` is not required to equal the verified production source artifact, source rows are not required to byte/canonical-row match the actual selector raw rows, and formula `rule_sha256` has no required rule artifact.
3. Hit versus markout: FIXED IN CODE. Truth-valid hit counts survive missing currency/adjustment/close-source semantics; markout alone becomes CANNOT_CONFIRM. Documentation still contradicts this and must be corrected.
4. Comparator alias conflict: FIXED FOR THE REPORTED DEFECT. Conflicting `bucket_weight`/`candidate_bucket` and `no_trade_gate`/status fail closed. Keep `selection.py` unchanged in R2; add explicit regression cases.
5. Full pool: FIXED IN CODE. Persistent freeze requires exactly 100 rows and selector capture requires 100 full sorted rows. Natural 100-row evidence still does not exist.
6. Preflight: PARTIALLY FIXED. Empty/short freeze-format rows now reject, but current preflight validates the already-materialized freeze schema, while `capture` accepts a raw selector-input schema and derives rank/formula joins inside the hook. Add one shared capture-request static validator and a capture-specific preflight path.

## R2 allowed file set

Functional changes only in:
- `stage_center/formula_margin_shadow.py`
- `tests/test_formula_margin_shadow.py`
- `docs/formula_margin_shadow_v1.md`

`stage_center/selection.py` must remain byte-identical to checkpoint SHA256 `1f93525ced647bfdc8fbf53ad3efb157a112206997003ade3f06dcfb91919549` for this batch unless a new independent defect is demonstrated.

`ops/run_formula_margin_shadow.py` need not change; it delegates to `_cli`. The CLI inside `formula_margin_shadow.py` may add a capture-specific preflight subcommand/mode.

## Fix 1 — bind selector capture to actual bytes

For selector capture, require all of the following:

- `metadata.input_sha256 == sha256(source_artifact bytes)`.
- `metadata.raw_artifact_sha256 == sha256(source_artifact bytes)` for this experiment's capture contract. If the real V4 field means a different upstream object, stop and provide the existing manifest relationship; do not accept two unrelated hashes.
- `source_artifact.rows` must canonical-match the callback `raw_rows` as an ordered row sequence, not merely match code sets or selected comparator fields.
- `rule_sha256 == sha256(rule_artifact bytes)`.
- Formula manifest/state artifact must satisfy `formula_manifest.input_sha256 == sha256(formula state artifact bytes)` and the per-code H/N/U rows must exactly match those bytes.
- Add required `formula_manifest.rule_artifact`; its actual SHA must equal `formula_manifest.rule_sha256`, and formula provenance input/rule SHAs must equal the manifest input/rule SHAs.
- D1 manifest artifact remains the authority for the 100 pool members; its code set must equal the selector raw input code set.

Any mismatch writes/returns `CANNOT_CONFIRM`; no B/F artifact may be published.

## Fix 2 — full-universe truth must be authority-bound, then joined to D1

Do not trust `truth_universe_count`, `truth_coverage_ratio`, `truth_top20_codes`, arbitrary source-version strings, or a user-created combined JSON as proof of universe authority.

Before implementing the adapter, identify the EXISTING V4 source that is authoritative for the exact-date full HK Connect universe and same-day final close gain. No new web/vendor/parallel data source is allowed in R2.

The adapter needs these exact source facts from that existing source:

1. membership producer/source identity and schema/version;
2. exact-date membership artifact/manifest SHA and security-id field;
3. close/gain producer/source identity and schema/version;
4. authoritative gain field OR an explicit documented `close`/reference-price formula and its corporate-action/adjustment semantics;
5. final-EOD/final-close status or finalization timestamp/flag;
6. deterministic same-gain ordering/rank field or documented source tie-break;
7. suspension handling in that source (included with a defined gain, null, or another documented representation).

If any of 4–7 is absent, do not guess. The truth unit is not admissible until the source contract is explicit.

Implementation behavior once the existing source is identified:

- Load exact-date membership set M from its verified artifact.
- Load final close/gain rows C from its verified artifact.
- Require exact security coverage for every member in M; extra/nonmember rows must not enter truth.
- Derive `truth_universe_count=len(M)` and coverage internally. Do not accept these as authority from label JSON.
- Compute/order Top20 from the authoritative gain/rank contract. A caller-supplied Top20 may be checked, never used as source.
- Then join the computed Top20 membership/rank to the frozen D1 members. Full-market rows outside D1 are expected and must not generate `LABEL_NOT_IN_D1_POOL`.
- Do not require per-D1 markout semantics to decide hit membership.

Suspensions: if a security is an exact-date HK Connect member, do not exclude it merely because it is suspended. Use the existing authoritative source's documented gain value/policy. If the source leaves gain undefined and gives no binding policy, the entire truth unit is invalid; do not impute 0%.

Tie at the Top20 boundary: use the existing source's deterministic rank/tie-break. If the existing source has no such contract, mark the unit invalid until the user/source owner freezes one; do not silently retain `security_id ASC` as an invented authority rule.

## Fix 3 — preserve hit/markout separation and align docs

Hit unit is valid when authoritative full-universe truth is complete and frozen B/F lists are valid.

Markout alone is invalid when any selected name lacks compatible:
- stage price / close price,
- currency,
- adjustment mode,
- same-security price identity/source semantics.

Missing markout semantics must not null `baseline_hit_count`, `candidate_hit_count`, P@10, or recall@20.

Update docs lines that currently state that every D1 member missing close-price semantics makes the whole unit CANNOT_CONFIRM.

## Fix 4 — capture preflight must match capture admission

Add a shared `_validate_capture_request_static(...)` used by both:
- a new capture-specific preflight entry (`preflight-capture` or `preflight --mode capture`), and
- the beginning of `capture_selector_snapshot`.

It must verify before invoking the selector:
- supported stage/date/cutoff and forward observation mode;
- captured_at <= cutoff;
- exactly 100 unique raw D1 rows;
- actual production source and rule artifact bindings;
- D1 manifest actual artifact and exact member-set equality;
- formula input artifact, rule artifact, exact 100-code state coverage, and H/N/U states;
- time-evidence presence and binding required by the capture contract.

A static preflight PASS means only `READY_FOR_SELECTOR_CAPTURE`, not `FROZEN` and not a counted natural sample. Dynamic rank/tau checks remain in the actual capture/freeze path.

The existing freeze-format `preflight` can remain separate, but docs must distinguish the two input schemas.

## Mandatory acceptance cases

All cases are fail-closed unless explicitly marked READY.

1. Arbitrary hash-consistent fake universe not bound to the configured existing membership authority -> truth invalid.
2. Verified full universe contains hundreds of non-D1 members -> truth can be READY; Top20 is computed before D1 join and no outside-D1 error occurs.
3. One exact-date member missing authoritative gain/close coverage -> entire hit unit invalid, not a zero/nonhit.
4. Caller supplies a fake Top20 list while source rows produce another Top20 -> invalid.
5. Same-gain boundary without source-bound deterministic tie-break -> invalid.
6. Suspended exact-date member remains in membership; undefined source gain with no documented policy -> invalid, not excluded and not forced to 0.
7. Missing currency/adjustment/close-price-source only for markout -> hit evaluation READY; markout CANNOT_CONFIRM.
8. `raw_artifact_sha256` different from verified source artifact SHA -> capture invalid.
9. Source artifact row sequence/content differs from actual selector raw rows -> capture invalid.
10. Formula state artifact byte/state mismatch -> capture invalid.
11. Formula `rule_sha256` with no matching actual rule artifact -> capture invalid.
12. Reported bucket alias conflict example -> invalid.
13. Matching bucket but `WATCH_ONLY` plus `no_trade_gate=0` -> invalid.
14. 99 or 101 raw/sorted rows -> capture invalid; no candidate artifact.
15. Empty/malformed capture input -> capture preflight REJECTED and capture CANNOT_CONFIRM.
16. A valid raw 100-row capture request -> capture preflight `READY_FOR_SELECTOR_CAPTURE`; actual capture baseline Top10 must equal the selector's real returned Top10.
17. No valid rank6..15 same-class score gap -> stage invalid; never broaden tau.
18. tau=0 -> only exact score ties in the same equivalence class may reorder.
19. Shadow callback/file failure -> production selector envelope exactly unchanged.
20. Label/truth mutation after freeze or selection artifact tampering -> verification invalid.

Independent Reviewer must run the focused tests in the complete V4 environment. This chat environment could not collect the package test module because the ZIP intentionally omits `infrastructure.interprocess_lock` and other project modules; therefore Writer's reported 13 PASS is not upgraded to an independent PASS here.

## Blockers versus markout-only gaps

Selection/freeze blocker:
- not exactly 100 D1 rows;
- missing/late formula states;
- unbound production/formula artifacts;
- comparator conflict;
- invalid/tau-unavailable rank10 equivalence class;
- cutoff/PIT violation.

Hit/truth-unit blocker:
- membership authority missing or wrong date;
- incomplete full-member gain coverage;
- nonfinal close source;
- gain definition/adjustment semantics for the truth ranking undefined;
- tie-break undefined;
- suspension handling undefined where needed to rank all members.

Markout-only blocker:
- stage-vs-close currency mismatch;
- stage-vs-close adjustment mismatch;
- close/stage price source identity insufficient for a comparable price ratio;
- selected-name close price missing after hit truth was independently established.

## Manual natural canary after R2 independent PASS

No scheduler is created.

For each of the three locked stages on one future trading day:
1. Operator obtains the exact live D1 100-row selector input and formula/D1/source/rule artifacts at/before cutoff.
2. Run capture-specific preflight. It must return only `READY_FOR_SELECTOR_CAPTURE`.
3. Manually run `capture`; verify immutable members/B/F/receipt and that B equals the real selector Top10.
4. Do not inspect or change the rule based on intra-day outcomes.
5. After the existing authoritative close source is FINAL, run `label` using the exact-date full membership and final gain source.
6. Run `verify` then `evaluate`.
7. A natural canary day counts only when all three planned stage units have qualified selection freezes and authoritative truth. Invalid units remain recorded, never zero-filled.

Repeat this unchanged for the five-day engineering canary. Only after five complete natural days may the fixed 20-day pilot start. Synthetic fixtures never increment `natural_sample_count`.

Safety remains:
`RESEARCH_ONLY=true`, `shadow_only=true`, `production_allowed=false`, `buy_gate_updated=false`, `orders_sent=false`, `automation_created=false`.
